import React from 'react';
import {StyleSheet, Image, ImageBackground, Dimensions, TouchableOpacity} from 'react-native';
import {View, Text} from 'native-base';
// import { useNavigation } from '@react-navigation/native';

const banner = './banner.jpg';
const logo = './logo.jpg';

const {width, height} = Dimensions.get('window');

/* Components */

export class RoundedRectangle extends React.Component {
  render() {
    return (
      <ImageBackground
        style={{
          flex: 1,
          height: 105,
          width: 343,
          position: 'absolute',
          alignItems: 'center',
          left: 0,
          right: 0,
          top: 0,
        }}
        source={require('./rounded_rectangle.png')}>
      </ImageBackground>
    );
  }
}



export class Banner extends React.Component {
  render() {
    return (
      <ImageBackground
        style={{
          flex: 1,
          backgroundColor: 'white',
          height: 300,
          position: 'absolute',
          alignItems: 'center',
          left: 0,
          right: 0,
          top: 0,
        }}
        source={require('./banner.jpg')}>
        <View style={{alignItems: 'center', marginTop: 45}}>
          <Image
            style={{width: width * 0.45, resizeMode: 'contain'}}
            source={require('./logo.png')}
          />
        </View>
      </ImageBackground>
    );
  }
}

export class Wrapper extends React.Component {
  render() {
    return (
      <View
        style={{
          backgroundColor: '#fefefe',
          padding: 15,
          margin: 15,
          marginTop: 200,
        }}>
        <View style={{alignItems: 'center', marginBottom: 20}}>
          <Text
            style={{
              color: '#27ae60',
              fontSize: 18,
              marginBottom: 10,
              marginTop: 20,
              fontWeight: 'bold',
            }}>
            {this.props.heading}
          </Text>
          <View
            style={{
              borderBottomColor: '#27ae60',
              borderBottomWidth: 2,
              width: width - width * 0.9,
            }}
          />
        </View>
        {this.props.children}
      </View>
    );
  }
}

export class OrdersHeading extends React.Component {
  render() {
    return (
      <ImageBackground
        style={{
          flex: 1,
          backgroundColor: '#3c4a55',
          height: 200,
          position: 'absolute',
          alignItems: 'center',
          left: 0,
          right: 0,
          top: 0,
        }}>
        <View style={{alignItems: 'center', marginTop: 30}}>
          <Text style={{color: '#61aee3', fontWeight: 'bold'}}>
            Current Balance: {this.props.currentBalance}
          </Text>
        </View>
      </ImageBackground>
    );
  }
}

export class WrapperNoPadding extends React.Component {
  render() {
    return (
      <View
        style={{
          backgroundColor: '#fefefe',
          borderWidth: 0.5,
          borderColor: '#dddddd',
          marginTop: 85,
          margin: 15,
        }}>
        {this.props.children}
      </View>
    );
  }
}

export class TopNavigationBar extends React.Component {
  render() {
    return (
      <View
        style={{
          backgroundColor: '#232323',
          color: '#fff',
          paddingTop: 15,
          paddingBottom: 15,
        }}>
          <Image style={{position: 'absolute', width: 40, marginTop: 5, resizeMode: 'contain'}} source={require('./images/backicon.png')} />
        <View
        style={{
          marginLeft: 'auto',
          marginRight: 'auto',
        }}>
          <Text style={{ color: '#fff' }}>{this.props.name}</Text>
        </View>
      </View>
    );
  }
}

export class TopProtectedNavigationBar extends React.Component {
  render() {
    // const navigation = useNavigation();
    return (
      <View
        style={{
          backgroundColor: '#232323',
          color: '#fff',
          paddingTop: 15,
          paddingBottom: 15,
        }} >
          <TouchableOpacity onPress={() => this.props.navigate('Profile', {screen: 'Profile'})}>
            <Image  style={{position: 'absolute', width: 40, marginTop: 0, resizeMode: 'contain'}} source={require('./images/user.png')} />
          </TouchableOpacity>
        <View
        style={{
          marginLeft: 'auto',
          marginRight: 'auto',
        }}>
          <Text style={{ color: '#fff' }}>{this.props.name}</Text>
        </View>
      </View>
    );
  }
}

export class BottomProtectedNavigationBar extends React.Component {
  render() {
    return (
      <View style={{ position: 'absolute', bottom: 0, backgroundColor: '#232323', padding: 20, flexDirection: 'row', marginTop: 25 }}>
          <View style={{ flex: 1 }}>
              <View style={{ marginLeft: 'auto', marginRight: 'auto', textAlign: 'center' }}>
                <TouchableOpacity onPress={() => this.props.navigate('Dashboard', {screen: 'Dashboard'})}>
                  {this.props.name == 'Home' && (
                    <Image style={{ width: 30, resizeMode: 'contain', marginTop: 10}} source={require('./images/homeicon-active.png')} />
                  )}
                  {this.props.name != 'Home' && (
                    <Image style={{ width: 30, resizeMode: 'contain', marginTop: 10}} source={require('./images/homeicon.png')} />
                  )}
                    <Text style={{ fontSize: 9, color: '#fff', marginLeft: 'auto', marginRight: 'auto', marginTop: 13 }}>Home</Text>
                </TouchableOpacity>
              </View>
          </View>
          <View style={{ flex: 1 }}>
              <View style={{ marginLeft: 'auto', marginRight: 'auto', textAlign: 'center' }}>
                  <TouchableOpacity onPress={() => this.props.navigate('Markets', {screen: 'Markets'})}>
                      {this.props.name == 'Markets' && (
                        <Image style={{ width: 40, resizeMode: 'contain', marginTop: 10}} source={require('./images/baricon-active.png')} />
                      )}
                      {this.props.name != 'Markets' && (
                      <Image style={{ width: 40, resizeMode: 'contain', marginTop: 10}} source={require('./images/baricon.png')} />
                      )}
                      <Text style={{ fontSize: 9, color: '#fff', marginLeft: 'auto', marginRight: 'auto', marginTop: 10 }}>Markets</Text>
                  </TouchableOpacity>
              </View>
          </View>
          <View style={{ flex: 1 }}>
              <View style={{ marginLeft: 'auto', marginRight: 'auto', textAlign: 'center' }}>
                  <TouchableOpacity onPress={() => this.props.navigate('TradeChart', {screen: 'TradeChart'})}>
                      {this.props.name == 'Trade' && (
                        <Image style={{ width: 40, resizeMode: 'contain', marginTop: 10}} source={require('./images/brieficon-active.png')} />
                      )}
                      {this.props.name != 'Trade' && (
                        <Image style={{ width: 30, resizeMode: 'contain', marginTop: 10}} source={require('./images/brieficon.png')} />
                      )}
                      <Text style={{ fontSize: 9, color: '#fff', marginLeft: 'auto', marginRight: 'auto', marginTop: 15 }}>Trade</Text>
                  </TouchableOpacity>
              </View>
          </View>
          <View style={{ flex: 1 }}>
              <View style={{ marginLeft: 'auto', marginRight: 'auto', textAlign: 'center' }}>
                  <TouchableOpacity onPress={() => this.props.navigate('Wallet', {screen: 'Wallet'})}>
                      {this.props.name == 'Wallet' && (
                          <Image style={{ width: 40, resizeMode: 'contain', marginTop: 10}} source={require('./images/walleticon-active.png')} />
                      )}
                      {this.props.name != 'Wallet' && (
                          <Image style={{ width: 40, resizeMode: 'contain', marginTop: 10}} source={require('./images/walleticon.png')} />
                      )}
                      <Text style={{ fontSize: 9, color: '#fff', marginLeft: 'auto', marginRight: 'auto', marginTop: 13 }}>Wallets</Text>
                  </TouchableOpacity>
              </View>
          </View>
      </View>
    );
  }
}
