export const FIATWALLETS = 'wallets/FIATWALLETS';
