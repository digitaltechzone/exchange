import { fetchAPI } from '../../services/api';

const endpoints = {
    fetchFiatWallets: 'fiatwallets',
}

export const fetchFiatWallets = () => fetchAPI(endpoints.fetchFiatWallets, null, 'GET', {}, false, true);
