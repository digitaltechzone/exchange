import * as api from './api';
import * as actionTypes from './actiontypes';

export const fiatWallets = items => ({
    type: actionTypes.FIATWALLETS,
    items
})

export const getFiatWallets = () =>
    dispatch =>
        api.fetchFiatWallets()
            .then(response => dispatch(fiatWallets(response.data))).catch(response => {
            console.log('error 1');
            console.log(response);
        });
