import * as actionTypes from './actiontypes';

const initialState = {
    data: [],
}

export const reducer = (state = initialState, action) => {
    switch(action.type) {
        case actionTypes.FIATWALLETS:
            return {
                ...state,
                data: [
                    ...action.items.data
                ]
            }
        default:
            return state;
    }
}
