import { fetchAPI } from '../../services/api';

const endpoints = {
    fetchWallets: 'wallets',
}

export const fetchWallets = () => fetchAPI(endpoints.fetchWallets, null, 'GET',{}, false, true);
