export const WALLETS = 'wallets/WALLETS';
