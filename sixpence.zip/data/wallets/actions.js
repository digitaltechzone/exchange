import * as api from './api';
import * as actionTypes from './actiontypes';

export const wallets = items => ({
    type: actionTypes.WALLETS,
    items
})

export const getWallets = () =>
    dispatch =>
        api.fetchWallets()
        .then(response => dispatch(wallets(response.data))).catch(response => {
            console.log('error 2');
            console.log(response);
        });
