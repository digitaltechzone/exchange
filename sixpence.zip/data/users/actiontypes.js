export const UPDATE = 'users/UPDATE';
export const EMPTY = 'users/EMPTY';
