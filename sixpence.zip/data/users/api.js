import {fetchAPI} from '../../services/api';

const endpoints = {
  register: 'user/register',
  forgotpassword: 'user/forgotpassword',
  get: 'users',
};

export const register = payload =>
  fetchAPI(endpoints.register, payload, 'POST');
export const forgotpassword = payload =>
  fetchAPI(endpoints.forgotpassword, payload, 'POST');
export const get = payload => fetchAPI(endpoints.get, payload, 'GET');
