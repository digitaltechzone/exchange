import * as api from './api';
import * as actionTypes from './actiontypes';

export const update = items => ({
  type: actionTypes.UPDATE,
  items,
});

export const empty = () => ({
  tyoe: actionTypes.EMPTY,
});

export const get = payload => dispatch =>
  api.get(payload).then(response => dispatch(update(response.users)));
