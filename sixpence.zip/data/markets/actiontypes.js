export const UPDATE = 'markets/UPDATE';
export const TICKERUP = 'markets/TICKERUP';
export const EMPTY = 'markets/EMPTY';