import * as api from './api';
import * as actionTypes from './actiontypes';

export const update = items => ({
  type: actionTypes.UPDATE,
  items,
});

export const tickerUp = items => ({
  type: actionTypes.TICKERUP,
  items,
});

export const empty = () => ({
  type: actionTypes.EMPTY,
});

export const get = () => dispatch =>
  api.fetchMarkets().then(response => {
    console.log("markets fetched");
    dispatch(update(response.data));
  });

/*Promise.all(
                res.map((item, i) => {
                    return api.fetchTickerData(item.market_name)
                    .then(response => {
                        response.data.market = item.market_name;
                        return response.data
                    })
                })
            ).then(tickers => dispatch(tickerUp(tickers)));
            */
