import {fetchAPI} from '../../services/api';

const endpoints = {
  fetchMarkets: 'markets',
  ticker: 'orders/ticker',
};

export const fetchMarkets = () => fetchAPI(endpoints.fetchMarkets, null, 'GET');

export const fetchTickerData = market =>
  fetchAPI(endpoints.ticker, null, 'GET', {market: market});
