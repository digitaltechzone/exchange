import * as actionTypes from './actiontypes';

const initialState = {
    data: [],
    tickers: []
}

export const reducer = (state = initialState, action) => {
    switch(action.type) {
        case actionTypes.UPDATE:
            return {
                ...state,
                data: [
                    ...action.items.data
                ]
            }
        case actionTypes.TICKERUP:
            return {
                ...state,
                tickers: [
                    ...action.items.data
                ]
            }
        case actionTypes.EMPTY:
            return {
                data: [],
                tickers: []
            }
        default:
            return state;
    }
}