import { combineReducers } from 'redux';
import { reducer as usersReducer } from './users/reducer';
import { reducer as ordersReducer } from './orders/reducer';
import { reducer as marketsReducer } from './markets/reducer';
import { reducer as walletsReducer } from './wallets/reducer';
import { reducer as fiatWalletsReducer } from './fiatWallets/reducer';

export const reducer = combineReducers({
    users: usersReducer,
    orders: ordersReducer,
    markets: marketsReducer,
    wallets: walletsReducer,
    fiatWallets: fiatWalletsReducer,
});
