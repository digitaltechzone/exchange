import _ from 'lodash';

import store from '../../store';

export const getBuyOrders = () => {
    const items = store.getState().data.orders.buy;
    if(!_.isEmpty(items)) {
        const itemsArray = Object.keys(items).map(itemKey => items[itemKey]);
        return itemsArray;
    } else {
        return [];
    }
}

export const getSellOrders = () => {
    const items = store.getState().data.orders.sell;
    if(!_.isEmpty(items)) {
        const itemsArray = Object.keys(items).map(itemKey => items[itemKey]);
        return itemsArray;
    } else {
        return [];
    }
}