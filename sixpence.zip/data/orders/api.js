import {fetchAPI} from '../../services/api';

const endpoints = {
  fetchOrders: 'orders/orderbook',
  cancelOrder: 'order/cancel',
  fetchMarketOrder: 'orders',
  buyOrder: 'order/buy',
  sellOrder: 'order/sell',
  buyLimitOrder: 'order/buylimit',
  sellLimitOrder: 'order/selllimit',
  buyStopLimitOrder: 'order/buystoplimit',
  quoteCurrencies: 'qoute-currencies',
  favMarkets: 'user/favorite/markets',
  trendingMarkets: 'trending-markets',
  sellStopLimitOrder: 'order/sellstoplimit',
  balance: 'account/getbalance',
  marketDetail: 'market',
};

export const fetchOrders = (market, type) => {
  console.log('fetchorders1');
  return fetchAPI(
    endpoints.fetchOrders + '?type=' + type + '&market=' + market,
    null,
    'GET',
  );
};
export const fetchOrderBooks = (market, type) => {
  // console.log('fetchorder books1, market: ' + market + ', type: ' + type);

  return fetchAPI(
    'market/' + market + '/orderbook/' + type + '/6',
    null,
    'GET',
  );
};

export const cancelOrder = uuid => {
  // console.log('fetchorder books1, market: ' + market + ', type: ' + type);

  return fetchAPI(endpoints.cancelOrder, {uuid}, 'POST', {}, false, true);
};
export const fetchMarketOrders = (market, type) => {
  console.log('fetchMarketOrders: ' + market + ', type: ' + type);

  return fetchAPI(
    endpoints.fetchMarketOrder + '?status=' + type + '&market=' + market,
    null,
    'GET',
    {},
    false,
    true,
  );
};

export const getMarketHistories = market => {
  console.log('getMarketHistories: ' + market);

  return fetchAPI('market/' + market + '/history/10', null, 'GET', {});
};
export const buyOrder = payload =>
  fetchAPI(endpoints.buyOrder, payload, 'POST');
export const sellOrder = payload =>
  fetchAPI(endpoints.sellOrder, payload, 'POST');
export const createBuyOrder = (quantity, market) =>
  fetchAPI(endpoints.buyOrder, {quantity, market}, 'POST', {}, false, true);
export const createSellOrder = (quantity, market) =>
  fetchAPI(endpoints.sellOrder, {quantity, market}, 'POST', {}, false, true);
export const createBuyLimitOrder = (quantity, rate, market) =>
  fetchAPI(
    endpoints.buyLimitOrder,
    {quantity, rate, market},
    'POST',
    {},
    false,
    true,
  );
export const createSellLimitOrder = (quantity, rate, market) =>
  fetchAPI(
    endpoints.sellLimitOrder,
    {quantity, rate, market},
    'POST',
    {},
    false,
    true,
  );
export const createBuyStopLimitOrder = (
  quantity,
  rate,
  stop_price,
  stop_condition,
  market,
) =>
  fetchAPI(
    endpoints.buyStopLimitOrder,
    {quantity, rate, stop_price, stop_condition, market},
    'POST',
    {},
    false,
    true,
  );

export const getTrendingMarkets = () => {
  return fetchAPI(endpoints.trendingMarkets);
};

export const getQuoteCurrencies = () => {
  return fetchAPI(endpoints.quoteCurrencies);
};
export const getFavMarkets = () => {
  return fetchAPI(endpoints.favMarkets,{},'GET',{},false,true);
};
export const createSellStopLimitOrder = (
  quantity,
  rate,
  stop_price,
  stop_condition,
  market,
) =>
  fetchAPI(
    endpoints.sellStopLimitOrder,
    {quantity, rate, stop_price, stop_condition, market},
    'POST',
    {},
    false,
    true,
  );
export const getBalance = currency =>
  fetchAPI(endpoints.balance, {currency}, 'POST', {}, false, true);
export const getMarketDetail = market =>
  fetchAPI(endpoints.marketDetail + '/' + market, null, 'GET');
