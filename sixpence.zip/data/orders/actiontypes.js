export const UPDATEORDERBOOK = 'orderbooks/UPDATE';


export const UPDATEOPENORDERS = 'orders/UPDATEOPENORDERS';
export const UPDATEQUOTECURRENCIES = 'orders/UPDATEQUOTECURRENCIES';
export const UPDATEFAVMARKETS = 'orders/UPDATEFAVMARKETS';
export const UPDATETRENDINGMARKETS = 'orders/UPDATETRENDINGMARKETS';
export const UPDATEMARKETHISTORY = 'orders/UPDATEMARKETHISTORY';
export const UPDATE = 'orders/UPDATE';
export const EMPTY = 'orders/EMPTY';
export const MARKET = 'orders/MARKET';
export const TYPE = 'orders/TYPE';
export const BASEBALANCE = 'orders/BASEBALANCE';
export const MARKETBALANCE = 'orders/MARKETBALANCE';
export const MARKETDETAIL = 'orders/MARKETDETAIL';
