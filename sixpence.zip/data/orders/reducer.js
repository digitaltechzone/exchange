import * as actionTypes from './actiontypes';

const initalState = {
  market: '',
  marketDetail: [],
  type: 'both',
  balance: {
    base: 0.0,
    market: 0.0,
  },
  market_histories: [],
  orderbook_buy: [],
  orderbook_sell: [],
  trending_markets: [],
  open_orders: [],
  quote_currencies: [],
  fav_markets: [],
};

export const reducer = (state = initalState, action) => {
  switch (action.type) {
    case actionTypes.UPDATE:
      console.log('action type', action.type);
      console.log(initalState, action);
      return {
        ...state,
        buy: [...action.items.data.buy],
        sell: [...action.items.data.sell],
      };
    case actionTypes.UPDATEORDERBOOK:
      return {
        ...state,
        orderbook_buy: [...action.items.data.buy],
        orderbook_sell: [...action.items.data.sell],
      };
    case actionTypes.UPDATEOPENORDERS:
      return {
        ...state,
        open_orders: [...action.items.data],
      };
    case actionTypes.UPDATETRENDINGMARKETS:
      return {
        ...state,
        trending_markets: [...action.items.data],
      };
    case actionTypes.UPDATEQUOTECURRENCIES:
      return {
        ...state,
        quote_currencies: [...action.items.data],
      };
    case actionTypes.UPDATEMARKETHISTORY:
      return {
        ...state,
        market_histories: [...action.items.data],
      };
    case actionTypes.UPDATEFAVMARKETS:
      return {
        ...state,
        fav_markets: [...action.items.data],
      };
    case actionTypes.BASEBALANCE:
      return {
        ...state,
        balance: {
          base: action.balance,
          market: state.balance.market,
        },
      };
    case actionTypes.MARKETBALANCE:
      return {
        ...state,
        balance: {
          base: state.balance.base,
          market: action.balance,
        },
      };
    case actionTypes.MARKET:
      return {
        ...state,
        market: action.market,
      };
    case actionTypes.TYPE:
      return {
        ...state,
        type: action.orderType,
      };
    case actionTypes.EMPTY:
      return {
        buy: [],
        sell: [],
      };
    case actionTypes.MARKETDETAIL:
      return {
        ...state,
        marketDetail: action.marketDetail.data,
      };
    default:
      return state;
  }
};
