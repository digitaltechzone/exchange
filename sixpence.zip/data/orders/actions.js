import * as api from './api';
import * as actionTypes from './actiontypes';

export const update = items => ({
  type: actionTypes.UPDATE,
  items,
});

export const orderbooks = items => ({
  type: actionTypes.UPDATEORDERBOOK,
  items,
});
export const updateTrendingMarkets = items => ({
  type: actionTypes.UPDATETRENDINGMARKETS,
  items,
});
export const updateQuoteCurrencies = items => ({
  type: actionTypes.UPDATEQUOTECURRENCIES,
  items,
});

export const updateFavMarkets = items => ({
  type: actionTypes.UPDATEFAVMARKETS,
  items,
});

export const openorders = items => ({
  type: actionTypes.UPDATEOPENORDERS,
  items,
});

export const markethistories = items => ({
  type: actionTypes.UPDATEMARKETHISTORY,
  items,
});

export const empty = () => ({
  type: actionTypes.EMPTY,
});

export const market = market => ({
  type: actionTypes.MARKET,
  market,
});

export const orderType = orderType => ({
  type: actionTypes.TYPE,
  orderType,
});

export const baseBalance = balance => ({
  type: actionTypes.BASEBALANCE,
  balance,
});

export const marketBalance = balance => ({
  type: actionTypes.MARKETBALANCE,
  balance,
});

export const marketDetail = marketDetail => ({
  type: actionTypes.MARKETDETAIL,
  marketDetail,
});

export const buy = (quantity, market) => dispatch =>
  api.createBuyOrder(quantity, market);

export const sell = (quantity, market) => dispatch =>
  api.createSellOrder(quantity, market);

export const buyLimit = (quantity, rate, market) => dispatch =>
  api.createBuyLimitOrder(quantity, rate, market);

export const sellLimit = (quantity, rate, market) => dispatch =>
  api.createSellLimitOrder(quantity, rate, market);

export const buyStopLimit =
  (quantity, rate, stop_price, stop_condition, market) => dispatch =>
    api.createBuyStopLimitOrder(
      quantity,
      rate,
      stop_price,
      stop_condition,
      market,
    );

export const sellStopLimit =
  (quantity, rate, stop_price, stop_condition, market) => dispatch =>
    api.createSellStopLimitOrder(
      quantity,
      rate,
      stop_price,
      stop_condition,
      market,
    );

export const balance = (market, wallet, fiatWallet, type = 0) => {
  // Type: 0 - base, 1 - market
  let split = market.split('-', 2);

  const base = split[type];
  let searchWalletType = base;

  let walletInfo = wallet.data.filter(
    (value, index) => value.currency == searchWalletType,
  );
  let balance = 0;
  if (walletInfo.length === 0) {
    walletInfo = fiatWallet.data.filter(
      (value, index) => value.currency == searchWalletType,
    );
  }

  walletInfo = walletInfo[0];
  balance = walletInfo.total_balance.toFixed(2);

  return dispatch => {
    if (type == 0) {
      dispatch(marketBalance(balance));
    } else {
      dispatch(baseBalance(balance));
    }
  };
};

export const get =
  (market, type = 'both') =>
  dispatch =>
    api
      .fetchOrders(market, type)
      .then(response => dispatch(update(response.data)))
      .catch(response => {
        console.log('error 22');
        console.log(response);
      });

export const getMarketDetail = market => dispatch =>
  api
    .getMarketDetail(market)
    .then(response => dispatch(marketDetail(response.data)))
    .catch(err => {
      console.log('err');
      console.log(err);
    });

export const getOrderBook =
  (market, type = 'both') =>
  dispatch =>
    api
      .fetchOrderBooks(market, type)
      .then(response => {
        dispatch(orderbooks(response.data));
      })
      .catch(err => {
        console.log('err getorderbook');
        console.log(err);
      });

export const getMarketHistories = market => dispatch =>
  api
    .getMarketHistories(market)
    //.then(response => console.log("dispatchdata:",response.data.data))
    .then(response => dispatch(markethistories(response.data)))
    .catch(err => {
      console.log('err history');
      console.log(err);
    });

export const getOrders =
  (market, type = 'open') =>
  dispatch =>
    api
      .fetchMarketOrders(market, type)
      .then(response => dispatch(openorders(response.data)))
      .catch(response => {
        console.log('error 222 1');
        console.log(response);
      });

export const cancelOrder = uuid => dispatch =>
  api.cancelOrder(uuid).catch(response => {
    console.log('error 222 2');
    console.log(response);
  });
export const getTrendingMarkets =  () => dispatch =>
  api.getTrendingMarkets().then(response => {
    console.log("gettrending response",response.data);
   dispatch(updateTrendingMarkets(response.data));
  });
export const getQuoteCurrencies =  () => dispatch =>
  api.getQuoteCurrencies().then(response => {
    console.log("get quote response",response.data);
   dispatch(updateQuoteCurrencies(response.data));
  });
export const getFavMarkets =  () => dispatch =>
  api.getFavMarkets().then(response => {
    console.log("get getFavMarkets response",response);
   dispatch(updateFavMarkets(response));
  });
