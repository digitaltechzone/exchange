import React from 'react';
import {Container, Spinner, View, Text} from 'native-base';

class Loading extends React.Component {
  constructor() {
    super();
    this.state = {};
  }

  render() {
    return (
      <Container style={styles.background}>
        <View style={styles.container}>
          <Spinner color="#ef6048" />
          <Text style={styles.caption}>LOADING</Text>
        </View>
      </Container>
    );
  }
}

const styles = {
  background: {
    backgroundColor: '#000',
  },
  container: {
    alignItems: 'center',
    flexGrow: 1,
    justifyContent: 'center',
  },
  caption: {
    color: '#27ae60',
  },
};

export default Loading;
