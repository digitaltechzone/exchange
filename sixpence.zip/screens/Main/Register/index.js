import React from 'react';
import {
    StyleSheet,
    ScrollView,
    Image
} from 'react-native';
import {
    Container,
    Title,
    Button,
    View,
    Text,
    Item,
    Input,
    Form,
    Label,
    Content,
    CheckBox,
    Body,
    ListItem,
    Toast
} from 'native-base';
import Hyperlink from 'react-native-hyperlink';

// Compoennts
import Loading from '../Loading';
import { Banner, Wrapper, TopNavigationBar } from '../../../static';

// Importing custom packages
import * as usersAPI from '../../../data/users/api';
import * as session from '../../../services/session';
import * as API from '../../../services/api';

class Register extends React.Component {
    constructor() {
        super();
        this.state = {
            checkedTerms: false,
            error: null,
            email: '',
            password: '',
            password_confirmation: '',
            loading: false,
            showToast: false
        }

        this.checkTheBox = this.checkTheBox.bind(this);
        this.triggerRegister = this.triggerRegister.bind(this);
    }

    // Checking the box
    checkTheBox() {
        let opposite = !(this.state.checkedTerms);
        this.setState({checkedTerms: opposite});
    }

    // Register trigger
    triggerRegister() {
        const { email, password, password_confirmation } = this.state;

        usersAPI.register({ email, password, password_confirmation })
        .then(this.handleRegisterSuccess.bind(this))
        .catch(this.handleRegisterError.bind(this));
    }


    // Handling the register success
    handleRegisterSuccess = response => {
        // Showing the sucessfull registration toast
        Toast.show({
            text: 'Sucessfully registered!',
            position: 'top',
            buttonText: 'X',
            type: 'success'
        })
    }

    // Handling the register error
    handleRegisterError = error => {
        let errors = error.response.data.errors;
        let string = "";

        // Itterating through errors object
        for (var key in errors) {
            var value = errors[key][0];
            string += value + "\n";
        }

        this.setState({
            showToast: true
        })

        // SHowign the toast with errors
        Toast.show({
            text: string,
            position: 'top',
            buttonText: 'X',
            type: 'danger'
        })

        // Stop spinner
        this.setState({
            loading: false
        });
    }

    render() {
        const { navigate } = this.props.navigation;
        return (
            <ScrollView style={styles.background}>
                {
                    this.state.loading
                    &&
                    <Loading />
                }
                {
                    !this.state.loading
                    &&
                    <ScrollView>
                        {/* <Banner /> */}
                        <TopNavigationBar name="Register" />
                        <View style={styles.topLogoBackground}>
                            <Image style={{marginTop: 30}} source={require('../../../static/images/kriptoist.png')} />
                        </View>
                        <View style={{marginTop: 30}} heading={'Signup to Kriptoist'}>
                            <View style={styles.formgroup}>
                                <Form>
                                    <Text style={{color: '#fff', fontSize: 13}}>Email</Text>
                                    <Item regular style={{marginTop: 5, borderColor: 'transparent'}}>
                                        <Input style={styles.inputfield}
                                                placeholder="E-mail address"
                                                onChangeText={(text) => this.setState({email: text})}/>
                                    </Item>
                                    <Text style={{marginTop: 15, color: '#fff', fontSize: 13}}>Password</Text>
                                    <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                                        <Input style={styles.inputfield}
                                                secureTextEntry={true}
                                                placeholder="Password"
                                                onChangeText={(text) => this.setState({password: text})}/>
                                    </Item>
                                    <Text style={{marginTop: 15, color: '#fff', fontSize: 13}}>Re-Password</Text>
                                    <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                                        <Input style={styles.inputfield}
                                                secureTextEntry={true}
                                                placeholder="Password repeat"
                                                onChangeText={(text) => this.setState({password_confirmation: text})}/>
                                    </Item>
                                    <ListItem style={styles.checkbox}>
                                        <CheckBox style={{ borderColor: '#fff', position: 'absolute'}}
                                                    checked={this.state.checkedTerms}
                                                    onPress={this.checkTheBox}/>
                                        {/* <Body>
                                            <Hyperlink onPress={() => navigate('Terms', {screen: 'Terms'})}
                                                        linkStyle={{ color: '#27ae60'}}
                                                        linkText={ url => url === 'https://kriptoist.com/#/terms' ? 'Terms of Service' : url }>
                                                <Text style={{ fontSize: 14 }}>I agree to the https://kriptoist.com/#/terms</Text>
                                            </Hyperlink>
                                        </Body> */}
                                        <Text style={styles.textType3}>
                                            I agree to CCX Terms of use
                                        </Text>
                                    </ListItem>
                                    <Button block style={[styles.button, styles.orange]}
                                        onPress={this.triggerRegister}>
                                        <Text>Sign up</Text>
                                    </Button>
                                    <Text onPress={() =>
                                        navigate('Login', {screen: 'Login'})
                                    } style={styles.textType3}>
                                        Already registered? Login
                                    </Text>
                                </Form>
                            </View>
                        </View>

                        {/* <View style={{ paddingLeft: 45, paddingRight: 45, paddingBottom: 45 }}>
                            <Button bordered block light style={[styles.button, styles.green]}
                                    onPress={() => navigate('Main', {screen: 'Main'})}>
                                <Text>Back</Text>
                            </Button>
                        </View> */}
                    </ScrollView>
                }
                <View style={{height:200}} />
            </ScrollView>
        );
    }
}

// Styles
const styles = StyleSheet.create({
    background: {
        backgroundColor: '#000'
    },
    container: {
        alignItems: 'center',
        flexGrow: 1,
        justifyContent: 'center',
    },
    logo: {
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        width: 300,
        height: 100,
    },
    logoText: {
        color: '#fefefe',
        fontSize: 36,
    },
    smallText: {
        color: '#fefefe',
        fontSize: 18
    },
    button: {
        marginTop: 15,
        textAlign: 'center',
        borderRadius: 48
    },
    formgroup: {
        padding: 15,
    },
    inputfield: {
        padding: 15,
        paddingLeft: 15,
        paddingRight: 15,
        fontSize: 13,
        backgroundColor: '#222222',
        borderColor: '#222222',
        borderRadius: 6,
    },
    checkbox: {
        marginTop: 15,
        marginLeft: 0
    },
    whiteText: {
        color: '#fefefe'
    },
    orange: {
        backgroundColor: '#FFAB00'
    },
    green: {
        backgroundColor: '#27ae60'
    },
    topLogoBackground: {
        textAlign: 'center',
        marginLeft: 'auto',
        marginRight: 'auto',
        marginTop: 20
    },
    textType3: {
        fontSize: 14,
        color: '#fff',
        marginTop: 30,
        marginLeft: 'auto',
        marginRight: 'auto',
        textAlign: 'center'
    },
    textType2: {
        fontSize: 14,
        color: '#fff',
        marginTop: 20,
        marginLeft: 'auto',
        marginRight: 'auto',
        textAlign: 'center'
    },
});

export default Register;
