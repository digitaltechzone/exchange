import React from 'react';
import PropTypes from 'prop-types';
import {StyleSheet, Image, ImageBackground, Dimensions, ScrollView} from 'react-native';
import {Container, Header, Title, Button, View, Text} from 'native-base';

// Including images
import {Banner, Wrapper} from '../../static';

// Declaring the styles of this objects
const styles = StyleSheet.create({
  background: {
    backgroundColor: '#000',
  },
  container: {
    alignItems: 'center',
    flexGrow: 1,
    justifyContent: 'center',
  },
  logo: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    width: 300,
    height: 100,
  },
  logoText: {
    color: '#fefefe',
    fontSize: 36,
  },
  button: {
    marginBottom: 15,
    textAlign: 'center',
    borderRadius: 48
  },
  buttonText: {
    textAlign: 'center',
  },
  buttonGroup: {
    padding: 20,
  },
  wrapper: {
    backgroundColor: '#fefefe',
    padding: 15,
    margin: 15,
    marginTop: 200,
  },
  orange: {
    backgroundColor: '#ef5e47',
  },
  green: {
    backgroundColor: '#27ae60',
  },
  btnAsh: {
    backgroundColor: '#333333'
  },
  btnBlue: {
    backgroundColor: '#008BF8'
  },
  topLogoBackground: {
    backgroundColor: '#000',
    width: 200,
    height: 200,
    borderRadius: 200/2,
    textAlign: 'center',
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20
  },
  textMiddleSection: {
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20,
    color: '#fec900'
  },
  textType1: {
    fontSize: 25,
    color: '#fff',
    fontWeight: 'bold',
    marginLeft: 'auto',
    marginRight: 'auto'
  },
  textType2: {
    fontSize: 14,
    color: '#fff',
    marginTop: 10,
    marginLeft: 'auto',
    marginRight: 'auto',
    width: 300,
    textAlign: 'center'
  },
  textType3: {
    fontSize: 14,
    color: '#FFAB00',
    marginTop: 30,
    marginLeft: 'auto',
    marginRight: 'auto',
    textAlign: 'center'
  },
  cardType1: {
    marginTop: 25,
    marginBottom: 50,
    backgroundColor: '#222222',
    padding: 15,
    margin: 15,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  }
});

// Get the dimensions
const {width, height} = Dimensions.get('window');

class Main extends React.Component {
  render() {
    const {navigate} = this.props.navigation;
    return (
      <ScrollView style={styles.background}>
        <Container style={styles.background}>
          <View style={styles.topLogoBackground}>
            <Image style={{marginLeft: -50, width: width * 0.85, resizeMode: 'contain'}} source={require('../../static/images/monsy_logo.png')} />
          </View>
          <View style={styles.textMiddleSection}>
            <Text style={styles.textType1}>
              Welcome to CCX
            </Text>
            <Text style={styles.textType1}>
              Official App
            </Text>
            <Text style={styles.textType2}>
              To Authorize the app, login to CCX and get started.
            </Text>
          </View>
          {/* <Banner /> */}
          <View style={styles.cardType1} heading={'Welcome to CCX!'}>
            <View style={styles.buttonGroup}>
              <Button
                block
                style={[styles.button, styles.btnBlue]}
                onPress={() => navigate('Login', {screen: 'Login'})}>
                  <Image style={{width: 40, resizeMode: 'contain'}} source={require('../../static/images/facebook.png')} />
                  <Text>Login with Facebook</Text>
              </Button>
              <Button
                block
                style={[styles.button, styles.orange]}
                onPress={() => navigate('Login', {screen: 'Login'})}>
                  <Image style={{width: 40, resizeMode: 'contain'}} source={require('../../static/images/google.png')} />
                  <Text>Login with Google</Text>
              </Button>
              <Button
                block
                style={[styles.button, styles.btnAsh]}
                onPress={() => navigate('Login', {screen: 'Login'})}>
                  <Image style={{width: 40, resizeMode: 'contain'}} source={require('../../static/images/apple.png')} />
                  <Text>Login with Apple</Text>
              </Button>
              {/* <Button
                block
                style={[styles.green]}
                onPress={() => navigate('Register', {screen: 'Register'})}>
                <Text>Register</Text>
              </Button> */}
              <Text onPress={() => navigate('Login', {screen: 'Login'})} style={styles.textType3}>
                Login As Guest
              </Text>
            </View>
          </View>
        </Container>
        <View style={{height:200}} />
      </ScrollView>
    );
  }
}

export default Main;
