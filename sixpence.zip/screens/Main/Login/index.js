import React from 'react';
import {StyleSheet, ScrollView, Image} from 'react-native';
import {
  Container,
  Title,
  Button,
  View,
  Text,
  Item,
  Input,
  Form,
  Label,
  Toast,
} from 'native-base';
import Icon from 'react-native-fa-icons';
import get from 'lodash/get';

// Compoennts
import Loading from '../Loading';
import {Banner, Wrapper, TopNavigationBar} from '../../../static';

// Importing custom packages
import * as usersAPI from '../../../data/users/api';
import * as session from '../../../services/session';
import * as API from '../../../services/api';

class Login extends React.Component {
  constructor() {
    super();

    this.state = {
      email: '',
      password: '',
      error: null,
      loading: false,
      showToast: false,
    };

    this.triggerLogin = this.triggerLogin.bind(this);
  }

  // Trigger the login on button press
  triggerLogin() {
    const {email, password} = this.state;

    // Start the spinner
    this.setState({
      loading: true,
    });

    session
      .authenticate(this.state.email, this.state.password)
      .then(this.handleLoginSuccess.bind(this))
      .catch(this.handleLoginError.bind(this));
  }

  handleLoginSuccess = response => {
    // Redirect to protected area
    Toast.show({
      text: 'Sucessfully logged in!',
      position: 'top',
      buttonText: 'X',
      type: 'success',
    });
  };

  handleLoginError = error => {
    console.log('Login error -------');
    console.log(error);

    // Fetching errors and preparing error string
    let string = '';

    // Iterating through errors object
    if (error.response.status !== 403) {
      string += error.response.data.message;
    } else {
      string +=
        'New IP is detected. Please verify your IP address via the link sent to your e-mail.';
    }

    this.setState({
      showToast: true,
    });

    // SHowign the toast with errors
    Toast.show({
      text: string,
      position: 'top',
      buttonText: 'X',
      type: 'danger',
    });

    // Stop spinner
    this.setState({
      loading: false,
    });
  };

  render() {
    const {navigate} = this.props.navigation;
    return (
      <ScrollView style={styles.background}>
        {this.state.loading && <Loading />}
        {!this.state.loading && (
          <Container style={styles.background}>
            {/* <Banner /> */}
            <TopNavigationBar name="Login" />
            <View style={styles.topLogoBackground}>
              <Image style={{marginTop: 30, width: 250, resizeMode: 'contain'}} source={require('../../../static/images/kriptoist.png')} />
            </View>
            <View style={{marginTop: 30}}>
              <View style={styles.formgroup}>
                <Form>
                  <Text style={{color: '#fff', fontSize: 13}}>Email</Text>
                  <Item regular style={{marginTop: 5, borderColor: 'transparent'}}>
                    <Input
                      style={styles.inputfield}
                      placeholder="E-mail Address"
                      onChangeText={text => this.setState({email: text})}
                    />
                  </Item>
                  <Text style={{marginTop: 15,color: '#fff', fontSize: 13}}>Password</Text>
                  <Item regular style={{marginTop: 5, position: 'relative', borderColor: 'transparent'}}>
                    {/* <Image style={{marginTop: 30, float: 'left'}} source={require('../../../static/images/lock.png')} /> */}
                    <Input
                      style={styles.inputfield}
                      secureTextEntry={true}
                      placeholder="Password"
                      onChangeText={text => this.setState({password: text})}
                    />
                  </Item>
                  <Button
                    block
                    style={[styles.button, styles.orange]}
                    onPress={this.triggerLogin}>
                    <Text>Login</Text>
                  </Button>
                  <Text onPress={() =>
                    navigate('ResetPassword', {screen: 'ResetPassword'})
                  } style={styles.textType3}>
                    Forgot your password?
                  </Text>
                  <Text onPress={() =>
                    navigate('Register', {screen: 'Register'})
                  } style={styles.textType2}>
                    Don't have an account? Sign Up
                  </Text>
                </Form>
              </View>
            </View>

            {/* <View
              style={{paddingLeft: 45, paddingRight: 45, paddingBottom: 45}}>
              <Button
                bordered
                block
                light
                style={[styles.button, styles.green]}
                onPress={() => navigate('Main', {screen: 'Main'})}>
                <Text>Back</Text>
              </Button>
              <Button
                transparent
                block
                info
                style={styles.button}
                onPress={() =>
                  navigate('ResetPassword', {screen: 'ResetPassword'})
                }>

                <Text>Forgot your password?</Text>
              </Button>
            </View> */}
          </Container>
        )}
        <View style={{height:200}} />
      </ScrollView>
    );
  }
}

// Declaring the styles of this objects
const styles = StyleSheet.create({
  background: {
    backgroundColor: '#000000',
  },
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: {
    color: '#fefefe',
    fontSize: 36,
  },
  smallText: {
    color: '#fefefe',
    fontSize: 18,
  },
  button: {
    marginTop: 35,
    textAlign: 'center',
    borderRadius: 48
  },
  formgroup: {
    padding: 15,
  },
  inputfield: {
    padding: 15,
    paddingLeft: 15,
    paddingRight: 15,
    fontSize: 13,
    backgroundColor: '#222222',
    borderColor: '#222222',
    borderRadius: 6,
    color: '#fff'
  },
  toast: {
    marginBottom: 20,
  },
  orange: {
    backgroundColor: '#FFAB00',
  },
  green: {
    backgroundColor: '#27ae60',
  },
  topLogoBackground: {
    textAlign: 'center',
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20
  },
  textType3: {
    fontSize: 14,
    color: '#FFAB00',
    marginTop: 30,
    marginLeft: 'auto',
    marginRight: 'auto',
    textAlign: 'center'
  },
  textType2: {
    fontSize: 14,
    color: '#fff',
    marginTop: 20,
    marginLeft: 'auto',
    marginRight: 'auto',
    textAlign: 'center'
  },
});

// Exporting the screen
export default Login;
