import React from 'react';
import {StyleSheet, ScrollView} from 'react-native';
import {
  Container,
  Title,
  Button,
  View,
  Text,
  Item,
  Input,
  Form,
  Label,
  Content,
  CheckBox,
  Body,
  Toast,
} from 'native-base';

import Loading from '../../Loading';
import {Banner, Wrapper} from '../../../../static';

import * as session from '../../../../services/session';
import * as API from '../../../../services/api';

class TwoFA extends React.Component {
  constructor() {
    super();
    this.state = {
      otp: '',
      loading: false,
      showToast: false,
    };

    this.triggerOtp = this.triggerOtp.bind(this);
  }

  triggerOtp() {
    const {otp} = this.state;

    // Start the spinner
    this.setState({
      loading: true,
    });

    session
      .verify2FA(this.state.otp)
      .then(this.handle2FASuccess.bind(this))
      .catch(this.handle2FAError.bind(this));
  }

  handle2FASuccess = response => {
    Toast.show({
      text: 'Successfully authenticated!',
      position: 'top',
      buttonText: 'X',
      type: 'success',
    });
  };

  handle2FAError = error => {
    console.log('2fa error -------');
    console.log(error);
    let string = '';

    if (this.state.otp.length !== 6) {
      string = 'Onetime password needs to have 6 characters.';
    } else {
      string = 'Unable to verify this one time password.';
    }

    this.setState({
      showToast: true,
    });

    // SHowign the toast with errors
    Toast.show({
      text: string,
      position: 'top',
      buttonText: 'X',
      type: 'danger',
    });

    // Stop spinner
    this.setState({
      loading: false,
    });
  };

  render() {
    return (
      <ScrollView style={styles.background}>
        {this.state.loading && <Loading />}
        {!this.state.loading && (
          <Container>
            <Banner />
            <Wrapper heading="Two factor authentication">
              <View style={styles.formgroup}>
                <Form>
                  <Item regular>
                    <Input
                      style={styles.inputfield}
                      placeholder={'Enter one time password'}
                      onChangeText={text => this.setState({otp: text})}
                    />
                  </Item>
                  <Button
                    block
                    style={[styles.button, styles.orange]}
                    onPress={this.triggerOtp}>
                    <Text>Confirm</Text>
                  </Button>
                </Form>
              </View>
            </Wrapper>
          </Container>
        )}
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  background: {
    backgroundColor: '#eeeeee',
    flex: 1,
  },
  container: {
    alignItems: 'center',
    flexGrow: 1,
    justifyContent: 'center',
  },
  logo: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    width: 300,
    height: 100,
  },
  logoText: {
    color: '#fefefe',
    fontSize: 36,
  },
  smallText: {
    color: '#fefefe',
    fontSize: 18,
  },
  button: {
    marginTop: 15,
  },
  formgroup: {
    padding: 20,
  },
  inputfield: {
    padding: 15,
    paddingLeft: 15,
    paddingRight: 15,
    fontSize: 13,
  },
  orange: {
    backgroundColor: '#ef5e47',
  },
  green: {
    backgroundColor: '#27ae60',
  },
});

export default TwoFA;
