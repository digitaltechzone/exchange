import React from 'react';
import {
    StyleSheet,
    ScrollView
} from 'react-native';
import {
    Container,
    Title,
    Button,
    View,
    Body,
    Text,
    Item,
    Card,
    CardItem
} from 'native-base';

import { Banner, Wrapper } from '../../../static';

class Terms extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }

    render() {
        const { navigate } = this.props.navigation;
        return (
            <ScrollView style={styles.background}>
                <Banner />
                <Wrapper heading={'Terms and Conditions'}>
                    <View style={styles.textContainer}>
                        <Text style={styles.termsContent}>
                            { termsText }
                            ~{'\n'}
                            { termsText }
                        </Text>
                    </View>
                </Wrapper>
                <View style={{ paddingLeft: 45, paddingRight: 45, paddingBottom: 45 }}>
                    <Button block style={[styles.button, styles.green]}
                            onPress={() => navigate('Register', {screen: 'Register'})}>
                        <Text>Back</Text>
                    </Button>
                </View>
            </ScrollView>
        )
    }
}

const termsText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris pretium tincidunt convallis. Aliquam erat volutpat. Mauris pharetra, est nec accumsan pulvinar, quam enim gravida ligula, at scelerisque lorem sem vitae lacus. Maecenas a venenatis risus. Sed in lacus ut quam tristique congue. Nulla facilisi. Sed interdum porttitor ex, sit amet commodo ligula venenatis a. Ut consequat ipsum at urna dictum iaculis. Sed ex metus, varius nec mauris in, blandit laoreet leo.";

const styles = StyleSheet.create({
    background: {
        backgroundColor: '#eeeeee'
    },
    container: {
        alignItems: 'center',
        flexGrow: 1,
        justifyContent: 'center',
    },
    heading: {
        color: '#fefefe',
        fontSize: 20,
        borderBottomColor: '#d5d5d5',
        borderBottomWidth: 1,
        paddingBottom: 20,
        marginBottom: 20
    },
    whiteText: {
        color: '#fefefe',
        fontSize: 13,
        lineHeight: 20,
        borderBottomColor: '#d5d5d5',
        borderBottomWidth: 1,
        paddingBottom: 20
    },
    termsContent: {
        fontSize: 13,
        color: '#9c9d9e'
    },
    textContainer: {
        margin: 15
    },
    orange: {
        backgroundColor: '#ef5e47'
    },
    green: {
        backgroundColor: '#27ae60'
    },
    button: {
        marginTop: 15
    }
});

export default Terms;
