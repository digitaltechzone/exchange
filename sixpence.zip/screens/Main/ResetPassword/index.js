import React from 'react';
import {StyleSheet, ScrollView, Image} from 'react-native';
import {
  Container,
  Title,
  Button,
  View,
  Text,
  Item,
  Input,
  Form,
  Label,
  Content,
  CheckBox,
  Body,
  Toast,
} from 'native-base';

import Loading from '../Loading';
import {Banner, Wrapper, TopNavigationBar} from '../../../static';

import * as usersAPI from '../../../data/users/api';
import * as API from '../../../services/api';

class ResetPassword extends React.Component {
  constructor() {
    super();
    this.state = {
      email: '',
      loading: false,
      showToast: false,
    };

    this.triggerForgot = this.triggerForgot.bind(this);
  }

  triggerForgot() {
    const {email} = this.state;

    // Start the spinner
    this.setState({
      loading: true,
    });

    usersAPI
      .forgotpassword({email})
      .then(this.handleForgotSuccess.bind(this))
      .catch(this.handleForgotError.bind(this));
  }

  handleForgotSuccess = response => {
    this.setState({
      showToast: true,
      loading: false,
    });

    Toast.show({
      text: 'Reset password successful. An e-mail has been sent to you.',
      position: 'top',
      buttonText: 'X',
      type: 'success',
    });
  };

  handleForgotError = error => {
    let errors = error.response.data.errors;
    let string = '';

    console.log(error.response);

    // Itterating through errors object
    for (var key in errors) {
      var value = errors[key][0];
      string += value + '\n';
    }

    this.setState({
      showToast: true,
    });

    // SHowign the toast with errors
    Toast.show({
      text: string,
      position: 'top',
      buttonText: 'X',
      type: 'danger',
    });

    // Stop spinner
    this.setState({
      loading: false,
    });
  };

  render() {
    const {navigate} = this.props.navigation;

    return (
      <ScrollView style={styles.background}>
        {this.state.loading && <Loading />}
        {!this.state.loading && (
          <Container style={styles.background}>
            {/* <Banner /> */}
            <TopNavigationBar name="Reset Password" />
            <View style={styles.topLogoBackground}>
                <Image style={{marginTop: 30}} source={require('../../../static/images/kriptoist.png')} />
            </View>
            <View heading={'Reset your password'}>
              <View style={styles.formgroup}>
                <Form>
                  <Text style={{marginTop: 15, color: '#fff', fontSize: 13}}>Password</Text>
                  <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                    <Input
                      style={styles.inputfield}
                      placeholder={'E-mail address'}
                      onChangeText={text => this.setState({email: text})}
                    />
                  </Item>
                  <Button
                    block
                    style={[styles.button, styles.orange]}
                    onPress={this.triggerForgot}>
                    <Text>Reset password</Text>
                  </Button>
                </Form>
              </View>
            </View>
            {/* <View
              style={{paddingLeft: 45, paddingRight: 45, paddingBottom: 45}}>
              <Button
                bordered
                block
                light
                style={[styles.button, styles.green]}
                onPress={() => navigate('Login', {screen: 'Login'})}>
                <Text>Back</Text>
              </Button>
            </View> */}
          </Container>
        )}
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  background: {
    backgroundColor: '#000',
  },
  container: {
    alignItems: 'center',
    flexGrow: 1,
    justifyContent: 'center',
  },
  logo: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    width: 300,
    height: 100,
  },
  logoText: {
    color: '#fefefe',
    fontSize: 36,
  },
  smallText: {
    color: '#fefefe',
    fontSize: 18,
  },
  button: {
    marginTop: 35,
    textAlign: 'center',
    borderRadius: 48
  },
  formgroup: {
    padding: 15,
  },
  inputfield: {
    padding: 15,
    paddingLeft: 15,
    paddingRight: 15,
    fontSize: 13,
    backgroundColor: '#222222',
    borderColor: '#222222',
    borderRadius: 6,
  },
  orange: {
    backgroundColor: '#FFAB00',
  },
  green: {
    backgroundColor: '#27ae60',
  },
  topLogoBackground: {
    textAlign: 'center',
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20
  },
});

export default ResetPassword;
