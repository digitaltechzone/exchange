import React from 'react';
import {
  StyleSheet,
  ScrollView,
  Image,
  ImageBackground,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import {
  Container,
  Title,
  Button,
  View,
  Text,
  Item,
  Input,
  Form,
  Label,
  Content,
  CheckBox,
  Body,
  Toast,
  List,
  ListItem,
} from 'native-base';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import Loading from '../../../Main/Loading';
import {
  Banner,
  Wrapper,
  TopProtectedNavigationBar,
  BottomProtectedNavigationBar,
} from '../../../../static';
import * as walletsActionCreators from '../../../../data/wallets/actions';
import * as fiatWalletsActionCreators from '../../../../data/fiatWallets/actions';
import * as ordersActionCreators from '../../../../data/orders/actions';
import * as marketsActionCreators from '../../../../data/markets/actions';

import * as usersAPI from '../../../../data/users/api';
import * as API from '../../../../services/api';

const mapStateToProps = state => {
  return {
    wallets: state.data.wallets,
    fiatWallets: state.data.fiatWallets,
    markets: state.data.markets,
    orders: state.data.orders,
  };
};
const mapDispatchToComponent = dispatch => ({
  actions: {
    wallets: bindActionCreators(walletsActionCreators, dispatch),
    fiatWallets: bindActionCreators(fiatWalletsActionCreators, dispatch),
    orders: bindActionCreators(ordersActionCreators, dispatch),
    markets: bindActionCreators(marketsActionCreators, dispatch),
  },
});

class Markets extends React.Component {
  constructor() {
    super();
    this.state = {
      email: '',
      loading: false,
      showToast: false,
      activeTab: 'spot',
      activeQuoteCurrency: 'BTC',
    };

    this.changeTab = this.changeTab.bind(this);
    this.changeTabFavourite = this.changeTabFavourite.bind(this);
  }

  componentDidMount() {
    // console.log("markets before;",this.props.markets.data);
    this.props.actions.orders.getQuoteCurrencies();
    this.props.actions.orders.getFavMarkets();
  }

  changeTab() {
    this.setState({
      activeTab: 'spot',
    });
  }

  selectQuote(quote) {
    this.setState({
      activeQuoteCurrency: quote,
    });
  }

  changeTabFavourite() {
    this.setState({
      activeTab: 'favourite',
    });
  }

  render() {
    const {navigate} = this.props.navigation;
    const markets = this.props.markets.data;
    const {quote_currencies, fav_markets} = this.props.orders;
    console.log("fav markets:",fav_markets);
    return (
      <ScrollView style={styles.background}>
        {this.state.loading && <Loading />}
        {!this.state.loading && (
          <Container style={styles.background}>
            {/* <Banner /> */}
            <TopProtectedNavigationBar navigate={navigate} name="Markets" />

            <View
              style={{
                backgroundColor: '#222222',
                flexDirection: 'row',
                marginTop: 2,
              }}>
              <View style={{flex: 1}}>
                <View
                  style={[
                    this.state.activeTab == 'favourite'
                      ? styles.pageTabSectionActive
                      : styles.pageTabSection,
                  ]}>
                  <Text
                    onPress={this.changeTabFavourite}
                    style={[
                      this.state.activeTab == 'favourite'
                        ? styles.pageTabTextActive
                        : styles.pageTabText,
                    ]}>
                    Favourites
                  </Text>
                </View>
              </View>
              <View style={{flex: 1}}>
                <View
                  style={[
                    this.state.activeTab == 'spot'
                      ? styles.pageTabSectionActive
                      : styles.pageTabSection,
                  ]}>
                  <Text
                    onPress={this.changeTab}
                    style={[
                      this.state.activeTab == 'spot'
                        ? styles.pageTabTextActive
                        : styles.pageTabText,
                    ]}>
                    Spot
                  </Text>
                </View>
              </View>
              <View style={{flex: 2}} />
            </View>
            <View style={{paddingLeft: 5, paddingRight: 5}}>
              {this.state.activeTab == 'favourite' && (
                <ScrollView>
                  <React.Fragment>
                    <View style={{flexDirection: 'row', marginTop: 15}}>
                      <View style={{flex: 1}}>
                        <View style={{marginRight: 'auto', textAlign: 'left'}}>
                          <Text
                            style={{
                              fontSize: 8,
                              color: '#9C9E9D',
                              marginRight: 'auto',
                            }}>
                            Name
                          </Text>
                        </View>
                      </View>
                      <View style={{flex: 1}}>
                        <View
                          style={{
                            marginLeft: 'auto',
                            marginRight: 'auto',
                            textAlign: 'center',
                          }}>
                          <Text
                            style={{
                              fontSize: 8,
                              color: '#9C9E9D',
                              marginLeft: 'auto',
                              marginRight: 'auto',
                            }}>
                            Last Price
                          </Text>
                        </View>
                      </View>
                      <View style={{flex: 1}}>
                        <View style={{marginLeft: 'auto', textAlign: 'right'}}>
                          <Text
                            style={{
                              fontSize: 8,
                              color: '#9C9E9D',
                              marginLeft: 'auto',
                            }}>
                            24h Chg%
                          </Text>
                        </View>
                      </View>
                    </View>
                    {markets.map(
                      (market, i) =>
                        fav_markets.indexOf(market.id) != -1 && (
                          <TouchableOpacity
                            key={'mm-' + i}
                            onPress={() => {
                              this.props.navigation.push(
                                'TradeChart',
                                {market: market},
                                'market-' + market.id,
                              );
                            }}>
                            <View style={{flexDirection: 'row', marginTop: 10}}>
                              <View style={{flex: 1}}>
                                <View
                                  style={{
                                    marginRight: 'auto',
                                    textAlign: 'left',
                                  }}>
                                  <Text
                                    style={{
                                      fontSize: 14,
                                      color: '#9C9E9D',
                                      marginRight: 'auto',
                                    }}>
                                    {market.name}
                                  </Text>
                                  <Text
                                    style={{
                                      fontSize: 7,
                                      color: '#9C9E9D',
                                      marginRight: 'auto',
                                    }}>
                                    Vol. {market.volume_24h}
                                  </Text>
                                </View>
                              </View>
                              <View style={{flex: 1}}>
                                <View
                                  style={{
                                    marginLeft: 'auto',
                                    marginRight: 'auto',
                                    textAlign: 'center',
                                  }}>
                                  <Text
                                    style={{
                                      fontSize: 14,
                                      color: '#9C9E9D',
                                      marginLeft: 'auto',
                                      marginRight: 'auto',
                                    }}>
                                    {market.last}
                                  </Text>
                                  <Text
                                    style={{
                                      fontSize: 7,
                                      color: '#9C9E9D',
                                      marginRight: 'auto',
                                    }}>
                                    $35,523.34
                                  </Text>
                                </View>
                              </View>
                              <View style={{flex: 1}}>
                                <View
                                  style={{
                                    backgroundColor: '#43D882',
                                    borderRadius: 12,
                                    padding: 2,
                                    paddingRight: 15,
                                    paddingLeft: 15,
                                    marginLeft: 'auto',
                                    textAlign: 'center',
                                  }}>
                                  <Text
                                    style={{
                                      fontSize: 14,
                                      color: '#fff',
                                      marginLeft: 'auto',
                                      marginRight: 'auto',
                                    }}>
                                    {parseFloat(market.change_24h).toFixed(2)}%
                                  </Text>
                                </View>
                              </View>
                            </View>
                          </TouchableOpacity>
                        ),
                    )}
                    {/* <View style={{ flexDirection: 'row', marginTop: 10 }}>
                        <View style={{ flex: 1 }}>
                            <View style={{ marginRight: 'auto', textAlign: 'left' }}>
                                <Text style={{ fontSize: 14, color: '#9C9E9D', marginRight: 'auto' }}>BNB/BUSD</Text>
                                <Text style={{ fontSize: 7, color: '#9C9E9D', marginRight: 'auto' }}>Vol. 2.358</Text>
                            </View>
                        </View>
                        <View style={{ flex: 1 }}>
                            <View style={{ marginLeft: 'auto', marginRight: 'auto', textAlign: 'center' }}>
                                <Text style={{ fontSize: 14, color: '#9C9E9D', marginLeft: 'auto', marginRight: 'auto',  }}>404.5</Text>
                                <Text style={{ fontSize: 7, color: '#9C9E9D', marginRight: 'auto' }}>$35,523.34</Text>
                            </View>
                        </View>
                        <View style={{ flex: 1 }}>
                            <View style={{ backgroundColor: '#F85F5F', borderRadius: 12,  padding: 2, paddingRight: 15, paddingLeft: 15, marginLeft: 'auto', textAlign: 'center' }}>
                                <Text style={{ fontSize: 14, color: '#fff', marginLeft: 'auto', marginRight: 'auto',  }}>-% 2.53</Text>
                            </View>
                        </View>
                    </View>
                    <View style={{ flexDirection: 'row', marginTop: 10 }}>
                        <View style={{ flex: 1 }}>
                            <View style={{ marginRight: 'auto', textAlign: 'left' }}>
                                <Text style={{ fontSize: 14, color: '#9C9E9D', marginRight: 'auto' }}>BNB/BUSD</Text>
                                <Text style={{ fontSize: 7, color: '#9C9E9D', marginRight: 'auto' }}>Vol. 2.358</Text>
                            </View>
                        </View>
                        <View style={{ flex: 1 }}>
                            <View style={{ marginLeft: 'auto', marginRight: 'auto', textAlign: 'center' }}>
                                <Text style={{ fontSize: 14, color: '#43D882', marginLeft: 'auto', marginRight: 'auto',  }}>404.5</Text>
                                <Text style={{ fontSize: 7, color: '#9C9E9D', marginRight: 'auto' }}>$35,523.34</Text>
                            </View>
                        </View>
                        <View style={{ flex: 1 }}>
                            <View style={{ backgroundColor: '#43D882', borderRadius: 12,  padding: 2, paddingRight: 15, paddingLeft: 15, marginLeft: 'auto', textAlign: 'center' }}>
                                <Text style={{ fontSize: 14, color: '#fff', marginLeft: 'auto', marginRight: 'auto',  }}>-% 2.53</Text>
                            </View>
                        </View>
                    </View>
                    <View style={{ flexDirection: 'row', marginTop: 10 }}>
                        <View style={{ flex: 1 }}>
                            <View style={{ marginRight: 'auto', textAlign: 'left' }}>
                                <Text style={{ fontSize: 14, color: '#9C9E9D', marginRight: 'auto' }}>BNB/BUSD</Text>
                                <Text style={{ fontSize: 7, color: '#9C9E9D', marginRight: 'auto' }}>Vol. 2.358</Text>
                            </View>
                        </View>
                        <View style={{ flex: 1 }}>
                            <View style={{ marginLeft: 'auto', marginRight: 'auto', textAlign: 'center' }}>
                                <Text style={{ fontSize: 14, color: '#F85F5F', marginLeft: 'auto', marginRight: 'auto',  }}>404.5</Text>
                                <Text style={{ fontSize: 7, color: '#9C9E9D', marginRight: 'auto' }}>$35,523.34</Text>
                            </View>
                        </View>
                        <View style={{ flex: 1 }}>
                            <View style={{ backgroundColor: '#F85F5F', borderRadius: 12,  padding: 2, paddingRight: 15, paddingLeft: 15, marginLeft: 'auto', textAlign: 'center' }}>
                                <Text style={{ fontSize: 14, color: '#fff', marginLeft: 'auto', marginRight: 'auto',  }}>-% 2.53</Text>
                            </View>
                        </View>
                    </View>
                    <View style={{ flexDirection: 'row', marginTop: 10 }}>
                        <View style={{ flex: 1 }}>
                            <View style={{ marginRight: 'auto', textAlign: 'left' }}>
                                <Text style={{ fontSize: 14, color: '#9C9E9D', marginRight: 'auto' }}>BNB/BUSD</Text>
                                <Text style={{ fontSize: 7, color: '#9C9E9D', marginRight: 'auto' }}>Vol. 2.358</Text>
                            </View>
                        </View>
                        <View style={{ flex: 1 }}>
                            <View style={{ marginLeft: 'auto', marginRight: 'auto', textAlign: 'center' }}>
                                <Text style={{ fontSize: 14, color: '#43D882', marginLeft: 'auto', marginRight: 'auto',  }}>404.5</Text>
                                <Text style={{ fontSize: 7, color: '#9C9E9D', marginRight: 'auto' }}>$35,523.34</Text>
                            </View>
                        </View>
                        <View style={{ flex: 1 }}>
                            <View style={{ backgroundColor: '#43D882', borderRadius: 12,  padding: 2, paddingRight: 15, paddingLeft: 15, marginLeft: 'auto', textAlign: 'center' }}>
                                <Text style={{ fontSize: 14, color: '#fff', marginLeft: 'auto', marginRight: 'auto',  }}>-% 2.53</Text>
                            </View>
                        </View>
                    </View>
                    <View style={{ flexDirection: 'row', marginTop: 10 }}>
                        <View style={{ flex: 1 }}>
                            <View style={{ marginRight: 'auto', textAlign: 'left' }}>
                                <Text style={{ fontSize: 14, color: '#9C9E9D', marginRight: 'auto' }}>BNB/BUSD</Text>
                                <Text style={{ fontSize: 7, color: '#9C9E9D', marginRight: 'auto' }}>Vol. 2.358</Text>
                            </View>
                        </View>
                        <View style={{ flex: 1 }}>
                            <View style={{ marginLeft: 'auto', marginRight: 'auto', textAlign: 'center' }}>
                                <Text style={{ fontSize: 14, color: '#F85F5F', marginLeft: 'auto', marginRight: 'auto',  }}>404.5</Text>
                                <Text style={{ fontSize: 7, color: '#9C9E9D', marginRight: 'auto' }}>$35,523.34</Text>
                            </View>
                        </View>
                        <View style={{ flex: 1 }}>
                            <View style={{ backgroundColor: '#F85F5F', borderRadius: 12,  padding: 2, paddingRight: 15, paddingLeft: 15, marginLeft: 'auto', textAlign: 'center' }}>
                                <Text style={{ fontSize: 14, color: '#fff', marginLeft: 'auto', marginRight: 'auto',  }}>-% 2.53</Text>
                            </View>
                        </View>
                    </View> */}
                  </React.Fragment>
                </ScrollView>
              )}

              {this.state.activeTab == 'spot' && (
                <React.Fragment>
                  <ScrollView
                    horizontal={true}
                    style={{padding: 20, flexDirection: 'row', marginTop: 5}}>
                    {quote_currencies.map((quoteCurrency, i) => (
                      <TouchableOpacity
                        style={{flexDirection: 'row'}}
                        key={'mms-' + i}
                        onPress={() => {
                          this.selectQuote(quoteCurrency.symbol);
                        }}>
                        <View style={{flex: 1}}>
                          <View
                            style={{
                              backgroundColor:
                                quoteCurrency.symbol ==
                                this.state.activeQuoteCurrency
                                  ? '#FFAB00'
                                  : '#232323',
                              borderRadius: 6,
                              padding: 5,
                              paddingRight: 15,
                              paddingLeft: 15,
                              marginRight: 15,
                              textAlign: 'center',
                            }}>
                            <Text
                              style={{
                                fontSize: 12,
                                color: '#fff',
                              }}>
                              {quoteCurrency.symbol}
                            </Text>
                          </View>
                        </View>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>

                  {markets.map(
                    (market, i) =>
                      market.quote_currency ==
                        this.state.activeQuoteCurrency && (
                        <TouchableOpacity
                          key={'ko-' + i}
                          onPress={() => {
                            this.props.navigation.push(
                              'TradeChart',
                              {market: market},
                              'market-' + market.id,
                            );
                          }}>
                          <View style={{flexDirection: 'row', marginTop: 10}}>
                            <View style={{flex: 1}}>
                              <View
                                style={{
                                  marginRight: 'auto',
                                  textAlign: 'left',
                                }}>
                                <Text
                                  style={{
                                    fontSize: 14,
                                    color: '#9C9E9D',
                                    marginRight: 'auto',
                                  }}>
                                  {market.name}
                                </Text>
                                <Text
                                  style={{
                                    fontSize: 7,
                                    color: '#9C9E9D',
                                    marginRight: 'auto',
                                  }}>
                                  Vol. {market.volume_24h}
                                </Text>
                              </View>
                            </View>
                            <View style={{flex: 1}}>
                              <View
                                style={{
                                  marginLeft: 'auto',
                                  marginRight: 'auto',
                                  textAlign: 'center',
                                }}>
                                <Text
                                  style={{
                                    fontSize: 14,
                                    color: '#9C9E9D',
                                    marginLeft: 'auto',
                                    marginRight: 'auto',
                                  }}>
                                  {market.last}
                                </Text>
                                {/* <Text style={{ fontSize: 7, color: '#9C9E9D', marginRight: 'auto' }}>$35,523.34</Text> */}
                              </View>
                            </View>
                            <View style={{flex: 1}}>
                              <View
                                style={{
                                  backgroundColor:
                                    market.change_24h_percent >= 0
                                      ? '#43D882'
                                      : '#F85F5F',

                                  borderRadius: 12,
                                  padding: 2,
                                  paddingRight: 15,
                                  paddingLeft: 15,
                                  marginLeft: 'auto',
                                  textAlign: 'center',
                                }}>
                                <Text
                                  style={{
                                    fontSize: 14,
                                    color: '#fff',
                                    marginLeft: 'auto',
                                    marginRight: 'auto',
                                  }}>
                                  {parseFloat(
                                    market.change_24h_percent,
                                  ).toFixed(2)}
                                  %
                                </Text>
                              </View>
                            </View>
                          </View>
                        </TouchableOpacity>
                      ),
                  )}
                </React.Fragment>
              )}

              {/* </View> */}
              {/* <View style={styles.formgroup}>
                <Form>
                  <Text style={{marginTop: 15, color: '#fff', fontSize: 13}}>Password</Text>
                  <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                    <Input
                      style={styles.inputfield}
                      placeholder={'E-mail address'}
                      onChangeText={text => this.setState({email: text})}
                    />
                  </Item>
                  <Button
                    block
                    style={[styles.button, styles.orange]}
                    onPress={this.triggerForgot}>
                    <Text>Reset password</Text>
                  </Button>
                </Form>
              </View> */}
            </View>
          </Container>
        )}
        <BottomProtectedNavigationBar navigate={navigate} name="Markets" />
        <View style={{height: 0}} />
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  background: {
    backgroundColor: '#000',
  },
  container: {
    alignItems: 'center',
    flexGrow: 1,
    justifyContent: 'center',
  },
  logo: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    width: 300,
    height: 100,
  },
  logoText: {
    color: '#fefefe',
    fontSize: 36,
  },
  smallText: {
    color: '#fefefe',
    fontSize: 18,
  },
  button: {
    marginTop: 35,
    textAlign: 'center',
    borderRadius: 48,
  },
  formgroup: {
    padding: 15,
  },
  inputfield: {
    padding: 15,
    paddingLeft: 15,
    paddingRight: 15,
    fontSize: 13,
    backgroundColor: '#222222',
    borderColor: '#222222',
    borderRadius: 6,
  },
  orange: {
    backgroundColor: '#FFAB00',
  },
  green: {
    backgroundColor: '#27ae60',
  },
  topLogoBackground: {
    textAlign: 'center',
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20,
  },
  pageTabSection: {
    paddingTop: 15,
    paddingBottom: 15,
    marginLeft: 'auto',
    marginRight: 'auto',
    textAlign: 'center',
  },
  pageTabSectionActive: {
    paddingTop: 15,
    paddingBottom: 15,
    marginLeft: 'auto',
    marginRight: 'auto',
    textAlign: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#FFAB00',
  },
  pageTabText: {
    fontSize: 14,
    color: '#fff',
    marginLeft: 'auto',
    marginRight: 'auto',
  },
  pageTabTextActive: {
    fontSize: 14,
    color: '#FFAB00',
    marginLeft: 'auto',
    marginRight: 'auto',
  },
});

export default connect(mapStateToProps, mapDispatchToComponent)(Markets);
