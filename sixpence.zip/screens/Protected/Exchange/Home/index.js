import React from 'react';
import {StyleSheet, ScrollView, TouchableOpacity, Image} from 'react-native';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Container, Header, Title, Button, View, Text} from 'native-base';

import * as walletsActionCreators from '../../../../data/wallets/actions';
import * as fiatWalletsActionCreators from '../../../../data/fiatWallets/actions';
import * as ordersActionCreators from '../../../../data/orders/actions';
import {RoundedRectangle} from '../../../../static';

const mapStateToProps = state => {
  return {
    wallets: state.data.wallets,
    fiatWallets: state.data.fiatWallets,
  };
};
const mapDispatchToComponent = dispatch => ({
  actions: {
    wallets: bindActionCreators(walletsActionCreators, dispatch),
    fiatWallets: bindActionCreators(fiatWalletsActionCreators, dispatch),
    orders: bindActionCreators(ordersActionCreators, dispatch),
  },
});

class Wallets extends React.Component {
  constructor() {
    super();
  }

  componentDidMount() {
    console.log('ok');
  }

  changeTabs = number => {
    this.props.changeTabs(number);
  };

  render() {
    return (
      <View style={{justifyContent: 'center', alignItems: 'center', marginTop: 20}}>
        <View style={[styles.roundedRectangle]}>
          <View style={[styles.buttonContainer]}>
            <TouchableOpacity style={styles.button} activeOpacity={0.5}>
              <Image
                source={require('../../../../static/depositIcon.png')}
                style={styles.buttonImageIconStyle}
              />
              <Text style={styles.buttonTextStyle}>Deposit</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} activeOpacity={0.5}>
              <Image
                source={require('../../../../static/depositIcon.png')}
                style={styles.buttonImageIconStyle}
              />
              <Text style={styles.buttonTextStyle}>Trade</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} activeOpacity={0.5}>
              <Image
                source={require('../../../../static/depositIcon.png')}
                style={styles.buttonImageIconStyle}
              />
              <Text style={styles.buttonTextStyle}>Orders</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} activeOpacity={0.5}>
              <Image
                source={require('../../../../static/depositIcon.png')}
                style={styles.buttonImageIconStyle}
              />
              <Text style={styles.buttonTextStyle}>Referral</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  buttonTextStyle:{
    fontFamily: "Mukta",
    fontSize: 12,
    fontWeight: "400",
    fontStyle: "normal",
    lineHeight: 22,
    letterSpacing: -1,
    textAlign: "center",
    color: "#CFD7E3",
  },
  buttonImageIconStyle: {
    height: 24,
    width: 24,
    resizeMode: 'stretch',
  },
  buttonContainer: {
    position: 'absolute',
    flexDirection: 'row',
    width: '94.17%',
    marginLeft: '2.915%',
    marginRight: '2.915%',
    marginTop: '25.71%',
    marginBottom: '21.90%',
  },
  button: {
    alignItems:"center",
    width: '21.985%',
    marginRight: '4.02%',
    justifyContent: "space-between"

  },
  buttonLast: {
    width: '21.985%',
    justifyContent: "space-between"

  },
  roundedRectangle: {
    justifyContent: 'center',
    alignItems: 'center',
    width: '92.5%',
    marginLeft: '4.25%',
    marginRight: '4.25%',
    height: 105,
    backgroundColor: '#232323',
    borderRadius: 12,
  },
  background: {
    backgroundColor: '#eeeeee',
    flex: 1,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 10,
    marginBottom: 10,
  },
  row: {
    flexDirection: 'row',
    backgroundColor: '#eeeeee',
  },
  evenRow: {
    backgroundColor: '#fbfbfb',
  },
  rowPart: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  walletName: {
    color: '#3c4a55',
    fontSize: 11,
    paddingTop: 15,
    paddingBottom: 15,
  },
  walletTitle: {
    fontWeight: 'bold',
  },
});

export default connect(mapStateToProps, mapDispatchToComponent)(Wallets);
