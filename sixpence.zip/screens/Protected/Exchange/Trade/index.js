import React from 'react';
import {
  StyleSheet,
  ScrollView,
  Image,
  ImageBackground,
  TouchableOpacity,
} from 'react-native';
import {
  Container,
  Title,
  Button,
  View,
  Text,
  Item,
  Input,
  Form,
  Label,
  Content,
  CheckBox,
  Body,
  Toast,
} from 'native-base';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import Loading from '../../../Main/Loading';
import {
  Banner,
  Wrapper,
  TopProtectedNavigationBar,
  BottomProtectedNavigationBar,
} from '../../../../static';
import SelectDropdown from 'react-native-select-dropdown';

import * as usersAPI from '../../../../data/users/api';
import * as API from '../../../../services/api';
import * as orderActionCreators from '../../../../data/orders/actions';
import * as walletsActionCreators from '../../../../data/wallets/actions';
import * as fiatWalletsActionCreators from '../../../../data/fiatWallets/actions';

const mapStateToProps = state => {
  return {
    orders: state.data.orders,
    wallets: state.data.wallets,
    fiatWallets: state.data.fiatWallets,
  };
};

const mapDispatchToComponent = dispatch => ({
  actions: {
    orders: bindActionCreators(orderActionCreators, dispatch),
    wallets: bindActionCreators(walletsActionCreators, dispatch),
    fiatWallets: bindActionCreators(fiatWalletsActionCreators, dispatch),
  },
});

class Trade extends React.Component {
  constructor() {
    super();
    this.state = {
      email: '',
      totalAmount: 0,
      stop_price: 0,
      amount: 0,
      rate: 0,
      loading: false,
      showToast: false,
      activeTab: 'favourite',
      selectedGroup: 'buy',
      selectedType: 'Place Order',
      selectedLimitType: 'Greater than or equal',
      openOrders: 0,
    };

    this.changeTab = this.changeTab.bind(this);
    this.changeTabFavourite = this.changeTabFavourite.bind(this);
    this.changeTabGroup = this.changeTabGroup.bind(this);
    this.reloadData = this.reloadData.bind(this);
  }

  componentDidMount() {
    console.log('Component did mount; reload');
    this.reloadData();
  }

  reloadData() {
    console.log('get wallets trde');

    this.props.actions.wallets.getWallets();
    this.props.actions.fiatWallets.getFiatWallets();
    this.props.actions.orders.getMarketDetail(this.props.orders.market);
    this.props.actions.orders.getOrders(this.props.orders.market);
    this.props.actions.orders.getOrderBook(this.props.orders.market);

    // this.props.actions.orders.balance(this.props.orders.market, this.props.wallets, this.props.fiatWallets, 0);
    // this.props.actions.orders.balance(this.props.orders.market, this.props.wallets, this.props.fiatWallets, 1);
  }

  changeTab() {
    this.setState({
      ...this.state,
      activeTab: 'spot',
    });
  }

  changeTabFavourite() {
    this.setState({
      ...this.state,
      activeTab: 'favourite',
    });
  }

  changeTabGroup(group) {
    this.setState({
      ...this.state,
      selectedGroup: group,
    });
  }

  showCryptoName() {
    const {marketDetail} = this.props.orders;
    if (marketDetail) {
      let parts = marketDetail.name.split('-');
      return parts[0];
    }
  }

  showFiatName() {
    const {marketDetail} = this.props.orders;
    if (marketDetail) {
      let parts = marketDetail.name.split('-');
      return parts[1];
    }
  }

  changeSelectedType(selectedItem, index) {
    this.setState({
      ...this.state,
      selectedType: selectedItem,
    });
  }

  changeSelectedLimitType(selectedItem, index) {
    this.setState({
      ...this.state,
      selectedLimitType: selectedItem,
    });
  }

  sendOrder() {
    let group = this.state.selectedGroup;
    let type = this.state.selectedType;
    let limitType = this.state.selectedLimitType;

    this.setState({
      loading: true,
    });

    if (type == 'Place Order') {
      if (group == 'sell') {
        this.props.actions.orders
          .sellLimit(
            Number(this.state.amount),
            Number(this.state.rate),
            this.props.orders.market,
          )
          .then(this.handleLoginSuccess.bind(this))
          .catch(this.handleLoginError.bind(this));
      } else if (group == 'buy') {
        this.props.actions.orders
          .buyLimit(
            Number(this.state.amount),
            Number(this.state.rate),
            this.props.orders.market,
          )
          .then(this.handleLoginSuccess.bind(this))
          .catch(this.handleLoginError.bind(this));
      }
    } else if (type == 'Quick Order') {
      if (group == 'sell') {
        this.props.actions.orders
          .sell(Number(this.state.amount), this.props.orders.market)
          .then(this.handleLoginSuccess.bind(this))
          .catch(this.handleLoginError.bind(this));
      } else if (group == 'buy') {
        this.props.actions.orders
          .buy(Number(this.state.amount), this.props.orders.market)
          .then(this.handleLoginSuccess.bind(this))
          .catch(this.handleLoginError.bind(this));
      }
    } else if (type == 'Stop Limit') {
      let limitCommand = '';
      if (limitType == 'Greater than or equal') {
        limitCommand = 'EQUAL_OR_RISES_ABOVE';
      } else if (limitType == 'Less than or equal') {
        limitCommand = 'EQUAL_OR_FALLS_BELOW';
      }

      if (group == 'sell') {
        this.props.actions.orders
          .sellStopLimit(
            Number(this.state.amount),
            Number(this.state.rate),
            Number(this.state.stop_price),
            limitCommand,
            this.props.orders.market,
          )
          .then(this.handleLoginSuccess.bind(this))
          .catch(this.handleLoginError.bind(this));
      } else if (group == 'buy') {
        this.props.actions.orders
          .buyStopLimit(
            Number(this.state.amount),
            Number(this.state.rate),
            Number(this.state.stop_price),
            limitCommand,
            this.props.orders.market,
          )
          .then(this.handleLoginSuccess.bind(this))
          .catch(this.handleLoginError.bind(this));
      }
    }
  }

  showFiatBalance() {
    let fiatSymbol = this.showFiatName();
    let balance = 0;
    this.props.fiatWallets.data.map(item => {
      if (item.currency == fiatSymbol) {
        balance = item.available;
      }
    });
    return balance;
  }

  showCryptoBalance() {
    let cryptoSymbol = this.showCryptoName();
    let balance = 0;
    this.props.wallets.data.map(item => {
      if (item.currency == cryptoSymbol) {
        balance = item.available;
      }
    });
    return balance;
  }
  cancelOrder(uuid) {
    console.log("cancel uuid",uuid);
    this.setState({
      loading: true,
    });
    this.props.actions.orders.cancelOrder(uuid);
    this.reloadData();
    this.setState({
      loading: false,
    });

  }

  handleLoginSuccess = response => {
    console.log('handlesuccess reload; reload');

    this.reloadData();

    this.setState({
      loading: false,
    });

    // Redirect to protected area
    Toast.show({
      text: 'Order Successful',
      position: 'top',
      buttonText: 'X',
      type: 'success',
    });
  };

  handleLoginError = error => {
    console.log('Login error -------');
    console.log(error);
    console.log('dd', error.response.data.errors);

    // Fetching errors and preparing error string
    let string = '';
    for (let [key, value] of Object.entries(error.response.data.errors)) {
      string += value + '\n';

      console.log(`${key}: ${value}`);
    }
    // Iterating through errors object
    if (error.response.status !== 403) {
      // string += error.response.data.message;
    } else {
      string += 'Could not place this order';
    }

    this.setState({
      showToast: true,
    });

    // Stop spinner
    this.setState({
      loading: false,
    });

    // SHowign the toast with errors
    Toast.show({
      text: string,
      position: 'top',
      buttonText: 'X',
      type: 'danger',
    });
  };

  render() {
    const {navigate} = this.props.navigation;
    const {open_orders, orderbook_buy, orderbook_sell, marketDetail} =
      this.props.orders;

    const countries = ['Place Order', 'Quick Order', 'Stop Limit'];
    const stop_price_types = ['Greater than or equal', 'Less than or equal'];

    return (
      <ScrollView style={styles.background}>
        {this.state.loading && <Loading />}
        {!this.state.loading && (
          <Container style={styles.background}>
            {/* <Banner /> */}
            {/* <TopProtectedNavigationBar navigate={navigate} name="Markets" /> */}

            <View
              style={{
                flexDirection: 'row',
                marginTop: 2,
                paddingTop: 15,
                paddingBottom: 15,
              }}>
              <View style={{flex: 1}}>
                <View>
                  <Image
                    style={{width: 30, resizeMode: 'contain'}}
                    source={require('../../../../static/images/tradevector.png')}
                  />
                </View>
              </View>
              <View style={{flex: 4}}>
                <View style={{flexDirection: 'row'}}>
                  <Text style={{color: '#fff', marginRight: 5}}>
                    {marketDetail.name}
                  </Text>
                  <Text style={{color: '#F85F5F', fontSize: 10, marginTop: 5}}>
                    {marketDetail.change_24h_percent}%
                  </Text>
                </View>
              </View>

            </View>

            <View
              style={{
                backgroundColor: '#222222',
                flexDirection: 'row',
                marginTop: 5,
                padding: 15,
                borderRadius: 12,
              }}>
              <View style={{flex: 2}}>
                <View style={{height: 180}}>
                  <View style={{flexDirection: 'row'}}>
                    <View style={{flex: 1}}>
                      <Text style={{color: '#9C9E9D', fontSize: 9}}>Name</Text>
                      <Text style={{color: '#E2E2E2', fontSize: 14}}>
                        {this.showCryptoName()}
                      </Text>
                    </View>
                    <View style={{flex: 1}}>
                      <Text
                        style={{
                          color: '#9C9E9D',
                          fontSize: 9,
                          marginLeft: 'auto',
                        }}>
                        Last Price
                      </Text>
                      <Text
                        style={{
                          color: '#E2E2E2',
                          fontSize: 14,
                          marginLeft: 'auto',
                        }}>
                        ({this.showFiatName()})
                      </Text>
                    </View>
                  </View>
                  {orderbook_sell.map((item, i) => (
                    <View style={{flexDirection: 'row', marginTop: 10}}>
                      <View style={{flex: 1}}>
                        <Text style={{color: '#F85F5F', fontSize: 10}}>
                          {item.quantity}
                        </Text>
                      </View>
                      <View style={{flex: 1}}>
                        <Text
                          style={{
                            color: '#E2E2E2',
                            fontSize: 10,
                            marginLeft: 'auto',
                          }}>
                          {item.rate}
                        </Text>
                      </View>
                    </View>
                  ))}
                </View>

                <View style={{height: 180, marginTop: 5}}>
                  <View style={{flexDirection: 'row'}}>
                    <View style={{flex: 1}}>
                      <Text style={{color: '#9C9E9D', fontSize: 9}}>Name</Text>
                      <Text style={{color: '#E2E2E2', fontSize: 14}}>
                        {this.showCryptoName()}
                      </Text>
                    </View>
                    <View style={{flex: 1}}>
                      <Text
                        style={{
                          color: '#9C9E9D',
                          fontSize: 9,
                          marginLeft: 'auto',
                        }}>
                        Last Price
                      </Text>
                      <Text
                        style={{
                          color: '#E2E2E2',
                          fontSize: 14,
                          marginLeft: 'auto',
                        }}>
                        ({this.showFiatName()})
                      </Text>
                    </View>
                  </View>
                  {orderbook_buy.map((item, i) => (
                    <View style={{flexDirection: 'row', marginTop: 10}}>
                      <View style={{flex: 1}}>
                        <Text style={{color: '#43D882', fontSize: 10}}>
                          {item.quantity}
                        </Text>
                      </View>
                      <View style={{flex: 1}}>
                        <Text
                          style={{
                            color: '#E2E2E2',
                            fontSize: 10,
                            marginLeft: 'auto',
                          }}>
                          {item.rate}
                        </Text>
                      </View>
                    </View>
                  ))}
                </View>
              </View>
              <View style={{flex: 3}}>
                <View style={{flexDirection: 'row', marginLeft: 20}}>
                  <View
                    style={{
                      flex: 1,
                      backgroundColor:
                        this.state.selectedGroup == 'buy' ? '#FFAB00' : '#000',
                      padding: 10,
                      borderTopLeftRadius: 12,
                      borderBottomLeftRadius: 12,
                    }}>
                    <Text
                      onPress={() => this.changeTabGroup('buy')}
                      style={{
                        color: '#fff',
                        fontSize: 12,
                        marginLeft: 'auto',
                        marginRight: 'auto',
                      }}>
                      BUY
                    </Text>
                  </View>
                  <View
                    style={{
                      flex: 1,
                      backgroundColor:
                        this.state.selectedGroup == 'sell' ? '#FFAB00' : '#000',
                      padding: 10,
                      borderTopRightRadius: 12,
                      borderBottomRightRadius: 12,
                    }}>
                    <Text
                      onPress={() => this.changeTabGroup('sell')}
                      style={{
                        color: '#fff',
                        fontSize: 12,
                        marginLeft: 'auto',
                        marginRight: 'auto',
                      }}>
                      SELL
                    </Text>
                  </View>
                </View>

                <View
                  style={{flexDirection: 'row', marginLeft: 20, marginTop: 10}}>
                  <SelectDropdown
                    dropdownStyle={{backgroundColor: '#343434', padding: 0}}
                    rowTextStyle={{fontSize: 10, color: '#fff'}}
                    buttonTextStyle={{fontSize: 10, color: '#fff'}}
                    buttonStyle={{
                      height: 35,
                      backgroundColor: '#343434',
                      padding: 0,
                      borderRadius: 10,
                    }}
                    data={countries}
                    defaultValue="Place Order"
                    onSelect={(selectedItem, index) => {
                      this.changeSelectedType(selectedItem, index);
                    }}
                  />
                  <Image
                    style={{
                      position: 'absolute',
                      top: 10,
                      left: 5,
                      width: 30,
                      resizeMode: 'contain',
                    }}
                    source={require('../../../../static/images/tradewarn.png')}
                  />
                  <Image
                    style={{
                      position: 'absolute',
                      top: 15,
                      right: 5,
                      width: 30,
                      resizeMode: 'contain',
                    }}
                    source={require('../../../../static/images/arrow-down.png')}
                  />
                </View>

                {this.state.selectedType == 'Stop Limit' && (
                  <React.Fragment>
                    <View
                      style={{
                        flexDirection: 'row',
                        marginLeft: 20,
                        marginTop: 10,
                      }}>
                      <SelectDropdown
                        dropdownStyle={{backgroundColor: '#343434', padding: 0}}
                        rowTextStyle={{fontSize: 10, color: '#fff'}}
                        buttonTextStyle={{fontSize: 10, color: '#fff'}}
                        buttonStyle={{
                          height: 35,
                          backgroundColor: '#343434',
                          padding: 0,
                          borderRadius: 10,
                        }}
                        data={stop_price_types}
                        defaultValue="Greater than or equal"
                        onSelect={(selectedItem, index) => {
                          this.changeSelectedLimitType(selectedItem, index);
                        }}
                      />
                      <Image
                        style={{
                          position: 'absolute',
                          top: 10,
                          left: 5,
                          width: 30,
                          resizeMode: 'contain',
                        }}
                        source={require('../../../../static/images/tradewarn.png')}
                      />
                      <Image
                        style={{
                          position: 'absolute',
                          top: 15,
                          right: 5,
                          width: 30,
                          resizeMode: 'contain',
                        }}
                        source={require('../../../../static/images/arrow-down.png')}
                      />
                    </View>

                    <View
                      style={{
                        flexDirection: 'row',
                        marginLeft: 20,
                        marginTop: 10,
                      }}>
                      <Input
                        style={styles.inputfield}
                        placeholder="Stop Price"
                        keyboardType="numeric"
                        onChangeText={text => this.setState({stop_price: text})}
                      />
                      <Image
                        style={{
                          position: 'absolute',
                          top: 10,
                          left: 5,
                          width: 30,
                          resizeMode: 'contain',
                        }}
                        source={require('../../../../static/images/tradewarn.png')}
                      />
                      <Image
                        style={{
                          position: 'absolute',
                          top: 10,
                          right: 5,
                          width: 30,
                          resizeMode: 'contain',
                        }}
                        source={require('../../../../static/images/tradeaddicon.png')}
                      />
                    </View>
                  </React.Fragment>
                )}

                {this.state.selectedType != 'Quick Order' && (
                  <View
                    style={{
                      flexDirection: 'row',
                      marginLeft: 20,
                      marginTop: 10,
                    }}>
                    <Input
                      style={styles.inputfield}
                      placeholder="Price (rate)"
                      keyboardType="numeric"
                      onChangeText={text => this.setState({rate: text})}
                    />
                    <Image
                      style={{
                        position: 'absolute',
                        top: 10,
                        left: 5,
                        width: 30,
                        resizeMode: 'contain',
                      }}
                      source={require('../../../../static/images/tradewarn.png')}
                    />
                    <Image
                      style={{
                        position: 'absolute',
                        top: 10,
                        right: 5,
                        width: 30,
                        resizeMode: 'contain',
                      }}
                      source={require('../../../../static/images/tradeaddicon.png')}
                    />
                  </View>
                )}

                <View
                  style={{flexDirection: 'row', marginLeft: 20, marginTop: 10}}>
                  <Input
                    style={styles.inputfield}
                    placeholder="Amount"
                    keyboardType="numeric"
                    onChangeText={text => this.setState({amount: text})}
                  />
                  <Image
                    style={{
                      position: 'absolute',
                      top: 10,
                      left: 5,
                      width: 30,
                      resizeMode: 'contain',
                    }}
                    source={require('../../../../static/images/tradewarn.png')}
                  />
                  <Image
                    style={{
                      position: 'absolute',
                      top: 10,
                      right: 5,
                      width: 30,
                      resizeMode: 'contain',
                    }}
                    source={require('../../../../static/images/tradeaddicon.png')}
                  />
                </View>

                <View
                  style={{flexDirection: 'row', marginLeft: 20, marginTop: 10}}>
                  <View style={{flex: 1}}>
                    <View
                      style={{
                        backgroundColor: '#343434',
                        height: 5,
                        borderRadius: 9,
                        marginLeft: 2,
                        marginRight: 2,
                      }}
                    />
                    <Text
                      style={{
                        fontSize: 8,
                        color: '#fff',
                        marginLeft: 'auto',
                        marginRight: 'auto',
                        marginTop: 3,
                      }}>
                      25%
                    </Text>
                  </View>
                  <View style={{flex: 1}}>
                    <View
                      style={{
                        backgroundColor: '#343434',
                        height: 5,
                        borderRadius: 9,
                        marginLeft: 2,
                        marginRight: 2,
                      }}
                    />
                    <Text
                      style={{
                        fontSize: 8,
                        color: '#fff',
                        marginLeft: 'auto',
                        marginRight: 'auto',
                        marginTop: 3,
                      }}>
                      50%
                    </Text>
                  </View>
                  <View style={{flex: 1}}>
                    <View
                      style={{
                        backgroundColor: '#343434',
                        height: 5,
                        borderRadius: 9,
                        marginLeft: 2,
                        marginRight: 2,
                      }}
                    />
                    <Text
                      style={{
                        fontSize: 8,
                        color: '#fff',
                        marginLeft: 'auto',
                        marginRight: 'auto',
                        marginTop: 3,
                      }}>
                      75%
                    </Text>
                  </View>
                  <View style={{flex: 1}}>
                    <View
                      style={{
                        backgroundColor: '#343434',
                        height: 5,
                        borderRadius: 9,
                        marginLeft: 2,
                        marginRight: 2,
                      }}
                    />
                    <Text
                      style={{
                        fontSize: 8,
                        color: '#fff',
                        marginLeft: 'auto',
                        marginRight: 'auto',
                        marginTop: 3,
                      }}>
                      100%
                    </Text>
                  </View>
                </View>

                <View
                  style={{flexDirection: 'row', marginLeft: 20, marginTop: 10}}>
                  <Input
                    style={styles.inputfield}
                    placeholder="Total USD"
                    keyboardType="numeric"
                    editable={false}
                    defaultValue="0"
                    onChangeText={text => this.setState({totalAmount: text})}
                  />
                </View>

                <View
                  style={{flexDirection: 'row', marginLeft: 20, marginTop: 15}}>
                  <View style={{flex: 1}}>
                    <Text style={{color: '#fff', fontSize: 9}}>Avbl</Text>
                  </View>
                  <View style={{flex: 1}}>
                    <View style={{flexDirection: 'row'}}>
                      {this.state.selectedGroup == 'buy' && (
                        <Text style={{color: '#fff', fontSize: 9}}>
                          {this.showFiatBalance()} {this.showFiatName()}
                        </Text>
                      )}
                      {this.state.selectedGroup == 'sell' && (
                        <Text style={{color: '#fff', fontSize: 9}}>
                          {this.showCryptoBalance()} {this.showCryptoName()}
                        </Text>
                      )}
                      <Image
                        style={{
                          marginTop: -2,
                          width: 30,
                          resizeMode: 'contain',
                        }}
                        source={require('../../../../static/images/tradeaddicon.png')}
                      />
                    </View>
                  </View>
                </View>

                <View style={{flexDirection: 'row', marginLeft: 20}}>
                  <View style={{flex: 1}}>
                    <Button
                      onPress={() => this.sendOrder()}
                      block
                      style={[styles.button, styles.orange]}>
                      <Text>
                        {this.state.selectedGroup.toUpperCase()}{' '}
                        {this.showCryptoName()}
                      </Text>
                    </Button>
                  </View>
                </View>

              </View>
            </View>
            <View style={{display: 'flex', marginTop: 10}}>
              <View style={{flexDirection: 'row', marginLeft: 'auto'}}>
                <TouchableOpacity
                  onPress={() =>
                    navigate('TradeChart', {screen: 'TradeChart'})
                  }>
                  <Image
                    style={{width: 30, resizeMode: 'contain'}}
                    source={require('../../../../static/images/tradeunion.png')}
                  />
                </TouchableOpacity>

              </View>
            </View>

            <View style={{flexDirection: 'row', marginTop: 2}}>
              <View style={{flex: 2}}>
                <View
                  style={[
                    this.state.activeTab == 'favourite'
                      ? styles.pageTabSectionActive
                      : styles.pageTabSection,
                  ]}>
                  <Text
                    onPress={this.changeTabFavourite}
                    style={[
                      this.state.activeTab == 'favourite'
                        ? styles.pageTabTextActive
                        : styles.pageTabText,
                    ]}>
                    Open Orders ({open_orders && open_orders.length})
                  </Text>
                </View>
              </View>
            </View>

            <View style={{paddingLeft: 5, paddingRight: 5}}>
              {this.state.activeTab == 'favourite' && (
                <React.Fragment>
                  <View style={{flexDirection: 'row', marginTop: 15}}>
                    <View style={{flex: 1}}>
                      <View style={{marginRight: 'auto', textAlign: 'left'}}>
                        <Text
                          style={{
                            fontSize: 8,
                            color: '#9C9E9D',
                            marginRight: 'auto',
                          }}>
                          Created at / Type
                        </Text>
                      </View>
                    </View>
                    <View style={{flex: 1}}>
                      <View
                        style={{
                          marginLeft: 'auto',
                          marginRight: 'auto',
                          textAlign: 'center',
                        }}>
                        <Text
                          style={{
                            fontSize: 8,
                            color: '#9C9E9D',
                            marginLeft: 'auto',
                            marginRight: 'auto',
                          }}>
                          Order Rate({this.showCryptoName()}) / Amount(
                          {this.showFiatName()})
                        </Text>
                      </View>
                    </View>
                    <View style={{flex: 1}}>
                      <View style={{marginLeft: 'auto', textAlign: 'right'}}>
                        <Text
                          style={{
                            fontSize: 8,
                            color: '#9C9E9D',
                            marginLeft: 'auto',
                          }}>
                          Remaining (ETH)
                        </Text>
                      </View>
                    </View>
                    <View style={{flex: 1}}>
                      <View style={{marginLeft: 'auto', textAlign: 'right'}}>
                        <Text
                          style={{
                            fontSize: 8,
                            color: '#9C9E9D',
                            marginLeft: 'auto',
                          }}>
                          Total Price ({this.showFiatName()})
                        </Text>
                      </View>
                    </View>
                  </View>
                  {open_orders &&
                    open_orders.length > 0 && open_orders.map((item, i) => (
                    <View style={{flexDirection: 'row', marginTop: 10}}>
                      <View style={{flex: 1}}>
                        <View style={{marginRight: 'auto', textAlign: 'left'}}>
                          <Text
                            style={{
                              fontSize: 8,
                              color: '#9C9E9D',
                              marginRight: 'auto',
                            }}>
                            {item.created_at}
                          </Text>
                          {item.type == 'BUY' && (
                            <Text
                              style={{
                                fontSize: 9,
                                color: '#9C9E9D',
                                marginRight: 'auto',
                              }}>
                              BUY
                            </Text>
                          )}
                          {item.type == 'BUY_LIMIT' && (
                            <Text
                              style={{
                                fontSize: 9,
                                color: '#9C9E9D',
                                marginRight: 'auto',
                              }}>
                              BUY LIMIT
                            </Text>
                          )}
                          {item.type == 'SELL' && (
                            <Text
                              style={{
                                fontSize: 9,
                                color: '#9C9E9D',
                                marginRight: 'auto',
                              }}>
                              SELL
                            </Text>
                          )}
                          {item.type == 'SELL_LIMIT' && (
                            <Text
                              style={{
                                fontSize: 9,
                                color: '#9C9E9D',
                                marginRight: 'auto',
                              }}>
                              SELL LIMIT
                            </Text>
                          )}
                        </View>
                        <View style={{flex: 1}}>
                          <TouchableOpacity
                            onPress={() => {
                              this.cancelOrder(item.uuid);
                            }}>
                            <Image
                              style={{
                                marginTop: 0,
                                width: 7,
                                resizeMode: 'contain',
                                marginLeft: 0,
                              }}
                              source={require('../../../../static/images/closeicon.png')}
                            />
                          </TouchableOpacity>
                        </View>
                      </View>
                      <View style={{flex: 1}}>
                        <View
                          style={{
                            marginLeft: 'auto',
                            marginRight: 'auto',
                            textAlign: 'center',
                          }}>
                          <Text
                            style={{
                              fontSize: 10,
                              color: '#9C9E9D',
                              marginLeft: 'auto',
                              marginRight: 'auto',
                            }}>
                            {item.rate}({this.showCryptoName()})
                          </Text>
                          <Text
                            style={{
                              fontSize: 10,
                              color: '#9C9E9D',
                              marginLeft: 'auto',
                              marginRight: 'auto',
                            }}>
                            {item.rate * item.quantity}({this.showFiatName()})
                          </Text>
                        </View>
                      </View>
                      <View style={{flex: 1}}>
                        <View style={{marginLeft: 'auto', textAlign: 'center'}}>
                          <Text
                            style={{
                              fontSize: 10,
                              color: '#9C9E9D',
                              marginLeft: 'auto',
                              marginRight: 'auto',
                            }}>
                            {item.quantity_remaining}({this.showCryptoName()})
                          </Text>
                        </View>
                      </View>
                      <View style={{flex: 1}}>
                        <View style={{marginLeft: 'auto', textAlign: 'center'}}>
                          <Text
                            style={{
                              fontSize: 10,
                              color: '#9C9E9D',
                              marginLeft: 'auto',
                              marginRight: 'auto',
                            }}>
                            {item.rate * item.quantity} ({this.showFiatName()})
                          </Text>
                        </View>
                      </View>
                    </View>
                  ))}
                </React.Fragment>
              )}
              {/* </View> */}
              {/* <View style={styles.formgroup}>
                <Form>
                  <Text style={{marginTop: 15, color: '#fff', fontSize: 13}}>Password</Text>
                  <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                    <Input
                      style={styles.inputfield}
                      placeholder={'E-mail address'}
                      onChangeText={text => this.setState({email: text})}
                    />
                  </Item>
                  <Button
                    block
                    style={[styles.button, styles.orange]}
                    onPress={this.triggerForgot}>
                    <Text>Reset password</Text>
                  </Button>
                </Form>
              </View> */}
            </View>
          </Container>
        )}
        <BottomProtectedNavigationBar navigate={navigate} name="Trade" />
        <View style={{height: 50}} />
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  background: {
    backgroundColor: '#000',
  },
  container: {
    alignItems: 'center',
    flexGrow: 1,
    justifyContent: 'center',
  },
  logo: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    width: 300,
    height: 100,
  },
  logoText: {
    color: '#fefefe',
    fontSize: 36,
  },
  smallText: {
    color: '#fefefe',
    fontSize: 18,
  },
  button: {
    marginTop: 15,
    textAlign: 'center',
    borderRadius: 48,
  },
  formgroup: {
    padding: 15,
  },
  inputfield: {
    padding: 1,
    paddingLeft: 35,
    paddingRight: 15,
    fontSize: 10,
    backgroundColor: '#343434',
    borderColor: '#343434',
    borderRadius: 6,
    height: 35,
    color: '#fff',
  },
  orange: {
    backgroundColor: '#FFAB00',
  },
  green: {
    backgroundColor: '#27ae60',
  },
  topLogoBackground: {
    textAlign: 'center',
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20,
  },
  pageTabSection: {
    paddingTop: 15,
    paddingBottom: 15,
    marginLeft: 'auto',
    marginRight: 'auto',
    textAlign: 'center',
  },
  pageTabSectionActive: {
    paddingTop: 15,
    paddingBottom: 15,
    marginLeft: 'auto',
    marginRight: 'auto',
    textAlign: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#FFAB00',
  },
  pageTabText: {
    fontSize: 14,
    color: '#fff',
    marginLeft: 'auto',
    marginRight: 'auto',
  },
  pageTabTextActive: {
    fontSize: 14,
    color: '#FFAB00',
    marginLeft: 'auto',
    marginRight: 'auto',
  },
});

export default connect(mapStateToProps, mapDispatchToComponent)(Trade);
