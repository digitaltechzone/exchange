import React from 'react';
import { StyleSheet, ScrollView, Dimensions } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
    Container,
    Header,
    Title,
    Button,
    View,
    Text,
    Toast
} from 'native-base';
import SegmentedControlTab from 'react-native-segmented-control-tab'
import Prompt from 'rn-prompt';

import { OrdersHeading, WrapperNoPadding } from '../../../../static';

import * as orderSelectors from '../../../../data/orders/selectors';
import * as orderActionCreators from '../../../../data/orders/actions';
import * as walletsActionCreators from "../../../../data/wallets/actions";
import * as fiatWalletsActionCreators from "../../../../data/fiatWallets/actions";

const { width, height } = Dimensions.get('window');

const mapStateToProps = (state) => {
    return {
        orders: state.data.orders,
        wallets: state.data.wallets,
        fiatWallets: state.data.fiatWallets,
    }
}

const mapDispatchToComponent = (dispatch) => ({
    actions: {
        orders: bindActionCreators(orderActionCreators, dispatch),
        wallets: bindActionCreators(walletsActionCreators, dispatch),
        fiatWallets: bindActionCreators(fiatWalletsActionCreators, dispatch),
    }
})

class Orders extends React.Component {
    constructor () {
        super();
        this.state = {
            tabIndex: 0,
            buyPromptVisible: false,
            sellPromptVisible: false,
            sellPromptVisibleRate: false,
            sellQuantity: 0,
            showToast: false
        }

        this.reloadData = this.reloadData.bind(this);
    }

    handleSegmentChange = (index) => {
        this.setState({ tabIndex: index });
    }

    componentDidMount() {
       this.reloadData();
    }

    reloadData() {
        console.log("get wallets orders");
        this.props.actions.wallets.getWallets();
        this.props.actions.fiatWallets.getFiatWallets();
        this.props.actions.orders.getMarketDetail(this.props.orders.market)
        this.props.actions.orders.get(this.props.orders.market);
        this.props.actions.orders.balance(this.props.orders.market, this.props.wallets, this.props.fiatWallets, 0);
        this.props.actions.orders.balance(this.props.orders.market, this.props.wallets, this.props.fiatWallets, 1);
        console.log("reloading, market: " + this.props.orders.market);
      }

    render() {
        const { buy, sell, marketDetail } = this.props.orders;

        return (
            <ScrollView style={styles.background}>
                { /* Prompts */ }
                <Prompt
                    title="Enter buy quantity"
                    placeholder="Quantity"
                    visible={ this.state.buyPromptVisible }
                    onCancel={ () => this.setState({
                        buyPromptVisible: false,
                    }) }
                    onSubmit={ (value) => {
                            if(value != undefined && value > 0) {
                                this.setState({ buyPromptVisible: false })
                                this.props.actions.orders.buy(Number(value), this.props.orders.market)
                                .then(response =>  {
                                    this.reloadData();
                                })
                                .catch(error => { console.log(error.response) });
                            } else {
                                this.setState({ showToast: true, buyPromptVisible: false });
                                Toast.show({
                                    text: "You have to enter a correct amount",
                                    position: 'top',
                                    buttonText: 'X',
                                    type: 'danger'
                                });
                            }
                        }
                    }/>

                <Prompt
                    title="Enter sell quantity"
                    placeholder="Quantity"
                    visible={ this.state.sellPromptVisible }
                    onCancel={ () => this.setState({
                        sellPromptVisible: false,
                    }) }
                    onSubmit={
                        (value) => {
                            if(value != undefined && value > 0) {
                                this.setState({
                                    sellPromptVisible: false,
                                    sellPromptVisibleRate: true,
                                    sellQuantity: value
                                })
                            } else {
                                this.setState({ showToast: true, sellPromptVisible: false, });
                                Toast.show({
                                    text: "You have to enter a correct amount",
                                    position: 'top',
                                    buttonText: 'X',
                                    type: 'danger'
                                });
                            }
                        }
                    }/>

                <Prompt
                    title="Enter sell rate"
                    placeholder="Rate"
                    visible={ this.state.sellPromptVisibleRate }
                    onCancel={ () => this.setState({
                        sellQuantity: 0,
                        sellPromptVisibleRate: false
                    })}
                    onSubmit={ (rate) => {
                        if(rate != undefined && rate > 0) {
                            this.setState({ sellPromptVisibleRate: false });
                            this.props.actions.orders.sell(Number(this.state.sellQuantity), rate, this.props.orders.market)
                            .then(response => {
                                this.reloadData();
                            })
                            .catch(error => { console.log(error.response) });
                        } else {
                            this.setState({ showToast: true, sellPromptVisibleRate: false });
                                Toast.show({
                                    text: "You have to enter a correct amount",
                                    position: 'top',
                                    buttonText: 'X',
                                    type: 'danger'
                                });
                        }
                    }}/>

                { /* endof prompts */ }
                <Toast />
                <OrdersHeading currentBalance={this.props.orders.balance.base + " " + marketDetail.quote_currency}/>
                <WrapperNoPadding>
                    { /* begin market limit */ }
                    <View style={styles.marketLimit}>
                        <SegmentedControlTab
                            values={['MARKET', 'LIMIT']}
                            selectedIndex={this.state.tabIndex}
                            onTabPress={this.handleSegmentChange}
                            tabsContainerStyle={styles.tabsContainerStyle}
                            tabStyle={styles.tabStyle}
                            tabTextStyle={styles.tabTextStyle}
                            activeTabStyle={styles.activeTabStyle}
                            activeTabTextStyle={styles.activeTabTextStyle}
                        />
                        <View style={styles.marketLimitParent}>
                            <View style={styles.marketLimitHeading}>
                                <Text style={styles.greyText}>{marketDetail.quote_currency} to spend</Text>
                                <View style={{
                                    borderBottomColor: '#27ae60',
                                    borderBottomWidth: 2,
                                    width: width - width * 0.9,
                                    marginTop: 15}}>
                                </View>
                            </View>
                            <View style={styles.marketLimitHeading}>
                                <Text style={styles.greyText}>{marketDetail.currency} to sell</Text>
                                <View style={{
                                    borderBottomColor: '#27ae60',
                                    borderBottomWidth: 2,
                                    width: width - width * 0.9,
                                    marginTop: 15}}>
                                </View>
                            </View>
                        </View>
                        <View style={[styles.marketLimitParent]}>
                            <View style={[styles.marketLimitPart]}>
                                <Text style={[styles.orangeText, styles.font20]}>{this.props.orders.balance.base} {marketDetail.quote_currency}</Text>
                            </View>
                            <View style={styles.marketLimitPart}>
                                <Text style={[styles.blueText, styles.font20]}>{this.props.orders.balance.market} {marketDetail.currency}</Text>
                            </View>
                        </View>
                    </View>
                    { /* endpf market limit */ }

                    { /* begin of buy sell buttons */ }
                    <View style={styles.buySellBtns}>
                        <Button block style={[styles.buySellBtn, styles.orange]} onPress={ () => this.setState({buyPromptVisible: true})}>
                            <Text style={styles.whiteText}>BUY</Text>
                        </Button>
                        <Button block style={[styles.buySellBtn, styles.green]} onPress={ () => this.setState({sellPromptVisible: true})}>
                            <Text style={styles.whiteText}>SELL</Text>
                        </Button>
                    </View>
                    { /* end of buy sell buttons */ }

                    { /* table */ }
                    <View>
                        { /* table heading */ }
                        <View style={styles.tableHeading}>
                            <View style={styles.tableHeadingPart}>
                                <Text style={[styles.smallText, styles.midDarkText]}>Total USD:</Text>
                                <Text style={styles.smallText}>11462221.35</Text>
                            </View>
                            <View style={[styles.tableHeadingPart, styles.alignRight]}>
                                <Text style={styles.smallText}>Bid</Text>
                            </View>
                            <View style={[styles.tableHeadingPart]}>
                                <Text style={styles.smallText}>Ask</Text>
                            </View>
                            <View style={[styles.tableHeadingPart, styles.alignRight]}>
                                <Text style={[styles.smallText, styles.midDarkText]}>Total BTC:</Text>
                                <Text style={styles.smallText}>11462221.35</Text>
                            </View>
                        </View>
                        <View style={styles.tableRow}>
                            <View style={styles.tableSide}>
                                {
                                    buy.map((row, i) => (
                                        <TableRowBuy
                                            key={'row'+i}
                                            data={row} />
                                    ))
                                }
                            </View>
                            <View style={styles.tableSide}>
                                {
                                    sell.map((row, i) => (
                                        <TableRowSell
                                            key={'row'+i}
                                            data={row} />
                                    ))
                                }
                            </View>
                        </View>
                        { /* endof table heading */ }
                    </View>
                    { /* endof table */ }
                </WrapperNoPadding>
            </ScrollView>
        )
    }
}

 class TableRowBuy extends React.Component{
    render() {
        const d = this.props.data;
        return (
            <View style={styles.tableSideRow}>
                <View style={styles.tableSidePart}>
                    <Text style={[styles.normalText, styles.greyText]}>{Number(d.rate).toFixed(6)}</Text>
                </View>
                <View style={[styles.tableSidePart, styles.alignRight]}>
                    <Text style={[styles.normalText, styles.greenTableText]}>{Number(d.quantity).toFixed(6)}</Text>
                </View>
            </View>
        )
    }
}

class TableRowSell extends React.Component{
    render() {
        const d = this.props.data;
        return (
            <View style={styles.tableSideRow}>
                <View style={[styles.tableSidePart]}>
                    <Text style={[styles.normalText, styles.redTableText]}>{Number(d.quantity).toFixed(6)}</Text>
                </View>
                <View style={[styles.tableSidePart, styles.alignRight]}>
                    <Text style={[styles.normalText, styles.greyText]}>{Number(d.rate).toFixed(6)}</Text>
                </View>
            </View>
        )
    }
}

class Prompts extends React.Component{
    render() {
        return (
            <Container>

            </Container>
        )
    }
}

const styles = StyleSheet.create({
    background: {
        backgroundColor: '#eeeeee',
        flex: 1
    },
    lightBackground: {
        backgroundColor: '#596f95',
        borderRadius: 5
    },
    borderRightPart: {
        borderRightWidth: 0.5,
        borderColor: '#2c3e50',
    },
    darkText: {
        color: '#2c3e50'
    },
    whiteText: {
        color: '#fefefe',
    },
    lightText: {
        color: '#596f95'
    },
    midDarkText: {
        color: '#525967'
    },
    font20: {
        fontSize: 18,
        fontWeight: 'bold'
    },
    balance: {
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
        paddingTop: 10,
        paddingBottom: 10,
        margin: 15,
        borderRadius: 5,
        borderWidth: 0.5,
        borderColor: '#57c6f9',
    },
    blueText: {
        color: '#57c6f9'
    },
    greyText: {
        color: '#888888'
    },
    orangeText: {
        color: '#ef5e47'
    },
    marketLimitParent: {
        flexDirection: 'row',
        marginTop: 15,
    },
    marketLimitHeading: {
        flex: 0.5,
        alignItems: 'center'
    },
    marketLimitPart: {
        flex: 0.5,
        padding: 15,
        paddingTop: 5,
        paddingBottom: 5,
        alignItems: 'center'
    },
    tabsContainerStyle: {
        borderBottomWidth: 0.5,
        borderColor: '#dddddd',
        marginBottom: 15
    },
    tabStyle: {
        backgroundColor: 'transparent',
        borderWidth: 0,
    },
    tabTextStyle: {
        color: '#3c4a55',
        borderWidth: 0,
        fontSize: 14,
        fontWeight: 'bold'
    },
    activeTabStyle: {
        backgroundColor: '#ffffff',
    },
    activeTabTextStyle: {
        color: '#00b259',
        borderBottomWidth: 4,
        borderColor: '#00b259',
        paddingTop: 15,
        paddingBottom: 15,
        flex: 1,
        alignItems: 'center',
        marginBottom: -5,
        textAlign: 'center'
    },
    buySellBtns: {
        flexDirection: 'row',
    },
    buySellBtn: {
        flex: 0.5,
        margin: 15,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 1,
    },
    tableHeading: {
        flexDirection: 'row',
        backgroundColor: '#eeeeee',
    },
    tableHeadingPart: {
        flex: 0.25,
        padding: 7,
        justifyContent: 'flex-end'
    },
    tableRow: {
        flexDirection: 'row',
        marginTop: 10,
        marginBottom: 10,
        flexWrap: 'wrap'
    },
    tableSide: {
        flex: 0.5,
    },
    tableSideRow: {
        paddingTop: 7,
        paddingBottom: 7,
        flexDirection: 'row',
        borderBottomWidth: 1,
        borderColor: '#dddddd'
    },
    tableSidePart: {
        flex: 0.5,
        paddingLeft: 7,
        paddingRight: 7
    },
    tableRowPart: {
        flex: 0.25,
        justifyContent: 'flex-end',
    },
    alignRight: {
        alignItems: 'flex-end'
    },
    smallText: {
        fontSize: 11,
        color: '#596f95',
    },
    normalText: {
        fontSize: 11
    },
    pleft: {
        paddingLeft: 15,
    },
    pright: {
        paddingRight: 15
    },
    greenTableText: {
        color: '#50b85f'
    },
    redTableText: {
        color: '#b85050'
    },
    normalTableText: {
        color: '#efefef'
    },
    orange: {
        backgroundColor: '#ef5e47'
    },
    green: {
        backgroundColor: '#27ae60'
    },
})

export default connect(mapStateToProps, mapDispatchToComponent)(Orders);
