import React from 'react';
import {StyleSheet, ScrollView, TouchableOpacity} from 'react-native';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Container, Header, Title, Button, View, Text} from 'native-base';

import * as walletsActionCreators from '../../../../data/wallets/actions';
import * as fiatWalletsActionCreators from '../../../../data/fiatWallets/actions';
import * as ordersActionCreators from '../../../../data/orders/actions';

const mapStateToProps = state => {
  return {
    wallets: state.data.wallets,
    fiatWallets: state.data.fiatWallets,
  };
};
const mapDispatchToComponent = dispatch => ({
  actions: {
    wallets: bindActionCreators(walletsActionCreators, dispatch),
    fiatWallets: bindActionCreators(fiatWalletsActionCreators, dispatch),
    orders: bindActionCreators(ordersActionCreators, dispatch),
  },
});

class Wallets extends React.Component {
  constructor() {
    super();
  }

  componentDidMount() {
    console.log("get wallets wallets");

    this.props.actions.wallets.getWallets();
    this.props.actions.fiatWallets.getFiatWallets();
  }

  changeTabs = number => {
    this.props.changeTabs(number);
  };

  render() {
    const wallets = this.props.wallets.data;
    const fiatWallets = this.props.fiatWallets.data;
    return (
      <View style={[styles.background]}>
        <Text fonts style={[styles.title]}>
          Fiat Wallet Balances
        </Text>
        <View style={{flex: 1}}>
          <ScrollView>
            <TitleRow />
            {fiatWallets.map((item, i) => (
              <WalletRow
                key={i}
                wallet={item}
                changeTabs={this.changeTabs.bind(this)}
                no={i}
              />
            ))}
          </ScrollView>
        </View>
        <Text fonts style={[styles.title]}>
          Crypto Wallet Balances
        </Text>
        <View style={{flex: 1}}>
          <ScrollView>
            <TitleRow />
            {wallets.map((item, i) => (
              <WalletRow
                key={i}
                wallet={item}
                changeTabs={this.changeTabs.bind(this)}
                no={i}
              />
            ))}
          </ScrollView>
        </View>
      </View>
    );
  }
}

class WalletRow extends React.Component {
  changeTabs = (number, wallet) => {
    this.props.changeTabs(number);
    this.props.actions.orders.wallet(wallet);
  };

  render() {
    const {wallet, no} = this.props;
    let evenRow = no % 2 == 0;
    return (
      <View style={[styles.row, evenRow && styles.evenRow]}>
        <View style={styles.rowPart}>
          <Text style={styles.walletName}>{wallet.currency}</Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={styles.walletName}>{wallet.available}</Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={styles.walletName}>{wallet.pending}</Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={styles.walletName}>
            {wallet.withdraw_pending}
          </Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={styles.walletName}>
            {wallet.total_balance} {wallet.currency}
          </Text>
        </View>
      </View>
    );
  }
}

class TitleRow extends React.Component {
  render() {
    return (
      <View style={[styles.row]}>
        <View style={[styles.rowPart]}>
          <Text style={[styles.walletName, styles.walletTitle]}>Currency</Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={[styles.walletName, styles.walletTitle]}>Available</Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={[styles.walletName, styles.walletTitle]}>
            Exchange Pend.
          </Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={[styles.walletName, styles.walletTitle]}>
            Withdraw Pend.
          </Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={[styles.walletName, styles.walletTitle]}>Total</Text>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  background: {
    backgroundColor: '#eeeeee',
    flex: 1,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 10,
    marginBottom: 10,
  },
  row: {
    flexDirection: 'row',
    backgroundColor: '#eeeeee',
  },
  evenRow: {
    backgroundColor: '#fbfbfb',
  },
  rowPart: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  walletName: {
    color: '#3c4a55',
    fontSize: 11,
    paddingTop: 15,
    paddingBottom: 15,
  },
  walletTitle: {
    fontWeight: 'bold',
  },
});

export default connect(mapStateToProps, mapDispatchToComponent)(Wallets);
