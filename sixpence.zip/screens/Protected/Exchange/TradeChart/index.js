import React from 'react';
import {
  StyleSheet,
  ScrollView,
  Image,
  ImageBackground,
  Platform,
} from 'react-native';
import {
  Container,
  Title,
  Button,
  View,
  Text,
  Item,
  Input,
  Form,
  Label,
  Content,
  CheckBox,
  Body,
  Toast,
} from 'native-base';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import apiconfig from '../../../../services/api/config';
import Loading from '../../../Main/Loading';
import {
  Banner,
  Wrapper,
  TopProtectedNavigationBar,
  BottomProtectedNavigationBar,
} from '../../../../static';
import SelectDropdown from 'react-native-select-dropdown';
import {WebView} from 'react-native-webview';
import * as usersAPI from '../../../../data/users/api';
import * as API from '../../../../services/api';
import * as orderSelectors from '../../../../data/orders/selectors';
import * as orderActionCreators from '../../../../data/orders/actions';
import * as walletsActionCreators from '../../../../data/wallets/actions';
import * as fiatWalletsActionCreators from '../../../../data/fiatWallets/actions';
import AndroidChart, {AndroidApp} from '../../../../services/android.app';
import IOSChart, {IOSApp} from '../../../../services/ios.app';

const mapStateToProps = state => {
  return {
    orders: state.data.orders,
    wallets: state.data.wallets,
    fiatWallets: state.data.fiatWallets,
  };
};

const mapDispatchToComponent = dispatch => ({
  actions: {
    orders: bindActionCreators(orderActionCreators, dispatch),
    wallets: bindActionCreators(walletsActionCreators, dispatch),
    fiatWallets: bindActionCreators(fiatWalletsActionCreators, dispatch),
  },
});

class TradeChart extends React.Component {
  constructor(marketName) {
    super();
    this.state = {
      email: '',
      amount: 0,
      rate: 0,
      loading: false,
      showToast: false,
      activeTab: 'favourite',
    };
    console.log('cons n', marketName);
    this.changeTab = this.changeTab.bind(this);
    this.changeTabFavourite = this.changeTabFavourite.bind(this);
    this.reloadData = this.reloadData.bind(this);
  }

  componentDidMount() {

    console.log('initial:', this.props.orders);
    this.reloadData();
  }

  async reloadData() {

    const {market} = this.props.navigation.state.params;
    this.market = market;


    this.props.actions.wallets.getWallets();
    this.props.actions.fiatWallets.getFiatWallets();
    await this.props.actions.orders.getMarketDetail(  this.market.name);



    this.props.actions.orders
      .getOrderBook(  this.market.name)
      .catch(error => {
        console.log('get orderbook error', error);
      });

    this.props.actions.orders.getMarketHistories(  this.market.name);

    // this.props.actions.orders.balance(  this.market.name, this.props.wallets, this.props.fiatWallets, 0);
    // this.props.actions.orders.balance(this.props.orders.market, this.props.wallets, this.props.fiatWallets, 1);
  }

  changeTab() {
    this.setState({
      activeTab: 'spot',
    });
  }

  changeTabFavourite() {
    this.setState({
      activeTab: 'favourite',
    });
  }

  showCryptoName() {
    const {marketDetail} = this.props.orders;
    if (marketDetail && marketDetail.name) {
      let parts = marketDetail.name.split('-');
      return parts[0];
    }
  }

  showFiatName() {
    const {marketDetail} = this.props.orders;
    if (marketDetail && marketDetail.name) {
      let parts = marketDetail.name.split('-');
      return parts[1];
    }
  }

  render() {
    const {navigate} = this.props.navigation;
    const {
      open_orders,
      market_histories,
      orderbook_sell,
      orderbook_buy,
     } = this.props.orders;



    const countries = ['Egypt', 'Canada', 'Australia', 'Ireland'];

    return (
      <React.Fragment>
        <ScrollView style={styles.background}>
          {this.state.loading && <Loading />}
          {!this.state.loading && this.props.orders.market == '' && (
            <Container style={styles.background}>
              <TopProtectedNavigationBar navigate={navigate} name="Market" />
              <View style={{textAlign: 'center'}}>
                <Text
                  style={{
                    color: '#CFD7E3',
                    marginTop: 20,
                    fontSize: 12,
                    marginLeft: 'auto',
                    marginRight: 'auto',
                  }}>
                  Please select a market, to view this page
                </Text>
                <View
                  style={{flexDirection: 'row', marginLeft: 20, marginTop: 20}}>
                  <View style={{flex: 1}}>
                    <Button
                      onPress={() => navigate('Markets', {screen: 'Markets'})}
                      block
                      style={[styles.button, styles.orange]}>
                      <Text>Select Market</Text>
                    </Button>
                  </View>
                </View>
              </View>
            </Container>
          )}
          {!this.state.loading &&
              this.market &&
            this.props.orders.market != '' && (
              <Container style={styles.background}>
                {/* <Banner /> */}
                <TopProtectedNavigationBar
                  navigate={navigate}
                  name={  this.market.name}
                />
                <View style={{padding: 15}}>
                  <View
                    style={{
                      backgroundColor: '#232323',
                      flexDirection: 'row',
                      padding: 15,
                      borderRadius: 12,
                    }}>
                    <View style={{flex: 3}}>
                      <Text style={{color: '#fff', fontSize: 22}}>
                        {  this.market.last}
                      </Text>
                      <View style={{flexDirection: 'row', marginTop: 10}}>
                        <Text style={{color: '#CFD7E3', fontSize: 12}}>
                          {  this.market.name}
                        </Text>
                      </View>
                      <View style={{flexDirection: 'row', marginTop: 10}}>
                        <Text
                          style={{
                            color:
                                this.market.change_24h_percent < 0
                                ? '#F85F5F'
                                : '#43D882',
                            fontSize: 12,
                          }}>
                          {parseFloat(  this.market.change_24h_percent).toFixed(2)}%
                        </Text>
                      </View>
                    </View>
                    <View style={{flex: 2}}>
                      <View style={{flexDirection: 'row'}}>
                        <View style={{flex: 1}}>
                          <Text style={{fontSize: 8, color: '#CFD7E3'}}>
                            24h High
                          </Text>
                          <Text style={{fontSize: 8, color: '#CFD7E3'}}>
                            {  this.market.high_24h}
                          </Text>
                          <Text
                            style={{
                              fontSize: 8,
                              color: '#CFD7E3',
                              marginTop: 10,
                            }}>
                            24h Low
                          </Text>
                          <Text style={{fontSize: 8, color: '#CFD7E3'}}>
                            {  this.market.low_24h}
                          </Text>
                        </View>
                        <View style={{flex: 1}}>
                          <Text style={{fontSize: 8, color: '#CFD7E3'}}>
                            24h Vol({this.market.currency})
                          </Text>
                          <Text style={{fontSize: 8, color: '#CFD7E3'}}>
                            {  this.market.volume_24h}
                          </Text>

                        </View>
                      </View>
                    </View>
                  </View>
                </View>
                {Platform.OS === 'android' && (
                  <AndroidChart market={  this.market.name} />
                )}
                {Platform.OS === 'ios' && (
                  <IOSChart market={  this.market.name} />
                )}

                <View
                  style={{
                    backgroundColor: '#232323',
                    flexDirection: 'row',
                    marginTop: 12,
                  }}>
                  <View style={{flex: 2}}>
                    <View
                      style={[
                        this.state.activeTab == 'favourite'
                          ? styles.pageTabSectionActive
                          : styles.pageTabSection,
                      ]}>
                      <Text
                        onPress={this.changeTabFavourite}
                        style={[
                          this.state.activeTab == 'favourite'
                            ? styles.pageTabTextActive
                            : styles.pageTabText,
                        ]}>
                        Orderbook
                      </Text>
                    </View>
                  </View>
                  <View style={{flex: 2}}>
                    <View
                      style={[
                        this.state.activeTab == 'spot'
                          ? styles.pageTabSectionActive
                          : styles.pageTabSection,
                      ]}>
                      <Text
                        onPress={this.changeTab}
                        style={[
                          this.state.activeTab == 'spot'
                            ? styles.pageTabTextActive
                            : styles.pageTabText,
                        ]}>
                        Market History
                      </Text>
                    </View>
                  </View>
                  <View style={{flex: 2}} />
                </View>

                <View style={{paddingLeft: 5, paddingRight: 5}}>
                  {this.state.activeTab == 'favourite' && (
                    <React.Fragment>
                      <View style={{flexDirection: 'row', marginTop: 15}}>
                        <View style={{flex: 1}}>
                          <View
                            style={{marginRight: 'auto', textAlign: 'left'}}>
                            <Text
                              style={{
                                fontSize: 8,
                                color: '#9C9E9D',
                                marginRight: 'auto',
                              }}>
                              Amount
                            </Text>
                          </View>
                        </View>
                        <View style={{flex: 1}}>
                          <View
                            style={{
                              marginLeft: 'auto',
                              marginRight: 0,
                              textAlign: 'right',
                            }}>
                            <Text
                              style={{
                                fontSize: 8,
                                color: '#9C9E9D',
                              }}>
                              Asks
                            </Text>
                          </View>
                        </View>

                        <View style={{flex: 1}}>
                          <View
                            style={{
                              marginLeft: 'auto',
                              marginRight: 'auto',
                              textAlign: 'center',
                            }}>
                            <Text
                              style={{
                                fontSize: 8,
                                color: '#9C9E9D',
                                marginLeft: 'auto',
                                marginRight: 'auto',
                              }}>
                              Bids
                            </Text>
                          </View>
                        </View>

                        <View style={{flex: 1}}>
                          <View
                            style={{
                              marginLeft: 'auto',
                              marginRight: 0,
                              textAlign: 'right',
                            }}>
                            <Text
                              style={{
                                fontSize: 8,
                                color: '#9C9E9D',
                                marginLeft: 'auto',
                                marginRight: 'auto',
                              }}>
                              Amount
                            </Text>
                          </View>
                        </View>
                      </View>

                      {orderbook_sell &&
                        orderbook_sell.length == 0 &&
                        orderbook_buy.length == 0 && (
                          <Text
                            style={{color: '#fff', fontSize: 8, marginTop: 10}}>
                            No orders
                          </Text>
                        )}

                      <View style={{display: 'flex', flexDirection: 'row'}}>
                        <View style={{width: '50%'}}>
                          {orderbook_sell &&
                            orderbook_sell.map((item, i) => (
                              <View
                                key={'osm-' + i}
                                style={{flexDirection: 'row', marginTop: 10}}>
                                <View style={{flex: 3}}>
                                  <View
                                    style={{
                                      marginLeft: 0,
                                      marginRight: 'auto',
                                      textAlign: 'left',
                                      flexDirection: 'row',
                                    }}>
                                    <Text
                                      style={{
                                        fontSize: 10,
                                        color: '#9C9E9D',
                                        marginLeft: 'auto',
                                        marginRight: 'auto',
                                      }}>
                                      {item.quantity}
                                    </Text>
                                  </View>
                                </View>
                                <View style={{flex: 2}}>
                                  <View
                                    style={{
                                      marginLeft: 'auto',
                                      textAlign: 'center',
                                    }}>
                                    <Text
                                      style={{
                                        fontSize: 10,
                                        color: '#F85F5F',
                                        marginLeft: 'auto',
                                        marginRight: 'auto',
                                      }}>
                                      {item.rate}
                                    </Text>
                                  </View>
                                </View>
                              </View>
                            ))}
                        </View>
                        <View style={{width: '50%'}}>
                          {orderbook_buy.map((item, i) => (
                            <View
                              key={'osm-' + i}
                              style={{flexDirection: 'row', marginTop: 10}}>
                              <View style={{flex: 3}}>
                                <View
                                  style={{
                                    marginLeft: 'auto',
                                    marginRight: 'auto',
                                    textAlign: 'center',
                                    flexDirection: 'row',
                                  }}>
                                  <Text
                                    style={{
                                      fontSize: 10,
                                      color: '#43D882',
                                      marginLeft: 'auto',
                                      marginRight: 'auto',
                                    }}>
                                    {item.rate}
                                  </Text>
                                </View>
                              </View>
                              <View style={{flex: 2}}>
                                <View
                                  style={{
                                    marginLeft: 'auto',
                                    textAlign: 'center',
                                  }}>
                                  <Text
                                    style={{
                                      fontSize: 10,
                                      color: '#9C9E9D',
                                      marginLeft: 'auto',
                                      marginRight: 'auto',
                                    }}>
                                    {item.quantity}
                                  </Text>
                                </View>
                              </View>
                            </View>
                          ))}
                        </View>
                      </View>
                    </React.Fragment>
                  )}

                  {this.state.activeTab == 'spot' && (
                    <React.Fragment>
                      <View style={{flexDirection: 'row', marginTop: 15}}>
                        <View style={{flex: 1}}>
                          <View
                            style={{marginRight: 'auto', textAlign: 'left'}}>
                            <Text
                              style={{
                                fontSize: 8,
                                color: '#9C9E9D',
                                marginRight: 'auto',
                              }}>
                              Type
                            </Text>
                          </View>
                        </View>
                        <View style={{flex: 1}}>
                          <View
                            style={{
                              marginLeft: 'auto',
                              marginRight: 'auto',
                              textAlign: 'center',
                            }}>
                            <Text
                              style={{
                                fontSize: 8,
                                color: '#9C9E9D',
                                marginLeft: 'auto',
                                marginRight: 'auto',
                              }}>
                              Rate
                            </Text>
                          </View>
                        </View>
                        <View style={{flex: 1}}>
                          <View
                            style={{marginLeft: 'auto', textAlign: 'center'}}>
                            <Text
                              style={{
                                fontSize: 8,
                                color: '#9C9E9D',
                                marginLeft: 'auto',
                              }}>
                              Amount
                            </Text>
                          </View>
                        </View>
                        <View style={{flex: 1}}>
                          <View
                            style={{marginLeft: 'auto', textAlign: 'right'}}>
                            <Text
                              style={{
                                fontSize: 8,
                                color: '#9C9E9D',
                                marginLeft: 'auto',
                              }}>
                              Date
                            </Text>
                          </View>
                        </View>
                      </View>
                      {open_orders &&
                        open_orders.length > 0 &&
                        open_orders.map((item, i) => (
                          <View
                            key={'mo-' + i}
                            style={{flexDirection: 'row', marginTop: 10}}>
                            <View style={{flex: 1}}>
                              <View
                                style={{
                                  marginRight: 'auto',
                                  textAlign: 'left',
                                }}>
                                {item.type == 'SELL' && (
                                  <Text
                                    style={{
                                      fontSize: 8,
                                      color: '#F85F5F',
                                      marginRight: 'auto',
                                    }}>
                                    SELL
                                  </Text>
                                )}
                                {item.type == 'SELL_LIMIT' && (
                                  <Text
                                    style={{
                                      fontSize: 8,
                                      color: '#F85F5F',
                                      marginRight: 'auto',
                                    }}>
                                    SELL LIMIT
                                  </Text>
                                )}
                              </View>
                            </View>
                            <View style={{flex: 3}}>
                              <View
                                style={{
                                  marginLeft: 'auto',
                                  marginRight: 'auto',
                                  textAlign: 'center',
                                  flexDirection: 'row',
                                }}>
                                <Text
                                  style={{
                                    fontSize: 10,
                                    color: '#F85F5F',
                                    marginLeft: 'auto',
                                    marginRight: 'auto',
                                  }}>
                                  {item.rate}
                                </Text>
                              </View>
                            </View>
                            <View style={{flex: 1}}>
                              <View
                                style={{
                                  marginLeft: 'auto',
                                  textAlign: 'center',
                                }}>
                                <Text
                                  style={{
                                    fontSize: 10,
                                    color: '#9C9E9D',
                                    marginLeft: 'auto',
                                    marginRight: 'auto',
                                  }}>
                                  {item.quantity}
                                </Text>
                              </View>
                            </View>
                          </View>
                        ))}
                      {market_histories &&
                        market_histories.length > 0 &&
                        market_histories.map((item, i) => (
                          <View
                            key={'buymap-' + i}
                            style={{flexDirection: 'row', marginTop: 10}}>
                            <View style={{flex: 1}}>
                              <View
                                style={{
                                  marginRight: 'auto',
                                  textAlign: 'left',
                                }}>
                                {item.type == 'buy' && (
                                  <Text
                                    style={{
                                      fontSize: 8,
                                      color: '#43D882',
                                      marginRight: 'auto',
                                    }}>
                                    BUY
                                  </Text>
                                )}
                                {item.type == 'sell' && (
                                  <Text
                                    style={{
                                      fontSize: 8,
                                      color: '#43D882',
                                      marginRight: 'auto',
                                    }}>
                                    BUY
                                  </Text>
                                )}
                              </View>
                            </View>
                            <View style={{flex: 3}}>
                              <View
                                style={{
                                  marginLeft: 'auto',
                                  marginRight: 'auto',
                                  textAlign: 'center',
                                  flexDirection: 'row',
                                }}>
                                <Text
                                  style={{
                                    fontSize: 10,
                                    color: '#fff',
                                    marginLeft: 'auto',
                                    marginRight: 'auto',
                                  }}>
                                  {item.rate}
                                </Text>
                                {/* <Text style={{ fontSize: 10, color: '#F85F5F', marginLeft: 'auto', marginRight: 'auto',  }}>32,456.50(USDT)</Text> */}
                              </View>
                            </View>
                            <View style={{flex: 1}}>
                              <View
                                style={{
                                  marginLeft: 'auto',
                                  textAlign: 'center',
                                }}>
                                <Text
                                  style={{
                                    fontSize: 10,
                                    color: '#9C9E9D',
                                    marginLeft: 'auto',
                                    marginRight: 'auto',
                                  }}>
                                  {item.amount}
                                </Text>
                              </View>
                            </View>
                            <View style={{flex: 1}}>
                              <View
                                style={{
                                  marginLeft: 'auto',
                                  textAlign: 'center',
                                }}>
                                <Text
                                  style={{
                                    fontSize: 10,
                                    color: '#9C9E9D',
                                    marginLeft: 'auto',
                                    marginRight: 'auto',
                                  }}>
                                  {item.time}
                                </Text>
                              </View>
                            </View>
                          </View>
                        ))}
                    </React.Fragment>
                  )}

                  <View
                    style={{
                      backgroundColor: '#232323',
                      flexDirection: 'row',
                      marginTop: 12,
                      padding: 15,
                    }}>
                    <View style={{flex: 1}}>
                      <View style={{flexDirection: 'row'}}>
                        <Image
                          style={{
                            width: 30,
                            resizeMode: 'contain',
                            marginTop: 13,
                          }}
                          source={require('../../../../static/images/tradebell.png')}
                        />
                        <Text
                          style={{color: '#fff', fontSize: 12, marginTop: 14}}>
                          Trade
                        </Text>
                      </View>
                    </View>
                    <View style={{flex: 1}}>
                      <View style={{flexDirection: 'row'}}>
                        <View style={{flex: 1}}>
                          <Button
                            onPress={() => navigate('Trade', {screen: 'Trade'})}
                            block
                            style={[styles.button, styles.green]}>
                            <Text style={{fontSize: 12}}>BUY</Text>
                          </Button>
                        </View>
                        <View style={{flex: 1}}>
                          <Button
                            onPress={() => navigate('Trade', {screen: 'Trade'})}
                            block
                            style={[styles.button, styles.orange]}>
                            <Text style={{fontSize: 12}}>SELL</Text>
                          </Button>
                        </View>
                      </View>
                    </View>
                  </View>
                  {/* </View> */}
                  {/* <View style={styles.formgroup}>
                <Form>
                  <Text style={{marginTop: 15, color: '#fff', fontSize: 13}}>Password</Text>
                  <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                    <Input
                      style={styles.inputfield}
                      placeholder={'E-mail address'}
                      onChangeText={text => this.setState({email: text})}
                    />
                  </Item>
                  <Button
                    block
                    style={[styles.button, styles.orange]}
                    onPress={this.triggerForgot}>
                    <Text>Reset password</Text>
                  </Button>
                </Form>
              </View> */}
                </View>
              </Container>
            )}

          <View style={{height: 200}} />
        </ScrollView>
        <BottomProtectedNavigationBar navigate={navigate} name="Trade" />
      </React.Fragment>
    );
  }
}

const styles = StyleSheet.create({
  background: {
    backgroundColor: '#000',
  },
  container: {
    alignItems: 'center',
    flexGrow: 1,
    justifyContent: 'center',
  },
  logo: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    width: 300,
    height: 100,
  },
  logoText: {
    color: '#fefefe',
    fontSize: 36,
  },
  smallText: {
    color: '#fefefe',
    fontSize: 18,
  },
  button: {
    marginTop: 0,
    textAlign: 'center',
    borderRadius: 9,
    marginLeft: 5,
  },
  formgroup: {
    padding: 15,
  },
  inputfield: {
    padding: 1,
    paddingLeft: 35,
    paddingRight: 15,
    fontSize: 10,
    backgroundColor: '#343434',
    borderColor: '#343434',
    borderRadius: 6,
    height: 35,
  },
  orange: {
    backgroundColor: '#FFAB00',
  },
  green: {
    backgroundColor: '#43D882',
  },
  topLogoBackground: {
    textAlign: 'center',
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20,
  },
  pageTabSection: {
    paddingTop: 15,
    paddingBottom: 15,
    marginLeft: 'auto',
    marginRight: 'auto',
    textAlign: 'center',
  },
  pageTabSectionActive: {
    paddingTop: 15,
    paddingBottom: 15,
    marginLeft: 'auto',
    marginRight: 'auto',
    textAlign: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#FFAB00',
  },
  pageTabText: {
    fontSize: 14,
    color: '#fff',
    marginLeft: 'auto',
    marginRight: 'auto',
  },
  pageTabTextActive: {
    fontSize: 14,
    color: '#FFAB00',
    marginLeft: 'auto',
    marginRight: 'auto',
  },
});

export default connect(mapStateToProps, mapDispatchToComponent)(TradeChart);
