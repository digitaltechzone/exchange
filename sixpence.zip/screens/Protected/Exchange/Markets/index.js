import React from 'react';
import {StyleSheet, ScrollView, TouchableOpacity} from 'react-native';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Container, Header, Title, Button, View, Text} from 'native-base';

import * as marketsActionCreators from '../../../../data/markets/actions';
import * as ordersActionCreators from '../../../../data/orders/actions';

const mapStateToProps = state => {
  return {
    markets: state.data.markets,
  };
};
const mapDispatchToComponent = dispatch => ({
  actions: {
    markets: bindActionCreators(marketsActionCreators, dispatch),
    orders: bindActionCreators(ordersActionCreators, dispatch),
  },
});

class Markets extends React.Component {
  constructor() {
    super();
  }

  componentDidMount() {
    this.props.actions.markets.get();
  }

  changeNavigation = navigatorName => {
    this.props.changeNavigation(navigatorName);
  };

  render() {
    const data = this.props.markets.data;
    return (
      <View style={{flex: 1}}>
        <ScrollView style={styles.background}>
          <View style={[styles.row]}>
            <View style={[styles.rowPart]}>
              <Text style={[styles.marketName, styles.marketTitle]}>
                Market
              </Text>
            </View>
            <View style={styles.rowPart}>
              <Text style={[styles.marketName, styles.marketTitle]}>
                Currency
              </Text>
            </View>
            <View style={styles.rowPart}>
              <Text style={[styles.marketName, styles.marketTitle]}>Price</Text>
            </View>
            <View style={styles.rowPart}>
              <Text style={[styles.marketName, styles.marketTitle]}>
                24h{'\n'}Volume
              </Text>
            </View>
            <View style={styles.rowPart}>
              <Text style={[styles.marketName, styles.marketTitle]}>
                24h{'\n'}Highest
              </Text>
            </View>
            <View style={styles.rowPart}>
              <Text style={[styles.marketName, styles.marketTitle]}>
                24h{'\n'}Lowest
              </Text>
            </View>
            <View style={styles.rowPart}>
              <Text style={[styles.marketName, styles.marketTitle]}>
                24h{'\n'}Change
              </Text>
            </View>
            <View style={styles.rowPart}>
              <Text style={[styles.marketName, styles.marketTitle]}>
                Buy/Sell
              </Text>
            </View>
          </View>
          {data.map((item, i) => (
            <MarketRow
              key={i}
              market={item}
              changeNavigation={this.changeNavigation.bind(this)}
              actions={this.props.actions}
              no={i}
            />
          ))}
        </ScrollView>
      </View>
    );
  }
}

class MarketRow extends React.Component {
  changeNavigation = (navigatorName, market) => {
    this.props.changeNavigation(navigatorName);
    this.props.actions.orders.market(market);
  };

  render() {
    const {market, no} = this.props;
    let evenRow = no % 2 == 0;
    return (
      <View style={[styles.row, evenRow && styles.evenRow]}>
        <View style={styles.rowPart}>
          <Text style={styles.marketName}>{market.name}</Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={styles.marketName}>{market.currency_name}</Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={styles.marketName}>
            {parseFloat(market.bid).toFixed(2)} {market.fiat_currency}
          </Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={styles.marketName}>{parseFloat(market.volume_24h).toFixed(2)}</Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={styles.marketName}>{parseFloat(market.high_24h).toFixed(2)}</Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={styles.marketName}>{parseFloat(market.low_24h).toFixed(2)}</Text>
        </View>
        <View style={styles.rowPart}>
          <Text style={styles.marketName}>{parseFloat(market.change_24h).toFixed(2)}</Text>
        </View>
        <View style={styles.rowPart}>
          <TouchableOpacity
            onPress={() => {
              this.changeNavigation('Orders', market.name);
            }}>
            <Text style={styles.buySell}>Buy/Sell</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  background: {
    backgroundColor: '#eeeeee',
    flex: 1,
  },
  row: {
    flexDirection: 'row',
    backgroundColor: '#eeeeee',
  },
  evenRow: {
    backgroundColor: '#fbfbfb',
  },
  rowPart: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  marketName: {
    color: '#3c4a55',
    fontSize: 11,
    paddingTop: 15,
    paddingBottom: 15,
  },
  buySell: {
    color: '#ffffff',
    backgroundColor: '#27ae60',
    fontSize: 11,
    padding: 5,
  },
  marketTitle: {
    fontWeight: 'bold',
  },
});

export default connect(mapStateToProps, mapDispatchToComponent)(Markets);
