import React from 'react';
import {StyleSheet, ScrollView, TouchableOpacity} from 'react-native';
import {
  Container,
  Header,
  Title,
  Button,
  View,
  Text,
  Tab,
  Tabs,
  DefaultTabBar,
} from 'native-base';

import Orders from './Orders';
import Markets from './Markets';
import Wallets from './Wallets';
import Home from './Home';

class Exchange extends React.Component {
  constructor() {
    super();
  }

  // Heading navigation
  static navigationOptions = ({navigation}) => ({
    title: 'Exchangess',
    headerTitleStyle: {
      textAlign: 'center',
      alignSelf: 'center',
      color: '#fefefe',
    },
    headerStyle: {
      backgroundColor: '#3c4a55',
    },
  });

  changeTabs = number => {
    this._tabs.goToPage(number);
  };

  changeNavigation = navigatorName => {
    this.props.navigation.navigate(navigatorName);
  };




  render() {
    const tabProps = {
      underlineStyle: {backgroundColor: '#3c4a55'},
    };
    return (
      <Container style={styles.background}>
        <Tabs
          initialPage={1}
          ref={t => (this._tabs = t)}
          tabBarUnderlineStyle={styles.border}
          renderTabBar={renderTabBar}>

          <Tab
            heading="Home"
            tabStyle={styles.tabBg}
            textStyle={styles.tabText}
            activeTabStyle={styles.activeTab}
            activeTextStyle={{color: '#3297da'}}>
            <Home changeTabs={this.changeTabs.bind(this)} />
          </Tab>
          <Tab
            heading="Wallets"
            tabStyle={styles.tabBg}
            textStyle={styles.tabText}
            activeTabStyle={styles.activeTab}
            activeTextStyle={{color: '#3297da'}}>
            <Wallets changeTabs={this.changeTabs.bind(this)} />
          </Tab>
          <Tab
            heading="Markets"
            tabStyle={styles.tabBg}
            textStyle={styles.tabText}
            activeTabStyle={styles.activeTab}
            activeTextStyle={{color: '#3297da'}}>
            <Markets
              changeTabs={this.changeTabs.bind(this)}
              changeNavigation={this.changeNavigation.bind(this)}
            />
          </Tab>
          <Tab
            heading="Orders"
            tabStyle={styles.tabBg}
            textStyle={styles.tabText}
            activeTabStyle={styles.activeTab}
            activeTextStyle={{color: '#3297da'}}>
            <Orders changeTabs={this.changeTabs.bind(this)} />
          </Tab>
        </Tabs>
      </Container>
    );
  }
}

const renderTabBar = (props) => {
  props.tabStyle = Object.create(props.tabStyle);
  return <DefaultTabBar {...props} />;
};
const styles = StyleSheet.create({
  background: {
    backgroundColor: '#eeeeee',
  },
  tabBg: {
    backgroundColor: '#ffffff',
  },
  tabText: {
    color: '#3c4a55',
  },
  activeTab: {
    backgroundColor: '#ffffff',
  },
  border: {
    borderColor: '#3297da',
    borderBottomWidth: 4,
  },
});

export default Exchange;
