import React from 'react';
import {
  StyleSheet,
  ScrollView,
  Image,
  ImageBackground,
  TouchableOpacity,
} from 'react-native';
import {
  Container,
  Title,
  Button,
  View,
  Text,
  Item,
  Input,
  Form,
  Label,
  Content,
  CheckBox,
  Body,
  Toast,
} from 'native-base';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import Loading from '../../../Main/Loading';
import {
  Banner,
  Wrapper,
  TopProtectedNavigationBar,
  BottomProtectedNavigationBar,
} from '../../../../static';
import * as walletsActionCreators from '../../../../data/wallets/actions';
import * as fiatWalletsActionCreators from '../../../../data/fiatWallets/actions';
import * as ordersActionCreators from '../../../../data/orders/actions';
import * as marketsActionCreators from '../../../../data/markets/actions';

import * as usersAPI from '../../../../data/users/api';
import * as API from '../../../../services/api';
import store from '../../../../store';

const mapStateToProps = state => {
  return {
    wallets: state.data.wallets,
    fiatWallets: state.data.fiatWallets,
    markets: state.data.markets,
    orders: state.data.orders,
  };
};
const mapDispatchToComponent = dispatch => ({
  actions: {
    wallets: bindActionCreators(walletsActionCreators, dispatch),
    fiatWallets: bindActionCreators(fiatWalletsActionCreators, dispatch),
    orders: bindActionCreators(ordersActionCreators, dispatch),
    markets: bindActionCreators(marketsActionCreators, dispatch),
  },
});

class Dashboard extends React.Component {
  constructor() {
    super();
    this.state = {
      email: '',
      loading: false,
      showToast: false,
    };
    // console.log('session dash', store.getState().services.session);
  }

  componentDidMount() {
    // console.log("DASHBOARD - getWallets");
    // this.props.actions.wallets.getWallets();
    //console.log('DASHBOARD - getFiatWallets');
    //   this.props.actions.fiatWallets.getFiatWallets();
    //console.log('DASHBOARD - markets.get');
    //  this.props.actions.markets.get();
    this.props.actions.orders.getTrendingMarkets();
  }



  render() {
    const {navigate} = this.props.navigation;
    const wallets = this.props.wallets.data;
    const fiatWallets = this.props.fiatWallets.data;
    const markets = this.props.markets.data;
    const {trending_markets} = this.props.orders;

    return (
      <ScrollView style={styles.background}>
        {this.state.loading && <Loading />}
        {!this.state.loading && (
          <Container style={styles.background}>
            {/* <Banner /> */}
            <TopProtectedNavigationBar navigate={navigate} name="Dashboard" />
            <View style={styles.topLogoBackground}>
              {/* <Image style={{marginTop: 30}} source={require('../../../../static/images/kriptoist.png')} /> */}
            </View>
            <View style={{padding: 5}}>
              {/* <View style={{width: 280, height: 140, bac: }}> */}
              <ScrollView horizontal={true}>
                {fiatWallets.map((item, i) => (
                  <ImageBackground
                    key={i + 'cards'}
                    style={{
                      flex: 1,
                      backgroundColor: '#000',
                      width: 280,
                      height: 140,
                      left: 0,
                      right: 0,
                      top: 0,
                      marginRight: 20,
                    }}
                    source={require('../../../../static/images/dashboardwallet.png')}>
                    <TouchableOpacity
                      onPress={() => navigate('Wallet', {screen: 'Wallet'})}>
                      <Image
                        style={{
                          position: 'absolute',
                          left: 0,
                          width: 40,
                          marginTop: 20,
                          resizeMode: 'contain',
                        }}
                        source={require('../../../../static/images/money.png')}
                      />
                      <View style={{marginLeft: 40}}>
                        <Text style={{color: '#fff', marginTop: 15}}>Cash</Text>
                      </View>
                      <Image
                        style={{
                          position: 'absolute',
                          right: 0,
                          width: 40,
                          marginTop: 15,
                          resizeMode: 'contain',
                        }}
                        source={require('../../../../static/images/dashboardicon.png')}
                      />
                      <View style={{marginLeft: 10}}>
                        <Text style={{color: '#fff', marginTop: 25}}>
                          Balance
                        </Text>
                      </View>
                      <View style={{marginLeft: 10}}>
                        <Text style={{color: '#fff', marginTop: 10}}>
                          {item.currency} {item.total_balance}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  </ImageBackground>
                ))}
              </ScrollView>

              <View
                style={{
                  backgroundColor: '#232323',
                  padding: 20,
                  borderRadius: 12,
                  flexDirection: 'row',
                  marginTop: 25,
                }}>
                <View style={{flex: 1}}>
                  <View
                    style={{
                      marginLeft: 'auto',
                      marginRight: 'auto',
                      textAlign: 'center',
                    }}>
                    <TouchableOpacity
                      onPress={() => navigate('Wallet', {screen: 'Wallet'})}>
                      <Image
                        style={{width: 30, resizeMode: 'contain'}}
                        source={require('../../../../static/images/creditcard-add.png')}
                      />
                      <Text
                        style={{
                          fontSize: 9,
                          color: '#fff',
                          marginLeft: 'auto',
                          marginRight: 'auto',
                        }}>
                        Deposit
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
                <View style={{flex: 1}}>
                  <View
                    style={{
                      marginLeft: 'auto',
                      marginRight: 'auto',
                      textAlign: 'center',
                    }}>
                    <TouchableOpacity
                      onPress={() =>
                        navigate('Trade', {screen: 'Trade'})                      }>
                      <Image
                        style={{
                          width: 40,
                          resizeMode: 'contain',
                          marginTop: 10,
                        }}
                        source={require('../../../../static/images/chartlineup.png')}
                      />
                      <Text
                        style={{
                          fontSize: 9,
                          color: '#fff',
                          marginLeft: 'auto',
                          marginRight: 'auto',
                          marginTop: 13,
                        }}>
                        Trade
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
                <View style={{flex: 1}}>
                  <View
                    style={{
                      marginLeft: 'auto',
                      marginRight: 'auto',
                      textAlign: 'center',
                    }}>
                    <TouchableOpacity
                      onPress={() =>
                        navigate('Trade', {screen: 'Trade'})                      }>
                      <Image
                        style={{
                          width: 30,
                          resizeMode: 'contain',
                          marginTop: -30,
                        }}
                        source={require('../../../../static/images/tote.png')}
                      />
                      <Text
                        style={{
                          fontSize: 9,
                          color: '#fff',
                          marginLeft: 'auto',
                          marginRight: 'auto',
                          marginTop: -19,
                        }}>
                        Order
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
                <View style={{flex: 1}}>
                  <View
                    style={{
                      marginLeft: 'auto',
                      marginRight: 'auto',
                      textAlign: 'center',
                    }}>
                    <Image
                      style={{width: 40, resizeMode: 'contain', marginTop: 10}}
                      source={require('../../../../static/images/frame.png')}
                    />
                    <Text
                      style={{
                        fontSize: 9,
                        color: '#fff',
                        marginLeft: 'auto',
                        marginRight: 'auto',
                        marginTop: 13,
                      }}>
                      Referral
                    </Text>
                  </View>
                </View>
              </View>

              <TouchableOpacity
                onPress={() => navigate('Wallet', {screen: 'Wallet'})}>
                <View
                  style={{
                    backgroundColor: '#232323',
                    padding: 20,
                    borderRadius: 12,
                    flexDirection: 'row',
                    marginTop: 25,
                    height: 105,
                  }}>
                  <Image
                    style={{
                      position: 'absolute',
                      right: 50,
                      top: -35,
                      width: 150,
                      marginTop: 20,
                      resizeMode: 'contain',
                    }}
                    source={require('../../../../static/images/point-down.png')}
                  />
                  <Image
                    style={{
                      position: 'absolute',
                      left: 30,
                      bottom: 0,
                      width: 190,
                      marginTop: 20,
                      resizeMode: 'contain',
                    }}
                    source={require('../../../../static/images/point-up.png')}
                  />
                  <View style={{flex: 1}}>
                    <View
                      style={{
                        marginLeft: 'auto',
                        marginRight: 'auto',
                        textAlign: 'center',
                      }}>
                      <Image
                        style={{
                          width: 90,
                          resizeMode: 'contain',
                          marginLeft: -15,
                          marginTop: -40,
                        }}
                        source={require('../../../../static/images/dashitem1.png')}
                      />
                    </View>
                  </View>
                  <View style={{flex: 3}}>
                    <View
                      style={{
                        marginLeft: 'auto',
                        marginRight: 'auto',
                        textAlign: 'center',
                      }}>
                      <Text
                        style={{
                          fontSize: 22,
                          color: '#FFAB00',
                          marginLeft: 'auto',
                          marginRight: 'auto',
                          marginTop: 20,
                          marginBottom: 'auto',
                        }}>
                        Wallets
                      </Text>
                      {/* <Text style={{ fontSize: 8, color: '#43D882' }}>{JSON.stringify(markets)}</Text> */}
                    </View>
                  </View>
                  <View style={{flex: 1}}>
                    <View
                      style={{
                        marginLeft: 'auto',
                        marginRight: 'auto',
                        textAlign: 'center',
                      }}>
                      <Image
                        style={{
                          width: 40,
                          resizeMode: 'contain',
                          marginTop: 25,
                          marginLeft: 5,
                        }}
                        source={require('../../../../static/images/arrow-right.png')}
                      />
                    </View>
                  </View>
                </View>
              </TouchableOpacity>

              <ScrollView style={{marginTop: 35}} horizontal={true}>
                {trending_markets &&
                  trending_markets.map((market, i) => (
                    <TouchableOpacity
                      key={'mmap1-m-' + i}
                      onPress={() => {
                        navigate('TradeChart', {market: market}, 'market-'+market.id);
                      }}>
                      <View style={{width: 150, marginRight: 15}}>
                        <View style={{flexDirection: 'row'}}>
                          <View style={{flex: 2}}>
                            <Text style={{fontSize: 12, color: '#fff'}}>
                              {market.name}
                            </Text>
                          </View>
                          <View style={{flex: 1}}>
                            <View style={{textAlign: 'right'}}>
                              <Text style={{fontSize: 12, color: '#43D882'}}>
                                {parseFloat(market.change_24h_percent).toFixed(
                                  2,
                                )}
                                %
                              </Text>
                            </View>
                          </View>
                        </View>
                        <View style={{flexDirection: 'row'}}>
                          <View style={{flex: 1}}>
                            <View style={{textAlign: 'left'}}>
                              <Text style={{fontSize: 22, color: '#43D882'}}>
                                {market.last}
                              </Text>
                            </View>
                          </View>
                        </View>
                        <View style={{flexDirection: 'row'}}>
                          <View style={{flex: 1}}>
                            <View style={{textAlign: 'left'}}>
                              <Image
                                style={{
                                  width: 80,
                                  resizeMode: 'contain',
                                  marginLeft: 5,
                                }}
                                source={require('../../../../static/images/up-graph.png')}
                              />
                            </View>
                          </View>
                        </View>
                      </View>
                    </TouchableOpacity>
                  ))}
                {/* <View style={{ width: 150, marginRight: 15 }}>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ flex: 2 }}>
                                <Text style={{ fontSize: 12, color: '#fff' }}>BTC-USD</Text>
                            </View>
                            <View style={{ flex: 1 }}>
                                <View style={{ textAlign: 'right' }}>
                                    <Text style={{ fontSize: 12, color: '#FFAB00' }}>+0.05%</Text>
                                </View>
                            </View>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ flex: 1 }}>
                                <View style={{ textAlign: 'left' }}>
                                    <Text style={{ fontSize: 22, color: '#43D882' }}>45,025.58</Text>
                                </View>
                            </View>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ flex: 1 }}>
                                <View style={{ textAlign: 'left' }}>
                                    <Image style={{ width: 80, resizeMode: 'contain', marginLeft: 5}} source={require('../../../../static/images/up-graph.png')} />
                                </View>
                            </View>
                        </View>
                    </View>
                    <View style={{ width: 150, marginRight: 15 }}>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ flex: 2 }}>
                                <Text style={{ fontSize: 12, color: '#fff' }}>BTC-USD</Text>
                            </View>
                            <View style={{ flex: 1 }}>
                                <View style={{ textAlign: 'right' }}>
                                    <Text style={{ fontSize: 12, color: '#43D882' }}>+0.05%</Text>
                                </View>
                            </View>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ flex: 1 }}>
                                <View style={{ textAlign: 'left' }}>
                                    <Text style={{ fontSize: 22, color: '#43D882' }}>45,025.58</Text>
                                </View>
                            </View>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ flex: 1 }}>
                                <View style={{ textAlign: 'left' }}>
                                    <Image style={{ width: 80, resizeMode: 'contain', marginLeft: 5}} source={require('../../../../static/images/decline-graph.png')} />
                                </View>
                            </View>
                        </View>
                    </View> */}
              </ScrollView>

              <View style={{padding: 20, flexDirection: 'row', marginTop: 25}}>
                <View style={{flex: 1}}>
                  <View
                    style={{
                      backgroundColor: '#FFAB00',
                      borderRadius: 12,
                      padding: 5,
                      paddingRight: 15,
                      paddingLeft: 15,
                      marginLeft: 'auto',
                      marginRight: 'auto',
                      textAlign: 'center',
                    }}>
                    <Text
                      style={{
                        fontSize: 9,
                        color: '#fff',
                        marginLeft: 'auto',
                        marginRight: 'auto',
                      }}>
                      Hot
                    </Text>
                  </View>
                </View>
              </View>

              <View style={{flexDirection: 'row', marginTop: 5}}>
                <View style={{flex: 1}}>
                  <View style={{marginRight: 'auto', textAlign: 'left'}}>
                    <Text
                      style={{
                        fontSize: 8,
                        color: '#9C9E9D',
                        marginRight: 'auto',
                      }}>
                      Pair
                    </Text>
                  </View>
                </View>
                <View style={{flex: 1}}>
                  <View
                    style={{
                      marginLeft: 'auto',
                      marginRight: 'auto',
                      textAlign: 'center',
                    }}>
                    <Text
                      style={{
                        fontSize: 8,
                        color: '#9C9E9D',
                        marginLeft: 'auto',
                        marginRight: 'auto',
                      }}>
                      Last Price
                    </Text>
                  </View>
                </View>
                <View style={{flex: 1}}>
                  <View style={{marginLeft: 'auto', textAlign: 'right'}}>
                    <Text
                      style={{
                        fontSize: 8,
                        color: '#9C9E9D',
                        marginLeft: 'auto',
                      }}>
                      24h Chg%
                    </Text>
                  </View>
                </View>
              </View>

              {trending_markets && trending_markets.map((market, i) => (
                <TouchableOpacity
                  key={'tmmap-' + i}
                  onPress={() => {
                    navigate('TradeChart', {market: market}, 'market-' + market.id);
                  }}>
                  <View style={{flexDirection: 'row', marginTop: 10}}>
                    <View style={{flex: 1}}>
                      <View style={{marginRight: 'auto', textAlign: 'left'}}>
                        <Text
                          style={{
                            fontSize: 14,
                            color: '#9C9E9D',
                            marginRight: 'auto',
                          }}>
                          {market.name}
                        </Text>
                      </View>
                    </View>
                    <View style={{flex: 1}}>
                      <View
                        style={{
                          marginLeft: 'auto',
                          marginRight: 'auto',
                          textAlign: 'center',
                        }}>
                        <Text
                          style={{
                            fontSize: 14,
                            color: '#9C9E9D',
                            marginLeft: 'auto',
                            marginRight: 'auto',
                          }}>
                          {market.last}
                        </Text>
                      </View>
                    </View>
                    <View style={{flex: 1}}>
                      <View
                        style={{
                          backgroundColor: '#43D882',
                          borderRadius: 12,
                          padding: 2,
                          paddingRight: 15,
                          paddingLeft: 15,
                          marginLeft: 'auto',
                          textAlign: 'center',
                        }}>
                        <Text
                          style={{
                            fontSize: 14,
                            color: '#fff',
                            marginLeft: 'auto',
                            marginRight: 'auto',
                          }}>
                          {parseFloat(market.change_24h_percent).toFixed(2)}%
                        </Text>
                      </View>
                    </View>
                  </View>
                </TouchableOpacity>
              ))}

              {/* <View style={{ flexDirection: 'row', marginTop: 10 }}>
                    <View style={{ flex: 1 }}>
                        <View style={{ marginRight: 'auto', textAlign: 'left' }}>
                            <Text style={{ fontSize: 14, color: '#9C9E9D', marginRight: 'auto' }}>BNB/BUSD</Text>
                        </View>
                    </View>
                    <View style={{ flex: 1 }}>
                        <View style={{ marginLeft: 'auto', marginRight: 'auto', textAlign: 'center' }}>
                            <Text style={{ fontSize: 14, color: '#43D882', marginLeft: 'auto', marginRight: 'auto',  }}>404.5</Text>
                        </View>
                    </View>
                    <View style={{ flex: 1 }}>
                        <View style={{ backgroundColor: '#43D882', borderRadius: 12,  padding: 2, paddingRight: 15, paddingLeft: 15, marginLeft: 'auto', textAlign: 'center' }}>
                            <Text style={{ fontSize: 14, color: '#fff', marginLeft: 'auto', marginRight: 'auto',  }}>-% 2.53</Text>
                        </View>
                    </View>
                </View>
                <View style={{ flexDirection: 'row', marginTop: 10 }}>
                    <View style={{ flex: 1 }}>
                        <View style={{ marginRight: 'auto', textAlign: 'left' }}>
                            <Text style={{ fontSize: 14, color: '#9C9E9D', marginRight: 'auto' }}>BNB/BUSD</Text>
                        </View>
                    </View>
                    <View style={{ flex: 1 }}>
                        <View style={{ marginLeft: 'auto', marginRight: 'auto', textAlign: 'center' }}>
                            <Text style={{ fontSize: 14, color: '#F85F5F', marginLeft: 'auto', marginRight: 'auto',  }}>404.5</Text>
                        </View>
                    </View>
                    <View style={{ flex: 1 }}>
                        <View style={{ backgroundColor: '#F85F5F', borderRadius: 12,  padding: 2, paddingRight: 15, paddingLeft: 15, marginLeft: 'auto', textAlign: 'center' }}>
                            <Text style={{ fontSize: 14, color: '#fff', marginLeft: 'auto', marginRight: 'auto',  }}>-% 2.53</Text>
                        </View>
                    </View>
                </View>
                <View style={{ flexDirection: 'row', marginTop: 10 }}>
                    <View style={{ flex: 1 }}>
                        <View style={{ marginRight: 'auto', textAlign: 'left' }}>
                            <Text style={{ fontSize: 14, color: '#9C9E9D', marginRight: 'auto' }}>BNB/BUSD</Text>
                        </View>
                    </View>
                    <View style={{ flex: 1 }}>
                        <View style={{ marginLeft: 'auto', marginRight: 'auto', textAlign: 'center' }}>
                            <Text style={{ fontSize: 14, color: '#43D882', marginLeft: 'auto', marginRight: 'auto',  }}>404.5</Text>
                        </View>
                    </View>
                    <View style={{ flex: 1 }}>
                        <View style={{ backgroundColor: '#43D882', borderRadius: 12,  padding: 2, paddingRight: 15, paddingLeft: 15, marginLeft: 'auto', textAlign: 'center' }}>
                            <Text style={{ fontSize: 14, color: '#fff', marginLeft: 'auto', marginRight: 'auto',  }}>-% 2.53</Text>
                        </View>
                    </View>
                </View>
                <View style={{ flexDirection: 'row', marginTop: 10 }}>
                    <View style={{ flex: 1 }}>
                        <View style={{ marginRight: 'auto', textAlign: 'left' }}>
                            <Text style={{ fontSize: 14, color: '#9C9E9D', marginRight: 'auto' }}>BNB/BUSD</Text>
                        </View>
                    </View>
                    <View style={{ flex: 1 }}>
                        <View style={{ marginLeft: 'auto', marginRight: 'auto', textAlign: 'center' }}>
                            <Text style={{ fontSize: 14, color: '#F85F5F', marginLeft: 'auto', marginRight: 'auto',  }}>404.5</Text>
                        </View>
                    </View>
                    <View style={{ flex: 1 }}>
                        <View style={{ backgroundColor: '#F85F5F', borderRadius: 12,  padding: 2, paddingRight: 15, paddingLeft: 15, marginLeft: 'auto', textAlign: 'center' }}>
                            <Text style={{ fontSize: 14, color: '#fff', marginLeft: 'auto', marginRight: 'auto',  }}>-% 2.53</Text>
                        </View>
                    </View>
                </View> */}

              {/* </View> */}
              {/* <View style={styles.formgroup}>
                <Form>
                  <Text style={{marginTop: 15, color: '#fff', fontSize: 13}}>Password</Text>
                  <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                    <Input
                      style={styles.inputfield}
                      placeholder={'E-mail address'}
                      onChangeText={text => this.setState({email: text})}
                    />
                  </Item>
                  <Button
                    block
                    style={[styles.button, styles.orange]}
                    onPress={this.triggerForgot}>
                    <Text>Reset password</Text>
                  </Button>
                </Form>
              </View> */}
            </View>
          </Container>
        )}
        <BottomProtectedNavigationBar navigate={navigate} name="Home" />
        <View style={{height: 500}} />
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  background: {
    backgroundColor: '#000',
  },
  container: {
    alignItems: 'center',
    flexGrow: 1,
    justifyContent: 'center',
  },
  logo: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    width: 300,
    height: 100,
  },
  logoText: {
    color: '#fefefe',
    fontSize: 36,
  },
  smallText: {
    color: '#fefefe',
    fontSize: 18,
  },
  button: {
    marginTop: 35,
    textAlign: 'center',
    borderRadius: 48,
  },
  formgroup: {
    padding: 15,
  },
  inputfield: {
    padding: 15,
    paddingLeft: 15,
    paddingRight: 15,
    fontSize: 13,
    backgroundColor: '#222222',
    borderColor: '#222222',
    borderRadius: 6,
  },
  orange: {
    backgroundColor: '#FFAB00',
  },
  green: {
    backgroundColor: '#27ae60',
  },
  topLogoBackground: {
    textAlign: 'center',
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20,
  },
});

export default connect(mapStateToProps, mapDispatchToComponent)(Dashboard);
