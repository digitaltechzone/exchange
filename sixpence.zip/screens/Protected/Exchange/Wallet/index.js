import React from 'react';
import {StyleSheet, ScrollView, Image, ImageBackground} from 'react-native';
import {
  Container,
  Title,
  Button,
  View,
  Text,
  Item,
  Input,
  Form,
  Label,
  Content,
  CheckBox,
  Body,
  Toast,
} from 'native-base';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import Loading from '../../../Main/Loading';
import {
  Banner,
  Wrapper,
  TopProtectedNavigationBar,
  BottomProtectedNavigationBar,
} from '../../../../static';

import * as orderActionCreators from '../../../../data/orders/actions';
import * as walletsActionCreators from '../../../../data/wallets/actions';
import * as fiatWalletsActionCreators from '../../../../data/fiatWallets/actions';

const mapStateToProps = state => {
  return {
    // orders: state.data.orders,
    wallets: state.data.wallets,
    fiatWallets: state.data.fiatWallets,
  };
};

const mapDispatchToComponent = dispatch => ({
  actions: {
    // orders: bindActionCreators(orderActionCreators, dispatch),
    wallets: bindActionCreators(walletsActionCreators, dispatch),
    fiatWallets: bindActionCreators(fiatWalletsActionCreators, dispatch),
  },
});

class Wallet extends React.Component {
  constructor() {
    super();
    this.state = {
      email: '',
      amount: 0,
      rate: 0,
      loading: false,
      showToast: false,
      activeTab: 'favourite',
    };

    this.changeTab = this.changeTab.bind(this);
    this.changeTabFavourite = this.changeTabFavourite.bind(this);
  }
  componentDidMount() {
    this.loadWallets();
  }

  loadWallets() {
    this.props.actions.wallets.getWallets();
    this.props.actions.fiatWallets.getFiatWallets();
  }

  changeTab() {
    this.setState({
      activeTab: 'spot',
    });
  }

  changeTabFavourite() {
    this.setState({
      activeTab: 'favourite',
    });
  }

  render() {
    const {navigate} = this.props.navigation;
    const fiatWallets = this.props.fiatWallets.data;
    const wallets = this.props.wallets.data;

    return (
      <ScrollView style={styles.background}>
        {this.state.loading && <Loading />}
        {!this.state.loading && (
          <Container style={styles.background}>
            {/* <Banner /> */}
            <TopProtectedNavigationBar navigate={navigate} name="Wallet" />

            <View style={{flexDirection: 'row', marginTop: 12}}>
              <View style={{flex: 1}}>
                <View
                  style={[
                    this.state.activeTab == 'favourite'
                      ? styles.pageTabSectionActive
                      : styles.pageTabSection,
                  ]}>
                  <Text
                    onPress={this.changeTabFavourite}
                    style={[
                      this.state.activeTab == 'favourite'
                        ? styles.pageTabTextActive
                        : styles.pageTabText,
                    ]}>
                    Fiat Wallets
                  </Text>
                </View>
              </View>
              <View style={{flex: 1}}>
                <View
                  style={[
                    this.state.activeTab == 'spot'
                      ? styles.pageTabSectionActive
                      : styles.pageTabSection,
                  ]}>
                  <Text
                    onPress={this.changeTab}
                    style={[
                      this.state.activeTab == 'spot'
                        ? styles.pageTabTextActive
                        : styles.pageTabText,
                    ]}>
                    Crypto Wallets
                  </Text>
                </View>
              </View>
              <View style={{flex: 1}} />
            </View>

            <View style={{backgroundColor: '#232323', padding: 20}}>
              {/* <View style={{ flexDirection: 'row' }}>
                            <View style={{ flex: 2 }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text style={{ color: '#fff', fontSize: 12, fontWeight: 'bold' }}>Equity Value (BTC) </Text>
                                    <Image style={{ width: 30, resizeMode: 'contain', marginTop: 3}} source={require('../../../../static/images/walleteye.png')} />
                                </View>
                            </View>
                            <View style={{ flex: 1 }}>

                            </View>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={{ color: '#fff', fontSize: 34, fontWeight: 'bold' }}>1,234.00 </Text>
                            <Text style={{ color: '#E2E2E2', fontSize: 17, fontWeight: 'bold', marginTop: 10 }}>= $20.20</Text>
                            <Image style={{ width: 30, resizeMode: 'contain', marginTop: 13}} source={require('../../../../static/images/tradewarn.png')} />
                        </View> }
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{flex: 1}}>
                                <Button block style={[styles.button, styles.orange]}>
                                    <Text style={{fontSize: 9}}>Deposit</Text>
                                </Button>
                            </View>
                            <View style={{flex: 1}}>
                                <Button block style={[styles.button, styles.ash]}>
                                    <Text style={{fontSize: 9}}>Withdraw</Text>
                                </Button>
                            </View>
                            <View style={{flex: 1}}>
                                <Button block style={[styles.button, styles.ash]}>
                                    <Text style={{fontSize: 9}}>Transfer</Text>
                                </Button>
                            </View>
                        </View>
                        */}
            </View>

            {this.state.activeTab == 'favourite' && (
              <React.Fragment>
                <View style={{paddingLeft: 5, paddingRight: 5, marginTop: 15}}>
                  <View style={{flexDirection: 'row'}}>
                    <View style={{flex: 1}}>
                      <Text style={{color: '#E2E2E2', fontSize: 14}}>
                        Portfolio
                      </Text>
                    </View>

                  </View>
                  <ScrollView style={{flex: 1}}>
                    {fiatWallets.map((item, i) => (
                      <View
                        key={'fwm-' + i}
                        style={{
                          marginTop: 15,
                          borderBottomWidth: 1,
                          borderBottomColor: '#424E5E',
                        }}>
                        <View style={{marginBottom: 10, flexDirection: 'row'}}>
                          <View style={{flex: 1}}>
                            <View style={{flexDirection: 'row'}}>
                              {/* <Image style={{ width: 30, resizeMode: 'contain'}} source={require('../../../../static/images/traderight.png')} /> */}
                              <Text style={{color: '#E2E2E2', fontSize: 15}}>
                                {item.currency}
                              </Text>
                            </View>
                          </View>
                          <View style={{flex: 1}}>
                            <View>
                              <Text
                                style={{
                                  color: '#E2E2E2',
                                  fontSize: 15,
                                  marginLeft: 'auto',
                                }}>
                                {item.total_balance} ({item.currency})
                              </Text>
                              <Text
                                style={{
                                  color: '#CFD7E3',
                                  fontSize: 10,
                                  marginLeft: 'auto',
                                }}>
                                = {item.available} ({item.currency})
                              </Text>
                            </View>
                          </View>
                        </View>
                      </View>
                    ))}
                  </ScrollView>
                </View>
              </React.Fragment>
            )}

            {this.state.activeTab == 'spot' && (
              <React.Fragment>
                <View style={{paddingLeft: 5, paddingRight: 5, marginTop: 15}}>


                  {wallets.map((item, i) => (
                    <View
                      key={'wmp-' + i}
                      style={{
                        marginTop: 15,
                        borderBottomWidth: 1,
                        borderBottomColor: '#424E5E',
                      }}>
                      <View style={{marginBottom: 10, flexDirection: 'row'}}>
                        <View style={{flex: 1}}>
                          <View style={{marginLeft: 5}}>
                            <Text style={{color: '#E2E2E2', fontSize: 15}}>
                              {item.currency}
                            </Text>
                            {/* <Text style={{  color: '#E2E2E2', fontSize: 9 }}>DENT</Text> */}
                          </View>
                        </View>
                        <View style={{flex: 1}}>
                          <View>
                            <Text
                              style={{
                                color: '#E2E2E2',
                                fontSize: 15,
                                marginLeft: 'auto',
                              }}>
                              {item.total_balance} ({item.currency})
                            </Text>
                            <Text
                              style={{
                                color: '#CFD7E3',
                                fontSize: 9,
                                marginLeft: 'auto',
                              }}>
                              = {item.available} ({item.currency})
                            </Text>
                          </View>
                        </View>
                      </View>
                    </View>
                  ))}
                </View>
              </React.Fragment>
            )}

            {/* </View> */}
            {/* <View style={styles.formgroup}>
                <Form>
                  <Text style={{marginTop: 15, color: '#fff', fontSize: 13}}>Password</Text>
                  <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                    <Input
                      style={styles.inputfield}
                      placeholder={'E-mail address'}
                      onChangeText={text => this.setState({email: text})}
                    />
                  </Item>
                  <Button
                    block
                    style={[styles.button, styles.orange]}
                    onPress={this.triggerForgot}>
                    <Text>Reset password</Text>
                  </Button>
                </Form>
              </View> */}
          </Container>
        )}
        <BottomProtectedNavigationBar navigate={navigate} name="Wallet" />
        <View style={{height: 0}} />
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  background: {
    backgroundColor: '#000',
  },
  container: {
    alignItems: 'center',
    flexGrow: 1,
    justifyContent: 'center',
  },
  logo: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    width: 300,
    height: 100,
  },
  logoText: {
    color: '#fefefe',
    fontSize: 36,
  },
  smallText: {
    color: '#fefefe',
    fontSize: 18,
  },
  button: {
    marginTop: 0,
    textAlign: 'center',
    borderRadius: 4,
    marginLeft: 5,
    marginTop: 10,
    height: 30,
  },
  formgroup: {
    padding: 15,
  },
  inputfield: {
    padding: 1,
    paddingLeft: 35,
    paddingRight: 15,
    fontSize: 10,
    backgroundColor: '#343434',
    borderColor: '#343434',
    borderRadius: 6,
    height: 35,
  },
  orange: {
    backgroundColor: '#FFAB00',
  },
  green: {
    backgroundColor: '#43D882',
  },
  ash: {
    backgroundColor: '#9C9E9D',
  },
  topLogoBackground: {
    textAlign: 'center',
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20,
  },
  pageTabSection: {
    paddingTop: 15,
    paddingBottom: 15,
    marginLeft: 'auto',
    marginRight: 'auto',
    textAlign: 'center',
  },
  pageTabSectionActive: {
    paddingTop: 15,
    paddingBottom: 15,
    marginLeft: 'auto',
    marginRight: 'auto',
    textAlign: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#FFAB00',
  },
  pageTabText: {
    fontSize: 14,
    color: '#fff',
    marginLeft: 'auto',
    marginRight: 'auto',
  },
  pageTabTextActive: {
    fontSize: 14,
    color: '#FFAB00',
    marginLeft: 'auto',
    marginRight: 'auto',
  },
});

export default connect(mapStateToProps, mapDispatchToComponent)(Wallet);
