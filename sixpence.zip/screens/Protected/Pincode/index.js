import React from 'react';
import {connect} from 'react-redux';
import {
  StyleSheet,
  TouchableWithoutFeedback,
  Keyboard,
  ScrollView,
  Image,
  Alert,
} from 'react-native';
import {
  Container,
  Title,
  Button,
  View,
  Text,
  Item,
  Input,
  Form,
  Label,
  Content,
  CheckBox,
  Body,
  Toast,
} from 'native-base';

//import Keyboard from 'react-native-keyboard';
import Loading from '../../Main/Loading';
import {Banner, Wrapper, TopNavigationBar} from '../../../static';

import * as session from '../../../services/session';
import * as API from '../../../services/api';
import Hyperlink from "react-native-hyperlink";

// Map state to props
const mapStateToProps = function (state) {
  return {
    enabled: state.services.session.pin.enabled,
  };
};

class Pincode extends React.Component {
  constructor() {
    super();
    this.state = {
      loading: false,
      showToast: false,
      description:
        'In order to have a secure user session, you have to setup an unique 4 digit PIN which will keep your data safe.',
      enabled: false,
      setup: false,
      digit_one: 0,
      digit_two: 0,
      digit_three: 0,
      digit_four: 0,
    };

    this.triggerPinSet = this.triggerPinSet.bind(this);
    this.changeDigit = this.changeDigit.bind(this);
  }

  componentWillMount() {
    //
    if (this.props.enabled) {
      this.setState({
        description: 'Please enter 4 digit PIN that you have set up.',
      });
    }
  }

  triggerPinSet = () => {
    let code = 0;

    code += this.state.digit_one * 1000;
    code += this.state.digit_two * 100;
    code += this.state.digit_three * 10;
    code += this.state.digit_four;

    const enabled = this.props.enabled;

    if (code && code > 999 && code < 10000) {
      if (enabled) {
        session.pinRefresh(code).catch(error => {
          let string = error.message;

          this.setState({
            digit_one: 0,
            digit_two: 0,
            digit_three: 0,
            digit_four: 0,
          });

          this.refs.DigitOne._root.clear();
          this.refs.DigitTwo._root.clear();
          this.refs.DigitThree._root.clear();
          this.refs.DigitFour._root.clear();

          Toast.show({
            text: string,
            position: 'top',
            buttonText: 'X',
            type: 'danger',
          });
        });
      } else {
        session.pinSet(Number(code));
      }
    } else {
      Toast.show({
        text: 'Please enter a valid 4 digit code.',
        position: 'top',
        buttonText: 'X',
        type: 'danger',
      });
    }
  };

  changeDigit(v, place) {
    // Setting up the digit
    const value = Number(v);

   // console.log('Triggered: ' + v + ' - ' + place);

    if (v !== null && value != null && value != '') {
      switch (place) {
        case 1:
          this.setState({digit_one: value});
        case 2:
          this.setState({digit_two: value});
        case 3:
          this.setState({digit_three: value});
        case 4:
          this.setState({digit_four: value});
        default:
          Keyboard.dismiss();
      }

      if (place == 1) {
        this.refs.DigitTwo._root.focus();
      } else if (place == 2) {
        this.refs.DigitThree._root.focus();
      } else if (place == 3) {
        this.refs.DigitFour._root.focus();
      } else {
        Keyboard.dismiss();
      }

      Keyboard.dismiss;
    }
  }

  render() {
    return (
      <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
        <ScrollView style={styles.background}>
          {this.state.loading && <Loading />}
          {!this.state.loading && (
            <Container style={styles.background}>
              {/* <Toast /> */}
              {/* <Banner /> */}
              <TopNavigationBar name="Pin Code Protection" />
              <View style={styles.topLogoBackground}>
                <Image style={{marginTop: 30}} source={require('../../../static/images/kriptoist.png')} />
              </View>
              <View style={{marginTop: 30}}>
                <View style={styles.formgroup}>
                  <Form
                    style={{flexDirection: 'row', justifyContent: 'center'}}>
                    <Item regular style={{flex: 1, margin: 15, marginLeft: 15}}>
                      <Input
                        style={styles.inputfield}
                        ref="DigitOne"
                        onChangeText={text => {
                          this.changeDigit(text, 1);
                        }}
                        keyboardType="numeric"
                        placeholder="0"
                        placeholderTextColor="#d5d5d5"
                      />
                    </Item>
                    <Item regular style={{flex: 1, margin: 15}}>
                      <Input
                        style={styles.inputfield}
                        ref="DigitTwo"
                        onChangeText={text => {
                          this.changeDigit(text, 2);
                        }}
                        keyboardType="numeric"
                        placeholder="0"
                        placeholderTextColor="#d5d5d5"
                      />
                    </Item>
                    <Item regular style={{flex: 1, margin: 15}}>
                      <Input
                        style={styles.inputfield}
                        ref="DigitThree"
                        onChangeText={text => {
                          this.changeDigit(text, 3);
                        }}
                        keyboardType="numeric"
                        placeholder="0"
                        placeholderTextColor="#d5d5d5"
                      />
                    </Item>
                    <Item regular style={{flex: 1, margin: 15}}>
                      <Input
                        style={styles.inputfield}
                        ref="DigitFour"
                        onChangeText={text => {
                          this.changeDigit(text, 4);
                        }}
                        keyboardType="numeric"
                        placeholder="0"
                        placeholderTextColor="#d5d5d5"
                      />
                    </Item>
                  </Form>
                  <Button
                    block
                    style={[styles.button, styles.orange]}
                    onPress={this.triggerPinSet}>
                    <Text>Confirm</Text>
                  </Button>
                  {this.props.enabled && (

                  <View>
                      <Text
                        style={{
                          color: '#767676',
                          textAlign: 'center',
                          marginTop: 15,
                        }}>
                        Please insert your PIN code.
                      </Text>
                      <Hyperlink onPress={() => navigate('Terms', {screen: 'Terms'})}

                                 linkStyle={{ color: '#27ae60'}} >
                        <Text style={{ fontSize: 14 }}>I agree to the https://ccx.earth/#/terms</Text>
                      </Hyperlink>
                  </View>
                  )}
                  {!this.props.enabled && (
                    <Text
                      style={{
                        color: '#767676',
                        textAlign: 'center',
                        marginTop: 15,
                      }}>
                      This is the first time you are using this PIN code. Please
                      set up a 4 digit code that you will use in order to have a
                      more secure acccess.
                    </Text>
                  )}
                </View>
              </View>
            </Container>
          )}
        </ScrollView>
      </TouchableWithoutFeedback>
    );
  }
}

const styles = StyleSheet.create({
  background: {
    backgroundColor: '#000',
  },
  container: {
    alignItems: 'center',
    flexGrow: 1,
    justifyContent: 'center',
  },
  alignement: {
    alignItems: 'center',
  },
  logo: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    width: 300,
    height: 100,
  },
  logoText: {
    color: '#fefefe',
    fontSize: 36,
  },
  smallText: {
    color: '#fefefe',
    fontSize: 18,
  },
  parahraph: {
    color: '#fefefe',
    fontSize: 14,
  },
  topLogoBackground: {
    textAlign: 'center',
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20
  },
  button: {
    marginTop: 35,
    textAlign: 'center',
    borderRadius: 48
  },
  formgroup: {
    padding: 20,
  },
  inputfield: {
    textAlign: 'center',
    color: '#fff'
  },
  orange: {
    backgroundColor: '#FFAB00',
  },
  green: {
    backgroundColor: '#27ae60',
  },
});

export default connect(mapStateToProps)(Pincode);
