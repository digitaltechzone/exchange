import React from 'react';
import {
  StyleSheet,
  ScrollView,
  Image,
  ImageBackground,
  TouchableOpacity,
} from 'react-native';
import {
  Container,
  Title,
  Button,
  View,
  Text,
  Item,
  Input,
  Form,
  Label,
  Content,
  CheckBox,
  Body,
  Toast,
} from 'native-base';

import Loading from '../../Main/Loading';
import {
  Banner,
  Wrapper,
  TopProtectedNavigationBar,
  BottomProtectedNavigationBar,
} from '../../../static';

import * as usersAPI from '../../../data/users/api';
import * as API from '../../../services/api';
import {logout} from '../../../services/session';
import store from '../../../store';

class Profile extends React.Component {
  constructor() {
    super();
    this.state = {
      email: '',
      loading: false,
      showToast: false,
    };

    this.triggerForgot = this.triggerForgot.bind(this);

    //   console.log('session profile ', store.getState().services.session);
    this.user = store.getState().services.session.user;
    console.log('user ', store.getState().services.session);
  }

  triggerForgot() {
    const {email} = this.state;

    // Start the spinner
    this.setState({
      loading: true,
    });

    usersAPI
      .forgotpassword({email})
      .then(this.handleForgotSuccess.bind(this))
      .catch(this.handleForgotError.bind(this));
  }

  render() {
    const {navigate} = this.props.navigation;

    return (
      <ScrollView style={styles.background}>
        {this.state.loading && <Loading />}
        {!this.state.loading && (
          <Container style={styles.background}>
            {/* <Banner /> */}
            <TopProtectedNavigationBar navigate={navigate} name="Profile" />
            <View style={styles.topLogoBackground}>
              {/* <Image style={{marginTop: 30}} source={require('../../../../static/images/kriptoist.png')} /> */}
            </View>
            <View style={{padding: 5}}>
              <View style={{flexDirection: 'row'}}>
                <View style={{flex: 2}}>
                  <Text style={{color: '#fff'}}>{this.user.name}</Text>
                  <Text style={{color: '#fff'}}>ID: {this.user.id}</Text>
                </View>
                <View style={{flex: 1}}>
                  <View
                    style={styles.verifiedBox}
                  >
                    <View style={{flex: 1}}>
                      <Image
                        style={{marginTop: 0, marginLeft: 'auto'}}
                        source={require('../../../static/images/greenicon.png')}
                      />
                    </View>
                    <View style={{flex: 2}}>
                      <Text style={{color: '#fff', textAlign: 'right'}}>
                        Verified
                      </Text>
                    </View>
                  </View>
                </View>
              </View>

              <View
                style={{
                  backgroundColor: '#222222',
                  padding: 20,
                  marginTop: 20,
                }}>
                <TouchableOpacity onPress={logout}>
                  <View
                    style={{
                      flexDirection: 'row',
                      borderBottomWidth: 1,
                      borderBottomColor: '#444',
                      paddingTop: 15,
                      paddingBottom: 15,
                    }}>
                    <View style={{flex: 1}}>
                      <Image
                        style={{marginTop: 0, marginRight: 'auto'}}
                        source={require('../../../static/images/logout.png')}
                      />
                    </View>
                    <View style={{flex: 4}}>
                      <Text style={{color: '#fff'}}>Log Out</Text>
                    </View>
                    <View style={{flex: 1}}>
                      <Image
                        style={{marginTop: 0, marginLeft: 'auto'}}
                        source={require('../../../static/images/arrow-right.png')}
                      />
                    </View>
                  </View>
                </TouchableOpacity>
              </View>

              {/* </View> */}
              {/* <View style={styles.formgroup}>
                <Form>
                  <Text style={{marginTop: 15, color: '#fff', fontSize: 13}}>Password</Text>
                  <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                    <Input
                      style={styles.inputfield}
                      placeholder={'E-mail address'}
                      onChangeText={text => this.setState({email: text})}
                    />
                  </Item>
                  <Button
                    block
                    style={[styles.button, styles.orange]}
                    onPress={this.triggerForgot}>
                    <Text>Reset password</Text>
                  </Button>
                </Form>
              </View> */}
            </View>
          </Container>
        )}
        <BottomProtectedNavigationBar name="Dashboard" />
        <View style={{height: 250}} />
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  verifiedBox: {
    backgroundColor: '#43D882',
    flexDirection: 'row',
    padding: 5,
    textAlign: 'right',
    borderTopLeftRadius: 12,
    borderBottomLeftRadius: 12,
  },
  background: {
    backgroundColor: '#000',
  },
  container: {
    alignItems: 'center',
    flexGrow: 1,
    justifyContent: 'center',
  },
  logo: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    width: 300,
    height: 100,
  },
  logoText: {
    color: '#fefefe',
    fontSize: 36,
  },
  smallText: {
    color: '#fefefe',
    fontSize: 18,
  },
  button: {
    marginTop: 35,
    textAlign: 'center',
    borderRadius: 48,
  },
  formgroup: {
    padding: 15,
  },
  inputfield: {
    padding: 15,
    paddingLeft: 15,
    paddingRight: 15,
    fontSize: 13,
    backgroundColor: '#222222',
    borderColor: '#222222',
    borderRadius: 6,
  },
  orange: {
    backgroundColor: '#FFAB00',
  },
  green: {
    backgroundColor: '#27ae60',
  },
  topLogoBackground: {
    textAlign: 'center',
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20,
  },
});

export default Profile;
