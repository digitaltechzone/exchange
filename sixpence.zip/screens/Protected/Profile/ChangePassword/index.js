import React from 'react';
import {StyleSheet, ScrollView, Image, ImageBackground, TouchableOpacity} from 'react-native';
import {
  Container,
  Title,
  Button,
  View,
  Text,
  Item,
  Input,
  Form,
  Label,
  Content,
  CheckBox,
  Body,
  Toast,
} from 'native-base';

import Loading from '../../../Main/Loading';
import {Banner, Wrapper, TopProtectedNavigationBar, BottomProtectedNavigationBar} from '../../../../static';
import SelectDropdown from 'react-native-select-dropdown';

import * as usersAPI from '../../../../data/users/api';
import * as API from '../../../../services/api';

class ChangePassword extends React.Component {
  constructor() {
    super();
    this.state = {
      email: '',
      amount: 0,
      rate: 0,
      loading: false,
      showToast: false,
      showEmailChangeToast: false,
      showPhoneNumberToast: false,
      activeTab: 'favourite',
    };

    this.changeTab = this.changeTab.bind(this);
    this.changeTabFavourite = this.changeTabFavourite.bind(this);
  }

  changeTab() {
      this.setState({
          activeTab: 'spot'
      });
  }

  changeTabFavourite() {
    this.setState({
        activeTab: 'favourite'
    });
  }

  render() {
    const {navigate} = this.props.navigation;
    const countries = ["Egypt", "Canada", "Australia", "Ireland"]

    return (
        <React.Fragment>
      <ScrollView style={styles.background}>
        {this.state.loading && <Loading />}
        {!this.state.loading && (
          <Container style={styles.background}>
            {/* <Banner /> */}
            <TopProtectedNavigationBar navigate={navigate} name="Change Password" />

            <View style={{ marginTop: 12, padding: 10 }}>
                <View style={{flexDirection: 'row'}}>
                    <View style={{ flex: 1 }}>
                        <Text style={{color: '#fff', fontSize: 12}}>Name</Text>
                    </View>
                </View>
                <View style={{marginTop: 0, borderBottomWidth: 1, borderBottomColor: '#444'}}>
                    <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                        <Input style={styles.inputfield2}
                                placeholder="Active"
                                onChangeText={(text) => this.setState({email: text})}/>
                        <Image style={{position: 'absolute', left: 8, marginTop: 0, width: 20, resizeMode: 'contain', marginRight: 'auto'}} source={require('../../../../static/images/email.png')} />
                    </Item>
                </View>

                <View style={{flexDirection: 'row', marginTop: 10}}>
                    <View style={{ flex: 1 }}>
                        <Text style={{color: '#fff', fontSize: 12, marginTop: 15}}>Email Address</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                        <Button onPress={() => this.setState({showEmailChangeToast: true})} style={[styles.button, styles.orange, styles.left]}><Text style={{fontSize: 12}}>Update</Text></Button>
                    </View>
                </View>
                <View style={{marginTop: 0, borderBottomWidth: 1, borderBottomColor: '#444'}}>
                    <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                        <Input style={styles.inputfield}
                                placeholder="Email Address"
                                onChangeText={(text) => this.setState({email: text})}/>
                    </Item>
                </View>

                <View style={{flexDirection: 'row', marginTop: 10}}>
                    <View style={{ flex: 1 }}>
                        <Text style={{color: '#fff', fontSize: 12, marginTop: 15}}>Phone Number</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                        <Button onPress={() => this.setState({showPhoneNumberToast: true})} style={[styles.button, styles.orange, styles.left]}><Text style={{fontSize: 12}}>Add Phone Number</Text></Button>
                    </View>
                </View>
                <View style={{marginTop: 0, borderBottomWidth: 1, borderBottomColor: '#444'}}>
                    <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                        <Input style={styles.inputfield}
                                placeholder="Email Address"
                                onChangeText={(text) => this.setState({email: text})}/>
                    </Item>
                </View>

                <View style={{flexDirection: 'row', marginTop: 10}}>
                    <View style={{ flex: 1 }}>
                        <Text style={{color: '#fff', fontSize: 12, marginTop: 15}}>Status</Text>
                    </View>
                </View>
                <View style={{marginTop: 0, borderBottomWidth: 1, borderBottomColor: '#444'}}>
                    <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                        <Input style={styles.inputfield}
                                placeholder="Active"
                                onChangeText={(text) => this.setState({email: text})}/>
                    </Item>
                </View>

                <View style={{flexDirection: 'row', marginTop: 10}}>
                    <View style={{ flex: 1 }}>
                        <Text style={{color: '#fff', fontSize: 12, marginTop: 15}}>Two Factor Authentication</Text>
                    </View>
                </View>
                <View style={{marginTop: 0, borderBottomWidth: 1, borderBottomColor: '#444'}}>
                    <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                        <Input style={styles.inputfield}
                                placeholder="Active"
                                onChangeText={(text) => this.setState({email: text})}/>
                    </Item>
                </View>

                <View style={{flexDirection: 'row', marginTop: 10}}>
                    <View style={{ flex: 1 }}>
                        <Text style={{color: '#fff', fontSize: 12, marginTop: 15}}>Identity Verification</Text>
                    </View>
                </View>
                <View style={{marginTop: 0, borderBottomWidth: 1, borderBottomColor: '#444'}}>
                    <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                        <Input style={styles.inputfield}
                                placeholder="Active"
                                onChangeText={(text) => this.setState({email: text})}/>
                    </Item>
                </View>
            </View>


          </Container>
        )}
        <BottomProtectedNavigationBar navigate={navigate} name="Wallet" />
        <View style={{height:180}} />
      </ScrollView>


        {this.state.showEmailChangeToast && (
                <View style={{backgroundColor: '#232323', position: 'absolute', bottom: 0, left: 0, right: 0, padding: 15}}>
                  <View style={{flexDirection: 'row'}}>
                      <View style={{flex: 1}}>
                          <Text style={{color: '#fff'}}>Update Email</Text>
                      </View>
                      <View style={{flex: 1}}>
                          <TouchableOpacity onPress={() => this.setState({showEmailChangeToast: false})}>
                            <Image style={{marginTop: 0, width: 20, resizeMode: 'contain', marginLeft: 'auto'}} source={require('../../../../static/images/closeicon.png')} />
                          </TouchableOpacity>
                      </View>
                  </View>

                  <View style={{flexDirection: 'row', marginTop: 10}}>
                      <View style={{flex: 1}}>
                              <Text style={{color: '#fff', fontSize: 10}}>New Email Address</Text>
                              <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                                  <Input style={styles.inputfield2}
                                          placeholder="Active"
                                          onChangeText={(text) => this.setState({email: text})}/>
                                  <Image style={{position: 'absolute', left: 8, marginTop: 0, width: 20, resizeMode: 'contain', marginRight: 'auto'}} source={require('../../../../static/images/email.png')} />
                              </Item>
                      </View>
                  </View>

                  <View style={{flexDirection: 'row', marginTop: 10}}>
                      <View style={{flex: 1}}>
                              <Text style={{color: '#fff', fontSize: 10}}>Two Factor Authentication</Text>
                              <Button block style={[styles.button2, styles.orange]}>
                                  <Text style={{fontSize: 15}}>Send Email Verification Code</Text>
                              </Button>
                      </View>
                  </View>

                  <View style={{flexDirection: 'row', marginTop: 10}}>
                      <View style={{flex: 1}}>
                              <Text style={{color: '#fff', fontSize: 10}}>OTP Sent to Your Email</Text>
                              <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                                  <Input style={styles.inputfield2}
                                          placeholder="Active"
                                          onChangeText={(text) => this.setState({email: text})}/>
                                  <Image style={{position: 'absolute', left: 8, marginTop: 0, marginRight: 'auto'}} source={require('../../../../static/images/padlock.png')} />
                              </Item>
                      </View>
                  </View>

                  <View style={{flexDirection: 'row', marginTop: 10}}>
                      <View style={{flex: 1}}>
                              <Text style={{color: '#fff', fontSize: 10}}>One Time Password</Text>
                              <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                                  <Input style={styles.inputfield2}
                                          placeholder="Active"
                                          onChangeText={(text) => this.setState({email: text})}/>
                                  <Image style={{position: 'absolute', left: 8, marginTop: 0, marginRight: 'auto'}} source={require('../../../../static/images/padlock.png')} />
                              </Item>
                      </View>
                  </View>

                  <View style={{flexDirection: 'row', marginTop: 10}}>
                      <View style={{flex: 1}}>
                              <Button block style={[styles.button3, styles.ash]}>
                                  <Text style={{fontSize: 15}}>Cancel</Text>
                              </Button>
                      </View>
                      <View style={{flex: 1}}>
                              <Button block style={[styles.button3, styles.orange]}>
                                  <Text style={{fontSize: 15}}>Change</Text>
                              </Button>
                      </View>
                  </View>
              </View>
        )}

        {this.state.showPhoneNumberToast && (
                <View style={{backgroundColor: '#232323', position: 'absolute', bottom: 0, left: 0, right: 0, padding: 15}}>
                  <View style={{flexDirection: 'row'}}>
                      <View style={{flex: 1}}>
                          <Text style={{color: '#fff'}}>Update Phone</Text>
                      </View>
                      <View style={{flex: 1}}>
                          <TouchableOpacity onPress={() => this.setState({showPhoneNumberToast: false})}>
                            <Image style={{marginTop: 0, width: 20, resizeMode: 'contain', marginLeft: 'auto'}} source={require('../../../../static/images/closeicon.png')} />
                          </TouchableOpacity>
                      </View>
                  </View>

                  <View style={{flexDirection: 'row', marginTop: 10}}>
                      <View style={{flex: 1}}>
                              <Text style={{color: '#fff', fontSize: 10}}>New Phone Number</Text>
                              <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                                  <Input style={styles.inputfield2}
                                          placeholder="Enter Phone Number"
                                          onChangeText={(text) => this.setState({email: text})}/>
                                  <Image style={{position: 'absolute', left: 8, marginTop: 0, width: 20, resizeMode: 'contain', marginRight: 'auto'}} source={require('../../../../static/images/phoneicon.png')} />
                              </Item>
                      </View>
                  </View>

                  <View style={{flexDirection: 'row', marginTop: 10}}>
                      <View style={{flex: 1}}>
                              <Text style={{color: '#fff', fontSize: 10}}>Two Factor Authentication</Text>
                              <Button block style={[styles.button2, styles.orange]}>
                                  <Text style={{fontSize: 15}}>Send Email Verification Code</Text>
                              </Button>
                      </View>
                  </View>

                  <View style={{flexDirection: 'row', marginTop: 10}}>
                      <View style={{flex: 1}}>
                              <Text style={{color: '#fff', fontSize: 10}}>OTP Sent to Your Email</Text>
                              <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                                  <Input style={styles.inputfield2}
                                          placeholder="Active"
                                          onChangeText={(text) => this.setState({email: text})}/>
                                  <Image style={{position: 'absolute', left: 8, marginTop: 0, marginRight: 'auto'}} source={require('../../../../static/images/padlock.png')} />
                              </Item>
                      </View>
                  </View>

                  <View style={{flexDirection: 'row', marginTop: 10}}>
                      <View style={{flex: 1}}>
                              <Text style={{color: '#fff', fontSize: 10}}>One Time Password</Text>
                              <Item regular style={{ marginTop: 5, borderColor: 'transparent' }}>
                                  <Input style={styles.inputfield2}
                                          placeholder="Active"
                                          onChangeText={(text) => this.setState({email: text})}/>
                                  <Image style={{position: 'absolute', left: 8, marginTop: 0, marginRight: 'auto'}} source={require('../../../../static/images/padlock.png')} />
                              </Item>
                      </View>
                  </View>

                  <View style={{flexDirection: 'row', marginTop: 10}}>
                      <View style={{flex: 1}}>
                              <Button block style={[styles.button3, styles.ash]}>
                                  <Text style={{fontSize: 15}}>Cancel</Text>
                              </Button>
                      </View>
                      <View style={{flex: 1}}>
                              <Button block style={[styles.button3, styles.orange]}>
                                  <Text style={{fontSize: 15}}>Change</Text>
                              </Button>
                      </View>
                  </View>
              </View>
        )}

      </React.Fragment>
    );
  }
}

const styles = StyleSheet.create({
  background: {
    backgroundColor: '#000',
  },
  container: {
    alignItems: 'center',
    flexGrow: 1,
    justifyContent: 'center',
  },
  logo: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    width: 300,
    height: 100,
  },
  logoText: {
    color: '#fefefe',
    fontSize: 36,
  },
  smallText: {
    color: '#fefefe',
    fontSize: 18,
  },
  button: {
    marginTop: 0,
    textAlign: 'center',
    borderRadius: 4,
    marginLeft: 5,
    marginTop: 10,
    fontSize: 12,
    height: 30
  },
  button2: {
    marginTop: 0,
    textAlign: 'center',
    borderRadius: 4,
    marginLeft: 5,
    marginTop: 10,
    fontSize: 12,
    height: 40
  },
  button3: {
    marginTop: 0,
    textAlign: 'center',
    borderRadius: 24,
    marginLeft: 5,
    marginTop: 10,
    fontSize: 12,
    height: 40
  },
  formgroup: {
    padding: 15,
  },
  inputfield: {
    paddingLeft: 0,
    paddingRight: 15,
    fontSize: 12,
    backgroundColor: '#000',
    borderColor: '#343434',
    borderRadius: 6,
    height: 45,
    color: '#fff'
  },
  inputfield2: {
    paddingLeft: 0,
    paddingRight: 15,
    fontSize: 12,
    backgroundColor: '#000',
    borderColor: '#343434',
    borderRadius: 6,
    height: 45,
    color: '#fff',
    paddingLeft: 35,
  },
  orange: {
    backgroundColor: '#FFAB00',
  },
  left: {
    marginLeft: 'auto'
  },
  green: {
    backgroundColor: '#43D882',
  },
  ash: {
      backgroundColor: '#9C9E9D'
  },
  topLogoBackground: {
    textAlign: 'center',
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20
  },
  pageTabSection: {
    paddingTop: 15,
    paddingBottom: 15,
    marginLeft: 'auto',
    marginRight: 'auto',
    textAlign: 'center'
  },
  pageTabSectionActive: {
    paddingTop: 15,
    paddingBottom: 15,
    marginLeft: 'auto',
    marginRight: 'auto',
    textAlign: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#FFAB00'
  },
  pageTabText: {
    fontSize: 14,
    color: '#fff',
    marginLeft: 'auto',
    marginRight: 'auto'
  },
  pageTabTextActive: {
    fontSize: 14,
    color: '#FFAB00',
    marginLeft: 'auto',
    marginRight: 'auto'
  }

});

export default ChangePassword;
