import React from 'react';
import {StyleSheet, ScrollView} from 'react-native';
import {Container, Header, Title, Button, View, Text} from 'native-base';

import * as session from '../../services/session';

class Protected extends React.Component {
  constructor() {
    super();
    this.state = {};
  }

  logout() {
    session.logout();
  }

  render() {
    return (
      <Container>
        <View>
          <Text>Protected area</Text>
          <Button transparent block info onPress={this.logout.bind(this)}>
            <Text>Logout</Text>
          </Button>
        </View>
      </Container>
    );
  }
}

export default Protected;
