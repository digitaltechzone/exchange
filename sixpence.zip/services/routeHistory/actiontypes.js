export const PUSH = 'routeHistory/PUSH';
