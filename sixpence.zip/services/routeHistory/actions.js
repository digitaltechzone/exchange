import * as actionTypes from './actiontypes';

export const push = route => ({
    type: actionTypes.PUSH,
    route
})