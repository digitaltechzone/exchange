import React, {Component} from 'react';
import {Alert, SafeAreaView, ToastAndroid, View} from 'react-native';
import {WebView} from 'react-native-webview';

class IOSChart extends Component {



  render() {
    return (
      <View style={{height: 400}}>
        <WebView
          style={{
            flex: 1,
            backgroundColor: '#000000',

          }}
          source={{
            uri:
              'https://ccx.earth/chart/?market=' +
              this.props.market +
              '&locale=en',
          }}


        />
      </View>
    );
  }
}

const IOSApp = props => {
  console.log('props change ios',props.market);

  return <IOSChart market={props.market}/>;
};
module.exports = IOSApp;
