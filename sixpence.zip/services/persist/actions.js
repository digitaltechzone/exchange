import * as actionTypes from './actiontypes';

export const update = payload => ({
    type: actionTypes.UPDATE,
    payload
})