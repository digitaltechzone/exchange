import React, {Component} from 'react';
import {ToastAndroid, View} from 'react-native';
import {WebView} from 'react-native-webview';

class AndroidChart extends Component {
  constructor(market) {
    super();
    this.market = market;
  }
  jsToInject = `
  console.log("twidget",tvWidget);
      tvWidget.onChartReady(function() {

          tvWidget.chart().onIntervalChanged().subscribe(
              null,
              function(interval) {
                  const response = { type: "onIntervalChanged", interval: interval }
                  //window.ReactNativeWebView.postMessage accepts one argument, data, 
                  //which will be available on the event object, event.nativeEvent.data. data must be a string.
                  window.ReactNativeWebView.postMessage(JSON.stringify(response));
              }
          );
      });
      true; // note: this is required, or you'll sometimes get silent failures 
            // (https://github.com/react-native-webview/react-native-webview/blob/master/docs/Guide.md)
    `;

  render() {

    return (
      <View style={{height: 400}}>
        <WebView
          style={{
            flex: 1,
            backgroundColor: '#000000',
          }}

          source={{uri: 'https://ccx.earth/chart/?market='+this.market.market+'&locale=en'}}
        />
      </View>
    );
  }
}

const AndroidApp = (props) => {
  return (
    <AndroidChart  market={props.market}/>
  );
};
module.exports = AndroidApp;
