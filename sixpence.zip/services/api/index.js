import axios from 'axios';
import _ from 'lodash';

import * as sessionSelectors from '../session/selectors';
import apiconfig from './config';

// Exception handling
export const exceptionHandler = exception => {
  // Return false if no errors are present
  if (!exception.Errors) {
    return false;
  }

  let error = false;
  const ekeys = Object.keys(exception.Errors);
  if (ekeys.length > 0) {
    error = exception.Errors[ekeys[0]][0].message;
  }

  // Return the error
  return error;
};

// Fetching data from API
export const fetchAPI = (
  endpoint,
  payload = {},
  method = 'GET',
  headers = {},
  base = false,
  authorize = false,
) => {

  console.log("api fetch request, endpoint: " + endpoint+",payload:",payload);
  // Get the access token
  const access_token = sessionSelectors.get().tokens.access_token;

  // Setting up the token
  if (authorize) {
    headers.Authorization = `Bearer ${access_token}`;
  }

  // Setting up the accept type
  if (method == 'POST') {
    headers.Accept = 'application/json';
  }

  // Setting up the request options
  let baseurl = base ? apiconfig.baseurl : apiconfig.url;
  let options = {
    method: method,
    url: baseurl + endpoint,
    headers: headers,
    data: payload,
  };

  if (method == 'GET') {
    options = {
      method: method,
      url: baseurl + endpoint,
      headers: headers,
    };
  }
  try {
    let result = axios(options);
    return result;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      handleAxiosError(error);
    } else {
      handleUnexpectedError(error);
    }
  }


};
