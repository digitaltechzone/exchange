export default {
  url: 'https://ccx.earth/api/v1/',
  baseurl: 'https://ccx.earth/',
  client_id: '3',
  client_secret: '',
};
