import {AsyncStorage} from 'react-native';

import store from '../../store';

import * as api from './api';
import * as selectors from './selectors';
import * as actionCreators from './actions';
import {initialState} from './reducer';

const SESSION_THRESHOLD = 300;
const PIN_DURATION = 300;

let sessionTimeout = null;
let pinTimeout = null;

// Refreshing session before it expires
const setSessionTimeout = duration => {
  clearTimeout(sessionTimeout);

  sessionTimeout = setTimeout(
    refreshToken,
    (duration - SESSION_THRESHOLD) * 1000,
  );

  console.ignoredYellowBox = ['Setting a timer'];
};

// Set the PIN expire trigger
const setPinTimeout = () => {
  clearTimeout(pinTimeout);

  pinTimeout = setTimeout(pinSetExpired, PIN_DURATION * 1000);

  console.ignoredYellowBox = ['Setting a timer'];
};

// Login and refresh token success handler
const onRequestSuccess = response => {
  const session = selectors.get();

  // Get required tokens
  const tokens = {
    access_token: response.data.access_token,
    refresh_token: response.data.refresh_token,
  };

  // Initial PINcode
  const pin = {
    enabled: session.pin.enabled,
    code: session.pin.code,
    expired: true,
  };

  // Inital 2FA informations
  let twostep = {
    enabled: null,
    verified: null,
    type: null,
  };

  let user = {
    id: null,
    email: null,
    name: null,
  };

  // Set the token to expire
  setSessionTimeout(response.data.expires_in);

  // Check if the user needs to do the 2FA
  api
    .user(response.data.access_token)
    .then(response => {
      // console.log("request response",response.data);
      user.id = response.data.id;
      user.email = response.data.email;
      user.name = response.data.name;

      // all good here
      // Dispatch initial state
      store.dispatch(actionCreators.update({tokens, twostep, pin, user}));
    })
    .catch(error => {
      if (error && error.response.status === 412) {
        // Setup the twostep according to the response
        twostep = {
          enabled: true,
          verified: false,
          type: error.response.data.two_fa_method,
        };
        console.log('dispatch from error');

        // Dispatch the action with that informations
        store.dispatch(actionCreators.update({tokens, twostep, pin, user}));

        // If the authentication method is SMS
        // Make a new api call to get the SMS
        if (twostep.type === 'sms') {
          api
            .twofaSMS(response.data.access_token)
            .then(() => {})
            .catch(() => {
              console.log('Something went wrong.');
            });
        }
      }
    });
};

// 2FA success request handler
const on2FARequestSucces = response => {
  const session = selectors.get();

  const tokens = {
    access_token: session.tokens.access_token,
    refresh_token: session.tokens.refresh_token,
  };

  // Initial PINcode
  const pin = {
    enabled: session.pin.enabled,
    code: session.pin.code,
    expired: session.pin.expired,
  };

  const twostep = {
    enabled: true,
    verified: true,
    type: session.tokens.type,
  };

  const user = {
    id: session.user.id,
    name: session.user.name,
    email: session.user.email,
  };

  // Dispatch the new informations
  store.dispatch(actionCreators.update({tokens, twostep, pin, user}));
};

const onRequestFailed = exception => {
  throw exception;
};

// Authenticate
export const authenticate = (email, password) => {
  return api
    .login(email, password)
    .then(onRequestSuccess)
    .catch(onRequestFailed);
};

// Refresh authentication token
export const refreshToken = () => {
  const session = selectors.get();

  if (!session.tokens.refresh_token) {
    return Promise.reject();
  }

  return api
    .refresh(session.tokens.refresh_token)
    .then(onRequestSuccess)
    .catch(onRequestFailed);
};

// Verify 2FA
export const verify2FA = otp => {
  const session = selectors.get();

  if (!session.tokens.access_token) {
    return Promise.reject();
  }

  return api
    .twofaVerify(session.tokens.access_token, otp)
    .then(on2FARequestSucces)
    .catch(onRequestFailed);
};

// Logout function
export const logout = () => {
  const session = selectors.get();

  clearTimeout(sessionTimeout);

  const tokens = {
    access_token: null,
    refresh_token: null,
  };

  const twostep = {
    enabled: null,
    type: null,
  };

  const user = {
    id: null,
    email: null,
    name: null,
  };

  // Persist the PIN
  const pin = session.pin;

  console.log('dispatch logout ');
  store.dispatch(actionCreators.update({tokens, twostep, pin, user}));
};

// Setup the PIN function
export const pinSet = code => {
  const session = selectors.get();
  const {tokens, twostep, user} = session;

  const pin = {
    enabled: true,
    code: code,
    expired: false,
  };

  // Dispatch the spin setup
  store.dispatch(actionCreators.update({tokens, twostep, pin, user}));

  // Set the pin to expire after five minutes
  setPinTimeout();
};

// Set pin to expired
export const pinSetExpired = () => {
  const session = selectors.get();
  const {tokens, twostep, user} = session;

  console.log('Setting the pin expired...');

  let pin = {
    code: session.pin.code,
    enabled: true,
    expired: true,
  };

  store.dispatch(actionCreators.update({tokens, twostep, pin, user}));
};

// Refresh the pin timeout
export const pinRefresh = code => {
  const session = selectors.get();

  return new Promise((resolve, reject) => {
    if (session.pin.code == code) {
      pinSet(code);
      resolve({message: 'PIN confirmed'});
    } else {
      let reason = new Error("The PIN doesn't match the PIN you have set up.");
      reject(reason);
    }
  });
};
