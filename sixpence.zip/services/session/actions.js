import * as actionTypes from './actiontypes';

export const update = session => ({
    type: actionTypes.UPDATE,
    session
});

export const verify = session => ({
    type: actionTypes.VERIFY,
    session
});
