import {Buffer} from 'buffer';
import {fetchAPI} from '../api';
import apiconfig from '../api/config';

// Declaring the authentication endpoints
const endpoints = {
  login: 'oauth/token',
  refresh: 'oauth/token',
  twofa_request: 'twofa/request',
  twofa_verify: 'twofa/verify',
  user: 'user',
};

// Declaring the login fucntion
export const login = (email, password) => {
  const payload = {
    username: email,
    password: password,
    grant_type: 'password',
    scope: '*',
    client_id: apiconfig.client_id,
    client_secret: apiconfig.client_secret,
  };

  return fetchAPI(
    endpoints.login,
    payload,
    'POST',
    {Authorization: null},
    true,
  );
};

// Declaring the token refresh
export const refresh = token => {
  const payload = {
    refresh_token: token,
    grant_type: 'refresh_token',
    client_id: apiconfig.client_id,
    client_secret: apiconfig.client_secret,
    scope: '*',
  };

  return fetchAPI(
    endpoints.refresh,
    payload,
    'POST',
    {
      Authorization: null,
    },
    true,
  );
};

// Retrieve user data, also can check if the 2FA is needed
export const user = token => {
  return fetchAPI(endpoints.user, null, 'GET', {
    Authorization: 'Bearer ' + token,
  });
};

// Request 2FA verification token -- SMS
export const twofaSMS = token => {
  return fetchAPI(endpoints.twofa_request, null, 'GET', {
    Authorization: 'Bearer ' + token,
  });
};

// Verify the 2FA
export const twofaVerify = (token, otp) => {
  return fetchAPI(endpoints.twofa_verify, {otp}, 'POST', {
    Authorization: 'Bearer ' + token,
  });
};
