import * as actionTypes from './actiontypes';

export const initialState = {
  tokens: {
    access_token: null,
    refresh_token: null,
  },
  twostep: {
    enabled: null,
    verified: null,
    type: null,
  },
  pin: {
    enabled: null,
    code: null,
    expires: null,
  },
  user: {
    id: null,
    email: null,
    name: null,
  },
};

export const reducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.UPDATE:
      return {
        ...action.session,
      };
    case actionTypes.VERIFY:
      return {
        tokens: {
          ...action.session.tokens,
        },
        user: {
          ...action.session.user,
        },
        twostep: {
          enabled: null,
          verified: null,
          type: null,
        },
        pin: {
          ...action.session.pin,
        },
      };
    default:
      return state;
  }
};
