export const UPDATE = 'session/UPDATE';
export const VERIFY = 'session/VERIFY';